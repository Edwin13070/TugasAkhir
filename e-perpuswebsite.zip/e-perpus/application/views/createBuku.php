<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Tambah Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">

                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Tambah </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <form action="<?= base_url('admin/buku/InputProses') ?>" method="post"
                            enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Kode Buku</label>
                                            </div>
                                            <div class="col-8"><input type="text" value="<?= $kdBk; ?>" readonly
                                                    id="text-input" name="kd_buku" class="form-control" required></div>

                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Judul</label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="judul" required
                                                    placeholder="Contoh: Rumus Matematika" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">No. Buku / ISSBN
                                                </label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="no_buku"
                                                    required placeholder="Contoh: 1231322" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Kategori
                                                </label></div>
                                            <div class="col-8">
                                                <select name="id_ktg" id="id_ktg" class="form-control" required>
                                                    <option value="">---Pilih Kategori---</option>
                                                    <?php foreach ($kategori as $datakategori) : ?>
                                                    <option value="<?= $datakategori->id_ktg ?>">
                                                        <?= $datakategori->nama_ktg ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for=""
                                                    class="form-control-label">Pengarang</label></div>
                                            <div class="col-8">
                                                <input type="text" id="pengarang" placeholder="Contoh: Cut Mutia" name="pengarang"
                                                    required class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for=""
                                                    class="form-control-label">Penerbit</label></div>
                                            <div class="col-8">
                                                <input type="text" id="penerbit" placeholder="Contoh: CV. Andi " name="penerbit"
                                                    required class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 ">

                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Tahun Terbit</label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="thn_terbit"
                                                    required placeholder="Text" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Stok</label></div>
                                            <div class="col-8"><input type="number" Min="1" id="text-input" name="stok"
                                                    required placeholder="Stok Buku" class="form-control"></div>
                                        </div>
                                         <div class="form-group row">
                                            <label for="keterangan_buku" class="col-md-4 col-form-label">Keterangan</label>
                                            <div class="col-md-8">
                                                <textarea class="form-control" name="keterangan_buku" id="keterangan_buku"
                                                    name="keterangan_buku"></textarea>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="file-input"
                                                    class=" form-control-label">Upload
                                                    Sampul</label></div>
                                            <div class="col-md-8">
                                                <input type="file" required name="sampul" class="form-control-file"
                                                    id="sampul">
                                            </div>
                                        </div>

                                        <!-- Input Hidden -->
                                        <div class="row form-group" hidden>
                                            <input type="text" id="text-input" name="status_akun" value="1" required
                                                placeholder="Text" class="form-control">
                                            <input type="text" id="text-input" name="id_role" value="2" required
                                                placeholder="Text" class="form-control">
                                        </div>
                                        <!-- /input hidden -->

                                        <div class="form-group row">
                                            <div class="col-sm-10 mt-3">
                                                <button type="submit" style="width:20%;"
                                                    class="btn custom-btn mr-2">Submit</button>
                                                <button type="reset" style="width:20%;"
                                                    class="btn btn-danger">Reset</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
</div>
</div><!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->