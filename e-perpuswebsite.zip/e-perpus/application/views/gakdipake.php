<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Tambah Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">

                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Tambah </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <form action="<?= base_url('admin/peminjaman/InputProses') ?>" method="post"
                            enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                class=" form-control-label">Kode Pinjam</label>
                                            </div>
                                            <div class="col-8"><input type="text" value="<?= $pnj; ?>" readonly
                                                id="text-input" name="kd_pinjam" class="form-control" required></div>

                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Nama Peminjam
                                                </label></div>
                                                <div class="col-8">
                                                    <select name="id_anggota" id="id_anggota" class="form-control" required>
                                                        <option value="">--- Pilih Peminjam ---</option>
                                                        <?php foreach ($peminjam as $dataPnj) : ?>
                                                            <option value="<?= $dataPnj->id_user ?>">
                                                                <?= $dataPnj->no_user ?> - <?= $dataPnj->nama_user ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="row form-group">
                                                    <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">Tanggal Pinjam</label></div>
                                                        <div class="col-8"><input  type="date" value="<?= date('Y-m-d');?>" n id="text-input" name="tanggal_pinjam" required
                                                            placeholder="Text" class="form-control"></div>
                                                        </div>
                                                        <div class="row form-group">
                                                            <div class="col col-md-4"><label for="text-input"
                                                                class=" form-control-label">Durasi
                                                            </label></div>
                                                            <div class="col-8"><input type="number" id="text-input" name="durasi"
                                                                required placeholder="Contoh : 3 (hari)" class="form-control"></div>
                                                            </div>
                                                            


                                                        </div>
                                                        <div class="col-lg-6 ">
                                                            <div class="row form-group">
                                                                <div class="col col-md-4"><label for="text-input"
                                                                    class=" form-control-label">Petugas
                                                                </label></div>
                                                                <div class="col-8"><input type="text" id="text-input" 
                                                                    required readonly value="<?=  $this->session->userdata('nama_user') ?>" class="form-control">
                                                                </div>
                                                            </div>
                                                            <div class="row form-group">
                                                                <div class="col col-md-4"><label for="text-input"
                                                                    class=" form-control-label">Pilih Buku
                                                                </label></div>
                                                                <div class="col-8">
                                                                    <input hidden type="text" class="form-control" autocomplete="off" name="id_buku" id="buku-search" placeholder="Contoh ID Buku : BK001" type="text" value="">
                                                                   <span class="input-group-btn" >
                                                                    <a data-toggle="modal" style="width: 100%;" data-target="#TableBuku" class="btn btn-warning"><i class="fa fa-search"> Pilih Buku</i></a>
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-12 mt-3">
                                                        <p class="text-dark"  ><b >Data</b> Buku</p>
                                                        <div class="section-divider mt-3"></div>
                                                        <div id="result_tunggu_buku"> <p style="color:red">* Belum Ada Hasil</p></div>
                                                        <div id="result_buku"></div>
                                                       
                                                    </div>

                                                    <div class="col-lg-6 ">
                                                    </div>
                                                    <div class="col-lg-6 ">


                                                        <div class="form-group row" >
                                                            <div class="col-sm-12 mt-3" style="text-align:right;">
                                                                <button type="submit" style="width:20%;"
                                                                class="btn custom-btn mr-2">Submit</button>
                                                                <button type="reset" style="width:20%;"
                                                                class="btn btn-danger">Reset</button>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                        </form>
                                    </div>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .animated -->
    </div>


    <!-- /.site-footer -->
</div>
<!-- /#right-panel -->

