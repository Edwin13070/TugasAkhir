<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <!-- Widgets  -->
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-five">
                            <div class="stat-icon dib flat-color-1">
                                <i class="fa fa-users"></i>
                            </div>
                            <div class="stat-content">
                                <div class="text-left dib">
                                    <div class="stat-text"><span class="count"><?= $anggota?></span></div>
                                    <div class="stat-heading">Anggota</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-five">
                            <div class="stat-icon dib flat-color-2">
                                <i class="fa fa-book"></i>
                            </div>
                            <div class="stat-content">
                                <div class="text-left dib">
                                    <div class="stat-text"><span class="count"><?= $buku?></span></div>
                                    <div class="stat-heading">Buku</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-five">
                            <div class="stat-icon dib flat-color-3">
                                <i class="fa fa-file-text"></i>
                            </div>
                            <div class="stat-content">
                                <div class="text-left dib">
                                    <div class="stat-text"><span class="count"><?= $pinjam ?></span></div>
                                    <div class="stat-heading">Peminjaman</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-five">
                            <div class="stat-icon dib flat-color-4">
                                <i class="ti-layers-alt"></i>
                            </div>
                            <div class="stat-content">
                                <div class="text-left dib">
                                    <div class="stat-text"><span class="count"><?= $kmb ?></span></div>
                                    <div class="stat-heading">Pengembalian</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Widgets -->


        <!--  /Traffic -->
        <div class="clearfix"></div>
        <!-- Orders -->
        <div class="orders">
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-header" style="text-align: left; padding: 10px 0;">
                            <label class="card-title ml-3" id="tanggal" style="margin: 0;"></label>
                        </div>

                         <div class="card-body">
                            <table id="bootstrap-data-table" class="table table-stred table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width:2%">No.</th>
                                        <th>Nama anggota</th>
                                        <th>Tgl Pinjam</th>
                                        <th>Durasi</th>
                                        <th>Status</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $no=1;   
                                    foreach($view_pnj as $dataPeminjam) :
                                        ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <td><?= $dataPeminjam->nama_anggota ?></td>
                                            <td><?= date('d-m-Y', strtotime($dataPeminjam->tanggal_pinjam)) ?></td>
                                            <td><?= $dataPeminjam->durasi ?></td>
                                            <?php if (empty($dataPeminjam->kd_pinjam)){ ?>
                                                <td>Menunggu Konfirmasi</td>
                                            <?php }else{ ?>
                                                <td><?= $dataPeminjam->kd_pinjam ?></td>
                                            <?php } ?>
                                            <?php if ($dataPeminjam->status_pinjam =="1"){ ?>
                                                <td class="text-danger">Pending</td>
                                            <?php }else if($dataPeminjam->status_pinjam =="2"){ ?>
                                                <td class="text-primary">Dipinjam</td>
                                            <?php } ?>

                                            
                                            

                                            <td class=" text-center">
                                                <a href="<?= base_url('admin/peminjaman/detailPnj/'. $dataPeminjam->id_pinjam ) ?>" class="btn btn-sm mb-1 custom-btn"><i class="fa fa-eye mr-1"></i>Lihat Detail</a>

                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    </div> <!-- /.card -->
                </div> <!-- /.col-lg-8 -->


            </div>
        </div>
        <!-- /.orders -->

        <!-- /To Do and Live Chat -->
        <!-- Calender Chart Weather  -->

    </div>
    <!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->

<script>
    // Mendapatkan tanggal hari ini
    var today = new Date();

    // Mendapatkan nama bulan
    var monthNames = ["Januari", "Februabri", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
    var month = monthNames[today.getMonth()];

    // Mendapatkan tanggal, bulan, dan tahun
    var day = today.getDate();
    var year = today.getFullYear();

    // Format tanggal sebagai "dd Mmm yyyy"
    var formattedDate = day + ' ' + month + ' ' + year;

    // Menampilkan tanggal dalam elemen dengan id "tanggal"
    document.getElementById("tanggal").innerHTML = "<b>Permintaan Peminjaman : </b>" + formattedDate;
</script>