<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Profil Akun</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <?php
                    foreach ($profil as $dataProfil) :
                        ?>
                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Edit</strong> Profil
                    </div>
                    <div class="card-body card-block">
                        <?php if($menu=="Anggota"){ ?>
                        <form action="<?= base_url('admin/anggota/editAkun') ?>" method="post"
                            enctype="multipart/form-data" class="form-horizontal">
                            <?php } else { ?>
                            <form action="<?= base_url('admin/petugas/editAkun') ?>" method="post"
                                enctype="multipart/form-data" class="form-horizontal">
                                <?php } ?>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label"><?php if($menu == "Anggota"){
                                            echo"NIS siswa";}else{echo "NIK Petugas"; } ?></label></div>
                                                <div class="col-md-8"><input type="text" id="text-input" name="no_user"
                                                        readonly value="<?= $dataProfil->no_user ?>"
                                                        class="form-control" required></div>
                                                <div class="col-md-8" hidden><input type="text" id="text-input"
                                                        name="id_user" readonly value="<?= $dataProfil->id_user ?>"
                                                        class="form-control" required></div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">Nama</label></div>
                                                <div class="col-md-8"><input type="text" id="text-input"
                                                        name="nama_user" value="<?= $dataProfil->nama_user ?>" required
                                                        placeholder="Text" class="form-control"></div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col col-md-4"><label class=" form-control-label">Jenis
                                                        Kelamin</label>
                                                </div>
                                                <div class="col-md-8">
                                                    <?php if ($dataProfil->jenkel == "Laki-laki") { ?>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="jenkel"
                                                            id="jenkel" checked="checked" value="Laki-laki" required>
                                                        <label class="form-check-label"
                                                            for="inlineRadio1">Laki-laki</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="jenkel"
                                                            id="jenkel" value="Perempuan">
                                                        <label class="form-check-label"
                                                            for="inlineRadio2">Perempuan</label>
                                                    </div>
                                                    <?php } else if ($dataProfil->jenkel == "Perempuan") { ?>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="jenkel"
                                                            id="jenkel" value="Laki-laki" required>
                                                        <label class="form-check-label"
                                                            for="inlineRadio1">Laki-laki</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="jenkel"
                                                            id="jenkel" checked="checked" value="Perempuan">
                                                        <label class="form-check-label"
                                                            for="inlineRadio2">Perempuan</label>
                                                    </div>
                                                    <?php } else { ?>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="jenkel"
                                                            id="jenkel" value="Laki-laki" required>
                                                        <label class="form-check-label"
                                                            for="inlineRadio1">Laki-laki</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="jenkel"
                                                            id="jenkel" value="Perempuan">
                                                        <label class="form-check-label"
                                                            for="inlineRadio2">Perempuan</label>
                                                    </div>
                                                    <?php } ?>

                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">Tempat
                                                        Lahir</label></div>
                                                <div class="col-md-8"><input type="text" id="text-input"
                                                        name="tempat_lahir" value="<?= $dataProfil->tempat_lahir ?>"
                                                        required placeholder="Text" class="form-control"></div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="tgl_lahir"
                                                        class="form-control-label">Tanggal
                                                        Lahir</label></div>
                                                <div class="col-md-8">
                                                    <?php
                                            // Mengubah format tanggal PHP ke dalam format yang sesuai dengan input tanggal
                                            $tgl_lahir_php = date("Y-m-d", strtotime($dataProfil->tgl_lahir));
                                            ?>
                                                    <input type="date" id="tgl_lahir" name="tgl_lahir"
                                                        value="<?= $tgl_lahir_php ?>" required class="form-control">
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="alamat" class="col-md-4 col-form-label">Alamat</label>
                                                <div class="col-md-8">
                                                    <textarea class="form-control" name="alamat" id="alamat"
                                                        name="alamat"><?= $dataProfil->alamat; ?></textarea>
                                                </div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">No.telp</label></div>
                                                <div class="col-md-8"><input type="text" id="text-input" name="no_telp"
                                                        value="<?= $dataProfil->no_telp ?>" required placeholder="Text"
                                                        class="form-control"></div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">

                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">Username</label></div>
                                                <div class="col-md-8"><input type="text" id="text-input" name="username"
                                                        value="<?= $dataProfil->username ?>" required placeholder="Text"
                                                        class="form-control"></div>
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">Password</label></div>
                                                <div class="col-md-8">
                                                    <input type="password" class="form-control" name="password"
                                                        id="password">
                                                    <input type="hidden" id="text-input" name="passwordLama"
                                                        value="<?= $dataProfil->password; ?>" class="form-control"
                                                        required>
                                                    <span class="text-danger">*Kosongkan password jika tidak
                                                        diganti</span>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">Konfirmasi
                                                        Password</label></div>
                                                <div class="col-md-8">
                                                    <input type="password" class="form-control" name="konfirmasiPass"
                                                        id="password">
                                                    <span class="text-danger">*Kosongkan password jika tidak
                                                        diganti</span>
                                                </div>
                                            </div>

                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="file-input"
                                                        class=" form-control-label">Upload
                                                        Foto</label></div>
                                                <div class="col-md-8">
                                                    <input type="hidden" name="fileLama" class="form-control"
                                                        value="<?= $dataProfil->foto;  ?>" required>
                                                    <?php if(!empty($dataProfil->foto)) { ?>
                                                    <img class="rounded mb-2"
                                                        src="<?= base_url()?>/api/upload/<?= $dataProfil->foto ?>"
                                                        width="90px" height="110px">
                                                    <?php }else { ?>
                                                    <img class="rounded mb-2"
                                                        src="<?= base_url()?>/api/upload/defaultUser.jpeg" width="90px"
                                                        height="110px">
                                                    <?php } ?>
                                                    <input type="file" name="foto" class="form-control-file" id="foto">

                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-10 mt-3">
                                                    <button type="submit" style="width:20%;"
                                                        class="btn custom-btn mr-2">Edit</button>
                                                    <button type="reset" style="width:20%;"
                                                        class="btn btn-danger">Reset</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>


</div>

<?php endforeach;?>
</div><!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->