<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Edit Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">

                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Edit </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <?php foreach ($pinjam as $dataPeminjam): ?>
                           <form action="<?= base_url('admin/peminjaman/editPeminjaman') ?>" method="post"
                            enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                class=" form-control-label">Kode Pinjam</label>
                                            </div>
                                            <div class="col-8">
                                                <input type="text" readonly id="text-input" name="kd_pinjam" value="<?= $dataPeminjam->kd_pinjam; ?>" class="form-control" required>
                                                <input hidden type="text" readonly id="text-input" name="id_pinjam" value="<?= $dataPeminjam->id_pinjam; ?>" class="form-control" required>
                                            </div>

                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                class=" form-control-label">Nama Peminjam
                                            </label></div>
                                            <div class="col-8">
                                                <label class="form-control" readonly>
                                                <?php foreach ($peminjam as $key) : ?>
                                                    <?php
                                                    if ($dataPeminjam->id_anggota == $key->id_user) {
                                                        echo $key->no_user.' - '.$key->nama_user;
                                                            break; // Hentikan loop setelah menemukan yang sesuai
                                                        }
                                                        ?>
                                                    <?php endforeach; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                class=" form-control-label">Tanggal Pinjam</label></div>
                                                <div class="col-8"><input  type="date"  id="text-input" value="<?= $dataPeminjam->tanggal_pinjam; ?>" name="tanggal_pinjam" required
                                                    placeholder="Text" class="form-control"></div>
                                                </div>
                                                <div class="row form-group">
                                                    <div class="col col-md-4"><label for="text-input"
                                                        class=" form-control-label">Durasi
                                                    </label></div>
                                                    <div class="col-8"><input type="number" value="<?= $dataPeminjam->durasi; ?>" id="text-input" name="durasi"
                                                        required placeholder="Contoh : 3 (hari)" class="form-control"></div>
                                                    </div>



                                                </div>
                                                <div class="col-lg-6 ">
                                                    <div class="row form-group">
                                                        <div class="col col-md-4"><label for="text-input"
                                                            class=" form-control-label">Petugas
                                                        </label></div>
                                                        <div class="col-8"><input type="text" id="text-input" 
                                                            required readonly value="<?=  $this->session->userdata('nama_user') ?>" class="form-control">
                                                        </div>
                                                    </div>

                                                </div>
                                                <div class="col-lg-12 mt-3">
                                                    <p class="text-dark"><b>Data</b> Buku</p>
                                                    <div class="section-divider mt-3"></div>
                                                    <table class="table table-striped">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>Kode</th>
                                                                <th>Judul</th>
                                                                <th>Penerbit</th>
                                                                <th>Tahun</th>
                                                                <th>Tgl Pinjam</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php 
                                                            $no=1;
                                                            foreach($buku as $detailBuku): ?>
                                                                <tr>
                                                                    <td><?= $no++; ?></td>
                                                                    <td><?= $detailBuku->kd_buku; ?></td>
                                                                    <td><?= $detailBuku->judul; ?></td>
                                                                    <td><?= $detailBuku->penerbit; ?></td>
                                                                    <td><?= $detailBuku->thn_terbit; ?></td>
                                                                    <td><?= $detailBuku->tanggal_pinjam; ?></td>




                                                                </tr>
                                                            <?php endforeach; ?>
                                                        </tbody>
                                                    </table>

                                                </div>




                                                <div class="col-lg-6 ">
                                                </div>
                                                <div class="col-lg-6 ">


                                                    <div class="form-group row" >
                                                        <div class="col-sm-12 mt-3" style="text-align:right;">
                                                            <input type="hidden" name="tambah" value="tambah">
                                                            <button type="submit" style="width:20%;"
                                                            class="btn custom-btn mr-2">Edit</button>
                                                            <button type="reset" style="width:20%;"
                                                            class="btn btn-danger">Reset</button>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>

                                    </form>
                                </div>

                            </div>

                        </div>
                    <?php endforeach; ?>


                </div>
            </div>
        </div>
    </div>
</div><!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->

