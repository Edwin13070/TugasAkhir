<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Data <?= $menu; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data <?= $menu; ?></strong>
                    </div>
                    <div class="card-body">
                        <table id="bootstrap-data-table" class="table table-stred table-bordered">
                            <thead>
                                <tr>
                                    <th >No.</th>
                                    <th style="width:10%">Kode Pinjam </th>
                                    <th >Nama </th>
                                    <th >Tgl. Pinjam</th>
                                    <th>Durasi</th>
                                    <th>Tgl. Kembali</th>
                                    <th>Denda</th>
                                    <th  style="width:18%;text-align: center;">Aksi</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no=1; 
                                foreach ($pengembalian as $dataPengembalian):  
                                    ?>
                                    <tr>
                                        <td><?= $no++; ?></td>
                                        <td><?=  $dataPengembalian->kd_pinjam ?></td>
                                        <td><?=  $dataPengembalian->nama_anggota?></td>
                                   <td><?= date('d M Y', strtotime($dataPengembalian->tanggal_pinjam)) ?></td>
<td><?= $dataPengembalian->durasi ?> Hari</td>
<td><?= date('d M Y', strtotime($dataPengembalian->tgl_pengembalian)) ?></td>

                                        <?php if (!empty($dataPengembalian->id_denda)){ ?>
                                            <td class="text-danger">Rp. <?= number_format($dataPengembalian->total_denda, 0, ',', '.') ?></td>
                                        <?php } else { ?>
                                            <td>Rp. 0</td>
                                        <?php } ?>

                                        <td class=" text-center">
                                           <a class="btn btn-sm mb-1" style="background:#d0d2d3;"
                                                href="<?= base_url('admin/pengembalian/editData/' . $dataPengembalian->id_pengembalian) ?>"><i
                                                class="fa fa-edit"></i></a>
                                           <a href="#deleteModal" class="btn btn-sm mb-1 btn-danger"
                                           data-href="<?= base_url('admin/pengembalian/hapusData/' . $dataPengembalian->id_pengembalian) ?>" data-toggle="modal"
                                           data-target="#deleteModal"><i class="fa fa-trash-o"></i></a>

                                           <a href="<?= base_url('admin/pengembalian/detailPnj/'. $dataPengembalian->id_pengembalian ) ?>" class="btn btn-sm mb-1 custom-btn"><i class="fa fa-eye"></i></a>
                                           <a href="<?= base_url('laporan/laporan/lap_detailPnj/'. $dataPengembalian->id_pengembalian ) ?>" target="_blank" class="btn btn-sm mb-1 btn-warning"><i class="fa fa-print"></i></a>



                                       </td>

                                   </tr>
                               <?php endforeach;?>
                           </tbody>
                       </table>
                   </div>
               </div>
           </div>


       </div>
   </div><!-- .animated -->
   <!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->

<!-- Delete Modal-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
        </div>
        <div class="modal-body">Yakin ingin menghapus data ini?</div>
        <div class="modal-footer">
            <button class="btn btn-dark" type="button" data-dismiss="modal">Batal</button>
            <a class="btn btn-yes" style="background:#ed212a; color:white;">Hapus</a>
        </div>
    </div>
</div>
</div>