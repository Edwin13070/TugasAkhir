<div class="breadcrumbs">
    <!-- Bagian HTML yang sudah ada tetap sama -->
</div>

<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title"><?= $menu; ?> Peminjaman</strong>
                    </div>
                    <div class="card-body">
                        <form class="mb-2" method="get" action="proses_pencarian.php">
                            <!-- Form untuk range tanggal -->
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="tanggal_mulai">Tanggal Mulai</label>
                                    <input type="date" class="form-control" id="tanggal_mulai" name="tanggal_mulai" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="tanggal_selesai">Tanggal Selesai</label>
                                    <input type="date" class="form-control" id="tanggal_selesai" name="tanggal_selesai" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary">Cari</button>
                        </form>

                        <?php
                        if ($_SERVER["REQUEST_METHOD"] == "GET") {
                            if (isset($_GET["tanggal_mulai"]) && isset($_GET["tanggal_selesai"])) {
                                $tanggal_mulai = $_GET["tanggal_mulai"];
                                $tanggal_selesai = $_GET["tanggal_selesai"];

                                // Lakukan pencarian berdasarkan range tanggal
                                echo "<p>Anda mencari laporan untuk range tanggal $tanggal_mulai sampai $tanggal_selesai.</p> <a class='btn btn-sm custom-btn' href='" . base_url('laporan/laporan/data_lapPnj/' . $tanggal_mulai . '/' . $tanggal_selesai) . "' target='_blank'><i class='fa fa-print mr-2'></i>Cetak</a>";

                                // Tambahkan logika sesuai kebutuhan, misalnya query database atau pemrosesan data
                            } else {
                                echo "<p>Silakan isi tanggal mulai dan tanggal selesai.</p>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .animated -->
    <!-- .animated -->
</div>
