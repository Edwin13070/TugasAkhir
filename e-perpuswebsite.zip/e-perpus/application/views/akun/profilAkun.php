<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Profil Akun</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <?php
                foreach ($profil as $dataProfil) :
            ?>
    <?= $this->session->flashdata('pesan'); ?>
    <div class="animated fadeIn">
        <div class="row">

            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title"> <?= $menu; ?></strong>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4">
                                <section class="card">
                                    <div class="card-body text-center">
                                        <?php if(!empty($dataProfil->foto)) { ?>
                                        <img src="<?= base_url()?>/api/upload/<?= $dataProfil->foto ?>" alt=" avatar"
                                            class="rounded-circle img-fluid" style="width: 150px;">
                                        <?php } else { ?>
                                        <img src="<?= base_url()?>/api/upload/defaultUser.jpeg" alt=" avatar"
                                            class="rounded-circle img-fluid" style="width: 150px;">
                                        <?php } ?>
                                        </a>
                                        <h5 class="my-3 text-align"><?= $dataProfil->nama_user ?></h5>
                                        <p class="text-muted" style="margin-top:-15px;">Admin</p>
                                    </div>
                                    <a href="<?= base_url('akun/settingAkun') ?>" type="button"
                                        class="btn custom-btn ml-3 mb-3 mr-3" style="margin-top:-15px;"><i
                                            class="fa fa-edit"></i>&nbsp; Edit Profil</a>
                                </section>
                            </div>
                            <div class="col-lg-8 ">
                                <section class="card">
                                    <div class="card-body text-secondary">
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">Petugas</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?= $dataProfil->nama_user ?></p>
                                                </div>
                                            </div>
                                            <hr>

                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">No. Petugas</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?= $dataProfil->no_user ?></p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">Jenis Kelamin</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?= $dataProfil->jenkel ?></p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">TTL</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0">
                                                        <?php
                                    // Mengubah format tanggal dari "Y-m-d" ke "d F Y"
                                    $tgl_lahir = date("d F Y", strtotime($dataProfil->tgl_lahir));
                                    echo $dataProfil->tempat_lahir . ", " . $tgl_lahir;
                                    ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">Alamat</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?= $dataProfil->alamat ?></p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">No.Telp</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0"><?= $dataProfil->no_telp ?></p>
                                                </div>
                                            </div>
                                            <hr>
                                            <div class="row">
                                                <div class="col-sm-3">
                                                    <p class="mb-0">Tanggal Aktif</p>
                                                </div>
                                                <div class="col-sm-9">
                                                    <p class="text-muted mb-0">
                                                        <?php
                                    // Mengubah format tanggal dari "Y-m-d" menjadi "d F Y"
                                    $tgl_dibuat = date("d F Y", strtotime($dataProfil->tgl_dibuat));
                                    echo $tgl_dibuat;
                                    ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
    <?php endforeach; ?>
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->