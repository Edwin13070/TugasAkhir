<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Data <?= $menu; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data <?= $menu; ?></strong>
                    </div>
                    <div class="card-body">
                            <table id="bootstrap-data-table" class="table table-stred table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width:1px">No.</th>
                                        <th>Laporan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Laporan Data User</td>
                                        <td><a class="btn btn-sm custom-btn" href="<?= base_url('laporan/laporan/Laporan_userAnggota/') ?>" target="_blank"><i class="fa fa-print mr-2"></i>Cetak</a></td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Laporan Data Buku</td>
                                        <td><a class="btn btn-sm custom-btn" href="<?= base_url('laporan/laporan/Laporan_buku/') ?>" target="_blank"><i class="fa fa-print mr-2"></i>Cetak</a></td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>Laporan Peminjaman</td>
                                        <td><a class="btn btn-sm custom-btn" href="<?= base_url('laporan/laporan/Laporan_peminjaman/') ?>">Pilih disini</a></td>
                                    </tr>
                                   <tr>
                                        <td>4</td>
                                        <td>Laporan Pengembalian</td>
                                        <td><a class="btn btn-sm custom-btn" href="<?= base_url('laporan/laporan/Laporan_pengembalian/') ?>">Pilih disini</a></td>
                                    </tr>
                                </tbody>
                           </table>
                       </div>
                   </div>
               </div>


           </div>
       </div><!-- .animated -->
       <!-- .animated -->
   </div>


   <!-- /.site-footer -->
