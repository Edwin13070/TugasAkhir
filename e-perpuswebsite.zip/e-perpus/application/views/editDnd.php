<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Tambah Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">

                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Tambah </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <?php foreach($denda as $dataDenda): ?>
                            <form action="<?= base_url('admin/denda/editDenda') ?>" method="post"
                                enctype="multipart/form-data" class="form-horizontal">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-lg-6">
                                           <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                class=" form-control-label">Kode Denda</label>
                                            </div>
                                            <div class="col-8"><input type="text" value="<?= $dataDenda->kd_denda; ?>" readonly
                                                id="text-input" name="kd_denda" class="form-control" required></div>
                                                <input hidden type="text" name="id_denda" value="<?= $dataDenda->id_denda?>" id="">
                                            </div>

                                             <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                class=" form-control-label">Jenis Denda</label>
                                            </div>
                                            <div class="col-8"><input type="text" value="<?= $dataDenda->jns_denda; ?>" readonly
                                                id="text-input" name="jns_denda" class="form-control" required></div>
                                            
                                            </div>
                                            <div class="row form-group">
                                                <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Keterangan</label></div>
                                                    <div class="col-8"><input type="text" value="<?= $dataDenda->keterangan; ?>" value="<?= $dataDenda->keterangan; ?>"   id="text-input" autocomplete="off" name="keterangan"
                                                        required placeholder="Contoh : Denda Telat" class="form-control"></div>
                                                    </div>
                                                    <div class="row form-group">
                                                        <div class="col col-md-4"><label for="text-input" class=" form-control-label">Nominal</label></div>
                                                        <div class="col-8"><input type="text" autocomplete="off" id="text-input-nominal" value="<?= $dataDenda->nominal; ?>"  name="nominal" required placeholder="Contoh : 500" class="form-control"></div>
                                                    </div>

                                                    <div class="form-group row">
                                                        <div class="col-sm-10 mt-3">
                                                            <button type="submit" style="width:20%;"
                                                            class="btn custom-btn mr-2">Submit</button>
                                                            <button type="reset" style="width:20%;"
                                                            class="btn btn-danger">Reset</button>
                                                        </div>
                                                    </div><br><br><br><br>
                                                </div>

                                                <div class="col-lg-6 ">


                                                    <!-- /input hidden -->



                                                </div>
                                            </div>
                                        </div>

                                    </form>
                                </div>

                            <?php endforeach;?>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->