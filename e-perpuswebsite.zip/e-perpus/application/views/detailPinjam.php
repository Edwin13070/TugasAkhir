<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Detail Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">
                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Detail </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <a href="<?= base_url('admin/peminjaman/') ?>" style="font-size:13px" type="button" class="btn custom-btn ml-3 mb-1" ><i class="fa fa-arrow-left"></i>&nbsp; Kembali</a>
                        <form action="<?= base_url('admin/peminjaman/InputProses') ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body">
                                <?php foreach ($pinjam as $dataPeminjam): ?>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="kode_pinjam" class="form-control-label">Kode Pinjam:</label>
                                                <?php
                                                    if (!empty($dataPeminjam->kd_pinjam )) {
                                                        ?>
                                                            <label class="form-control">
                                                    <strong><?= $dataPeminjam->kd_pinjam?></strong>
                                                </label>

                                                        <?php
                                                    }else{
                                                       ?>
                                                            <label class="form-control text-warning">
                                                                Menunggu Konfirmasi
                                                            </label>
                                                        <?php
                                                    }
                                                ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="nama_peminjam" class="form-control-label">Nama Peminjam:</label>
                                                <label class="form-control">
                                                    <?php foreach ($peminjam as $key) : ?>
                                                        <?php
                                                        if ($dataPeminjam->id_anggota == $key->id_user) {
                                                            echo $key->nama_user;
                                                            break; // Hentikan loop setelah menemukan yang sesuai
                                                        }
                                                        ?>
                                                    <?php endforeach; ?>
                                                </label>
                                            </div>
                                            <div class="form-group">
                                                <label for="nis" class="form-control-label">NIS:</label>
                                                <label class="form-control">
                                                    <?php foreach ($peminjam as $key) : ?>
                                                        <?php
                                                        if ($dataPeminjam->id_anggota == $key->id_user) {
                                                            echo $key->no_user;
                                                            break; // Hentikan loop setelah menemukan yang sesuai
                                                        }
                                                        ?>
                                                    <?php endforeach; ?>
                                                </label>
                                            </div>
                                            <div class="form-group">
                                                <label for="email" class="form-control-label">Email:</label>
                                                <label class="form-control">
                                                    <?php foreach ($peminjam as $key) : ?>
                                                        <?php
                                                        if ($dataPeminjam->id_anggota == $key->id_user) {
                                                            echo $key->email;
                                                            break; // Hentikan loop setelah menemukan yang sesuai
                                                        }
                                                        ?>
                                                    <?php endforeach; ?>
                                                </label>
                                            </div>
                                            
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="form-group">
                                                <label for="telp" class="form-control-label">Telp:</label>
                                                <label class="form-control">
                                                    <?php foreach ($peminjam as $key) : ?>
                                                        <?php
                                                        if ($dataPeminjam->id_anggota == $key->id_user) {
                                                            echo $key->no_telp;
                                                            break; // Hentikan loop setelah menemukan yang sesuai
                                                        }
                                                        ?>
                                                    <?php endforeach; ?>
                                                </label>
                                            </div>
                                            <div class="form-group">
                                                <label for="tgl_pinjam" class="form-control-label">Tgl Pinjam:</label>
                                                <?php
                                                // Ubah format tanggal dari Y-m-d ke d/m/Y
                                                $tgl_pinjam = date('d/m/Y', strtotime($dataPeminjam->tanggal_pinjam));
                                                ?>
                                                <label class="form-control"><?= $tgl_pinjam ?></label>
                                            </div>

                                            <div class="form-group">
                                                <label for="durasi" class="form-control-label">Durasi:</label>
                                                <label class="form-control"><?= $dataPeminjam->durasi ?> Hari</label>
                                            </div>
                                             <?php
                                                    if (!empty($dataPeminjam->kd_pinjam )) {
                                                       
                                                        ?>
                                                            <div class="form-group">
                                                                <label for="petugas" class="form-control-label">Petugas:</label>
                                                                <label class="form-control">
                                                                    <?php foreach ($peminjam as $key) : ?>
                                                                        <?php
                                                                        if ($dataPeminjam->id_admin == $key->id_user) {
                                                                            echo $key->nama_user;
                                                                            break; // Hentikan loop setelah menemukan yang sesuai
                                                                        }
                                                                        ?>
                                                                    <?php endforeach; ?>
                                                                </label>
                                                            </div>
                                                        <?php
                                                    }else{
                                                       ?>
                                                            
                                                        <?php
                                                    }
                                                ?>
                                            
                                        </div>
                                <?php endforeach; ?>
                                         <div class="col-lg-12 mt-3">
                                        <p class="text-dark"><b>Data</b> Buku</p>
                                        <div class="section-divider mt-3"></div>
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>No</th>
                                                    <th>Judul</th>
                                                    <th>Penerbit</th>
                                                    <th>Tahun</th>
                                                    <?php
                                                        if (!empty($dataPeminjam->kd_pinjam )) {
                                                           
                                                            ?>
                                                                <th>Deadline</th>
                                                                <th>Status</th>
                                                            <?php
                                                        }else{
                                                           ?>

                                                            <?php
                                                        }
                                                    ?>
                                                   
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $no=1;
                                                foreach($buku as $detailBuku): ?>
                                                    <tr>
                                                        <td><?= $no++; ?></td>
                                                        <td><?= $detailBuku->judul; ?></td>
                                                        <td><?= $detailBuku->penerbit; ?></td>
                                                        <td><?= $detailBuku->thn_terbit; ?></td>

                                                        <?php
                                                        if (!empty($dataPeminjam->kd_pinjam )) {
                                                           
                                                            ?>
                                                                <?php
                                                        // Ubah format tanggal dari Y-m-d ke d/m/Y
                                                        $tgl_pinjam = date('d/m/Y', strtotime($detailBuku->deadline_kembali));
                                                        ?>
                                                        <td><?= $tgl_pinjam; ?></td>
                                                        <?php 
                                                            $tglkbl = $detailBuku->deadline_kembali;
                                                            $tglIni = date('Y-m-d'); // Mengambil tanggal saat ini dalam format 'Y-m-d'

                                                           if ($dataPeminjam->status_pinjam == 2 && strtotime($tglIni) > strtotime($tglkbl)) {
                                                                $status1 = "0";
                                                                $status = "Belum Dikembalikan";
                                                                
                                                                // Menghitung selisih dalam detik
                                                                $selisihDetik = strtotime($tglIni) - strtotime($tglkbl);
                                                                
                                                                // Mengonversi selisih dalam detik menjadi hari
                                                                $deadline = floor($selisihDetik / (60 * 60 * 24));
                                                                
                                                                // Menggabungkan teks dengan nilai deadline
                                                                $statustlt = $deadline ;
                                                            }else{
                                                                $status1="1";
                                                                $status="Masa Peminjaman";
                                                                $statustlt="";
                                                            }
                                                        ?>

                                                         <td <?= ($status1 == 1) ? 'class="text-success"' : 'class="text-danger"' ?>>
                                                            <?= $status; ?>
                                                            <?php if (!empty($statustlt)) : ?>
                                                                <br>Peminjam telat <b> <?= $statustlt; ?> Hari</b>
                                                            <?php endif; ?>
                                                        </td>
                                                            <?php
                                                        }else{
                                                           ?>
                                                           
                                                            <?php
                                                        }
                                                    ?>


                                                         

                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    </div>
                                   
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /.animated -->
</div>
<!-- /.content -->
</div>
<!-- /#right-panel -->
