<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Tambah Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">

                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Tambah </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <form action="<?= base_url('admin/kategori/InputProses') ?>" method="post"
                            enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Kategori</label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="nama_ktg"
                                                    required placeholder="Text" class="form-control"></div>
                                        </div>

                                        <div class="form-group row">
                                            <div class="col-sm-10 mt-3">
                                                <button type="submit" style="width:20%;"
                                                    class="btn custom-btn mr-2">Submit</button>
                                                <button type="reset" style="width:20%;"
                                                    class="btn btn-danger">Reset</button>
                                            </div>
                                        </div><br><br><br><br><br><br><br>
                                    </div>

                                    <div class="col-lg-6 ">


                                        <!-- /input hidden -->



                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
</div>
</div><!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->