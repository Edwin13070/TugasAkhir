<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Tambah Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">

                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Tambah </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <form action="<?= base_url('admin/anggota/InputProses') ?>" method="post"
                            enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label"><?php if($menu == "Anggota"){
                                            echo"NIS siswa";}else{echo "NIK Petugas"; } ?></label>
                                            </div>
                                            <div class="col-8"><input type="text" id="text-input" name="no_user"
                                                    class="form-control" required></div>

                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Nama</label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="nama_user"
                                                    required placeholder="Text" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label class=" form-control-label">Jenis
                                                    Kelamin</label></div>
                                            <div class="col-md-8">
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jenkel"
                                                        id="jenkel" value="Laki-laki" required>
                                                    <label class="form-check-label" for="inlineRadio1">Laki-laki</label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input" type="radio" name="jenkel"
                                                        id="jenkel" value="Perempuan">
                                                    <label class="form-check-label" for="inlineRadio2">Perempuan</label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Tempat
                                                    Lahir</label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="tempat_lahir"
                                                    required placeholder="Text" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="tgl_lahir"
                                                    class="form-control-label">Tanggal
                                                    Lahir</label></div>
                                            <div class="col-8">
                                                <input type="date" id="tgl_lahir" name="tgl_lahir" required
                                                    class="form-control">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="alamat" class="col-md-4 col-form-label">Alamat</label>
                                            <div class="col-md-8">
                                                <textarea class="form-control" name="alamat" id="alamat"
                                                    name="alamat"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 ">

                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">No.telp</label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="no_telp"
                                                    required placeholder="Text" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Email</label></div>
                                            <div class="col-8"><input type="email" id="text-input" name="email" required
                                                    placeholder="Text" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Username</label></div>
                                            <div class="col-8"><input type="text" id="text-input" name="username"
                                                    required placeholder="Text" class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Password</label></div>
                                            <div class="col-8">
                                                <input type="password" class="form-control" name="password"
                                                    id="password">

                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="file-input"
                                                    class=" form-control-label">Upload
                                                    Foto</label></div>
                                            <div class="col-md-8">
                                                <input type="file" required name="foto" class="form-control-file"
                                                    id="foto">
                                            </div>
                                        </div>

                                        <!-- Input Hidden -->
                                        <div class="row form-group" hidden>
                                            <input type="text" id="text-input" name="status_akun" value="1" required
                                                placeholder="Text" class="form-control">
                                            <input type="text" id="text-input" name="id_role" value="2" required
                                                placeholder="Text" class="form-control">
                                        </div>
                                        <!-- /input hidden -->

                                        <div class="form-group row">
                                            <div class="col-sm-10 mt-3">
                                                <button type="submit" style="width:20%;"
                                                    class="btn custom-btn mr-2">Submit</button>
                                                <button type="reset" style="width:20%;"
                                                    class="btn btn-danger">Reset</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
</div>
</div><!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->