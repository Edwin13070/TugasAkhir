<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Data <?= $menu; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data <?= $menu; ?></strong>
                    </div>
                    <div class="card-body">
                        <a href="<?= base_url('admin/Petugas/create') ?>" style="font-size:13px" type="button"
                            class="btn custom-btn ml-3 mb-3"><i class="fa fa-plus"></i>&nbsp; Tambah Data</a>

                        <table id="bootstrap-data-table" class="table table-stred table-bordered">
                            <thead>
                                <tr>
                                    <th style="width:1px">No.</th>
                                    <th>Foto</th>
                                    <th>NIK</th>
                                    <th>Nama</th>
                                    <th>level</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Email</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                             $no=1;   
                             foreach($petugas as $dataPetugas) : ?>
                                <tr>
                                    <td><?= $no++; ?></td>
                                    <td class="avatar">
                                        <div class="round-img-center" style="width:70px">
                                            <a href="#"><img class="rounded"
                                                    src="<?= base_url()?>/api/upload/<?= $dataPetugas->foto ?>"
                                                    alt=""></a>
                                        </div>
                                    </td>
                                    <td><?= $dataPetugas->no_user ?></td>
                                    <td><?= $dataPetugas->nama_user ?></td>
                                    <td><?= $dataPetugas->hak_akses ?></td>
                                    <td><?= $dataPetugas->jenkel ?></td>
                                    <td><?= $dataPetugas->email ?></td>
                                    <td class=" text-center">
                                        <?php if ($this->session->userdata('id_user') == $dataPetugas->id_user ): ?>    
                                        <a class="btn btn-sm mb-1" style="background:#d0d2d3;"
                                            href="<?= base_url('admin/Petugas/editData/' . $dataPetugas->id_user) ?>"><i
                                                class="fa fa-edit"></i></a>
                                        <?php endif ?>
                                        <a href="#deleteModal" class="btn btn-sm mb-1 btn-danger"
                                            data-href="<?= base_url('admin/Petugas/hapusData/' . $dataPetugas->id_user) ?>"
                                            data-toggle="modal" data-target="#deleteModal"><i
                                                class="fa fa-trash-o"></i></a>
                                    </td>

                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


        </div>
    </div><!-- .animated -->
    <!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->

<!-- Delete Modal-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
            </div>
            <div class="modal-body">Yakin ingin menghapus data ini?</div>
            <div class="modal-footer">
                <button class="btn btn-dark" type="button" data-dismiss="modal">Batal</button>
                <a class="btn btn-yes" style="background:#ed212a; color:white;">Hapus</a>
            </div>
        </div>
    </div>
</div>