<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="author" >
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title><?= $title; ?></title>
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/my-login.css">
	
</head>

<body class="my-login-page">
	<section class="h-100">
		<div class="container h-100">
			<div class="row justify-content-md-center h-100">
				<div class="card-wrapper">
					<div class="brand" style="width: 80%; margin-top: 70PX;">
						<img src="<?= base_url(); ?>assets/images/logsonew.png" alt="logo" >
					</div>
					<br>
					<div class="card fat" style="margin-top: -40px;">
						<div class="card-body">
							<h4 class="card-title">Login</h4>
							<p></p>
							<form action="<?= base_url('') ?>" method="POST" class="my-login-validation" novalidate="">
								<?= $this->session->flashdata('pesan'); ?>
								<div class="form-group">
									<label for="Username">Username</label>
									<input id="Username" type="text" class="form-control" name="username" value="" required autofocus autocomplete="off">
									<p class="text danger"><?= form_error('username') ?></p>
								</div>

								<div class="form-group">
									<label for="password">Password
									</label>
									<input id="password" type="password" class="form-control" name="password" required >
									<p class="text danger"><?= form_error('password') ?></p>
								</div>
								<div class="form-group m-0">
									<button type="submit" name="login" class="btn btn-dark btn-block">
										Login
									</button>
								</div>
								<div class="mt-4 text-center">
									Copyright @SMKN 1 TRUCUK 2023
								</div>
							</form>

						</div>
					</div>
					<br><br>
				</div>
			</div>
		</div>
	</section>
	
</body>
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="<?= base_url()?>/assets/js/main.js"></script>
</html>
