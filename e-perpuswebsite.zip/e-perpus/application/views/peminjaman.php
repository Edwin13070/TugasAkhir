<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Data <?= $menu; ?></li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data <?= $menu; ?></strong>
                    </div>
                    <div class="card-body">
                        <a href="<?= base_url('admin/peminjaman/create') ?>" style="font-size:13px" type="button"
                            class="btn custom-btn ml-3 mb-3"><i class="fa fa-plus"></i>&nbsp; Tambah Data</a>
                            <a style="font-size:13px; float: right;" href="#SettingPnj" data-href="<?= base_url('admin/peminjaman/hapusData/') ?>" data-toggle="modal"data-target="#SettingPnj"
                            class="mr-3 mb-3"><i class="fa fa-gear"></i>&nbsp; Setting Peminjaman</a>

                            <table id="bootstrap-data-table" class="table table-stred table-bordered">
                                <thead>
                                    <tr>
                                        <th style="width:2%">No.</th>
                                        <th style="width:10%">Kode</th>
                                        <th style="width:10%">Tgl Booking</th>
                                        <th style="width:12%">Tgl Ambil</th>
                                        <th>Nama anggota</th>
                                        <th style="width:5%">Durasi</th>
                                        <th>Status</th>
                                        <th>Keterangan</th>
                                        <th>Konfirmasi </th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $no=1;   
                                    foreach($pinjam as $dataPeminjam) :
                                        ?>
                                        <tr>
                                            <td><?= $no++; ?></td>
                                            <?php if (empty($dataPeminjam->kd_pinjam)){ ?>
                                                <td>Menunggu Konfirmasi</td>
                                            <?php }else{ ?>
                                                <td><?= $dataPeminjam->kd_pinjam ?></td>
                                            <?php } ?>
                                             <td><?= date('d M Y', strtotime($dataPeminjam->tanggal_booking)) ?></td>
                                             <?php if ($dataPeminjam->status_pinjam =="1"){ ?>
                                                <td>-</td>
                                             <?php }else { ?>
                                             <td><?= date('d M Y', strtotime($dataPeminjam->tanggal_pinjam)) ?></td>
                                         <?php } ?>
                                            <td><?= $dataPeminjam->nama_anggota ?></td>
                                            <td><?= $dataPeminjam->durasi ." Hari" ?></td>
                                
                                                     
                                            <?php if ($dataPeminjam->status_pinjam =="1"){ ?>
                                                <td class="text-danger">Pending</td>
                                                 <?php
                                                // Konversi tanggal dari string ke objek DateTime (jika belum dalam format DateTime)
                                                $tanggalPengembalian = new DateTime(); // Tanggal hari ini
                                                $deadlineKembali = new DateTime($dataPeminjam->deadline_kembali);

                                                // Hitung selisih antara dua tanggal
                                                $selisih = $tanggalPengembalian->diff($deadlineKembali);

                                                // Ambil selisih dalam format hari
                                                $keterangan = $selisih->days;

                                                    echo '<td>-</td>';
                                                
                                                ?>        
                                                <td style="width:10%; text-align:center">
                                                    <a style="width:125px;" href="#konfPNJM" class="btn btn-sm mb-1 btn-primary" data-href="<?= base_url('admin/peminjaman/konfPNJ/'. $dataPeminjam->id_pinjam ) ?>" data-toggle="modal"
                                                data-target="#konfPNJM"><i
                                                    style="margin-left:-10px;"
                                                    class="fa fa-sign-in mr-1 "></i>Peminjaman</a>
                                                </td>

                                            <?php }else if($dataPeminjam->status_pinjam =="2"){ ?>
                                                <td class="text-primary">Dipinjam</td>
                                                 <?php
                                                // Konversi tanggal dari string ke objek DateTime (jika belum dalam format DateTime)
                                                $tanggalPengembalian = new DateTime(); // Tanggal hari ini
                                                $deadlineKembali = new DateTime($dataPeminjam->deadline_kembali);

                                                // Hitung selisih antara dua tanggal
                                                $selisih = $tanggalPengembalian->diff($deadlineKembali);

                                                // Ambil selisih dalam format hari
                                                $keterangan = $selisih->days;

                                                if ($tanggalPengembalian > $deadlineKembali) {
                                                    echo '<td class="text-danger">Terlambat</td>';
                                                } else {
                                                    echo '<td class="text-success">Masa Peminjaman</td>';
                                                }
                                                ?>        
                                                <td style="width:10%; text-align:center">
                                                    <a style="width:125px;" href="#konfKMB" class="btn btn-sm mb-1 btn-success" data-href="<?= base_url('admin/peminjaman/konfKMB/'. $dataPeminjam->id_pinjam ) ?>" data-toggle="modal"
                                                data-target="#konfKMB"><i
                                                    class="fa fa-retweet mr-1"></i>Pengembalian</a>
                                                </td>
                                            <?php }else if($dataPeminjam->status_pinjam =="5"){ ?>
                                                <td class="text-primary">Dipinjam</td>
                                                 <?php
                                        
                                               
                                                echo '<td class="text-dark">Menunggu Konfirmasi User</td>';
                                                
                                                ?>        
                                                <td style="width:10%; text-align:center">
                                                  <button style="width:125px;" class="btn btn-sm mb-1 btn-success" data-href="<?= base_url('admin/peminjaman/konfKMB/' . $dataPeminjam->id_pinjam) ?>" data-toggle="modal" data-target="#konfKMB" disabled>
                                                    <i class="fa fa-retweet mr-1"></i>Pengembalian
                                                  </button>
                                                </td>

                                            <?php } ?>


                                                
                                            

                                            <td class=" text-center">
                                                <a class="btn btn-sm mb-1" style="background:#d0d2d3;"
                                                href="<?= base_url('admin/peminjaman/editData/'. $dataPeminjam->id_pinjam ) ?>"><i
                                                class="fa fa-edit"></i></a>
                                                <a href="#deleteModal" class="btn btn-sm mb-1 btn-danger"
                                                data-href="<?= base_url('admin/peminjaman/hapusData/' . $dataPeminjam->id_pinjam) ?>" data-toggle="modal"
                                                data-target="#deleteModal"><i class="fa fa-trash-o"></i></a>

                                                <a href="<?= base_url('admin/peminjaman/detailPnj/'. $dataPeminjam->id_pinjam ) ?>" class="btn btn-sm mb-1 custom-btn"><i class="fa fa-eye"></i></a>

                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>
        </div><!-- .animated -->
        <!-- .animated -->
    </div>


    <!-- /.site-footer -->
</div>
<!-- /#right-panel -->

<!-- Delete Modal-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h5 class="modal-title" id="exampleModalLabel">Hapus Data</h5>
        </div>
        <div class="modal-body">Yakin ingin menghapus data ini?</div>
        <div class="modal-footer">
            <button class="btn btn-dark" type="button" data-dismiss="modal">Batal</button>
            <a class="btn btn-yes" style="background:#ed212a; color:white;">Hapus</a>
        </div>
    </div>
</div>
</div>

<!-- Konfirmasi Peminjaman Modal-->
<div class="modal fade" id="konfPNJM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h5 class="modal-title" id="exampleModalLabel">Confirm</h5>
        </div>
        <div class="modal-body">Anda dapat melihat rincian peminjaman yang diajukan terlebih dahulu. Klik 'Konfirmasi' untuk melanjutkan</div>
        <div class="modal-footer">
            <a class="btn btn-yes btn-primary" style="color:white;">Konfirmasi</a>
        </div>
    </div>
</div>
</div>



<!-- Konfirmasi Pengembalian Modal-->
<div class="modal fade" id="konfKMB" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h5 class="modal-title" id="exampleModalLabel">Confirm</h5>
        </div>
        <div class="modal-body">Lakukan pengecekan buku sebelum konfirmasi pengembalian dilakukan. Klik 'Pengembalian' untuk melanjutkan</div>
        <div class="modal-footer">
            <a class="btn btn-yes btn-success" style="color:white;">Pengembalian</a>
        </div>
    </div>
</div>
</div>



<!-- Konfirmasi Pengembalian Modal -->
<div class="modal fade" id="SettingPnj" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                <h5 class="modal-title" id="exampleModalLabel">Pengaturan Batasan Tanggal Maksimal Peminjaman Dari Hari Yang Berlaku</h5>
            </div>
            <div class="modal-body">
               

                <!-- Kolom input -->
                <div class="form-group">
                    <label for="durasi_booking">Masukkan Durasi Maksimal Peminjaman (dalam Hari)</label>
                    <input type="number" class="form-control" id="durasi_booking" placeholder="Contoh: 7 (untuk 7 hari)">
                </div>
                  <label>Batasan durasi saat ini: <?= $max_hari ?> Hari</label>
            </div>
            <div class="modal-footer">
                <a class="btn btn-yes btn-success"  id="simpan" style="color: white;">Simpan</a>
            </div>
        </div>
    </div>
</div>
