<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">LOGOUT</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
        </div>
        <div class="modal-body">Yakin Akan LogOut?</div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?= base_url('login/logout') ?>">Logout</a>
        </div>
    </div>
</div>
</div>

<!-- Add Modal-->
<div class="modal fade" id="TableBuku" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document" style="max-width: 80%;">
    <div class="modal-content">
        <div class="modal-header">
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <h5 class="modal-title" id="exampleModalLabel">Pilih Buku</h5>
        </div>
        <div id="modal_body" class="modal-body fileSelection1">
           <table id="bootstrap-data-table" class="table table-stred table-bordered">
            <thead>
                <tr>
                    <th style="width:1px">No.</th>
                    <th>Kode</th>
                    <th>Judul</th>
                    <th>Penerbit</th>
                    <th>Stok</th>
                    <th>Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no=1;   
                foreach($buku as $databuku) : ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $databuku->kd_buku ?></td>
                        <td><?= $databuku->judul ?></td>
                        <td><?= $databuku->penerbit ?></td>
                        <td><?= $databuku->stok ?></td>
                        <td><?= $databuku->nama_ktg ?></td>
                        <td class=" text-center">

                            <button class="btn custom-btn" id="Select_File2" data_id="<?= $databuku->kd_buku;?>" data-dismiss="modal" >
                                <i class="fa fa-check"> </i> Pilih Buku
                            </button>

                        </td>

                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button>
    </div>
</div>
</div>
</div>





<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="<?= base_url() ?>/assets/js/main.js"></script>

<!--  Chart js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>

<!--Chartist Chart-->
<script src="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chartist-plugin-legend@0.6.2/chartist-plugin-legend.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery.flot@0.8.3/jquery.flot.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flot-pie@1.0.0/src/jquery.flot.pie.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/flot-spline@0.0.1/js/jquery.flot.spline.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/simpleweather@3.1.0/jquery.simpleWeather.min.js"></script>
<script src="<?= base_url() ?>/assets/js/init/weather-init.js"></script>


<script src="https://cdn.jsdelivr.net/npm/moment@2.22.2/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.js"></script>

<script src="<?= base_url() ?>/assets/js/lib/data-table/datatables.min.js"></script>
<script src="<?= base_url() ?>/assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="<?= base_url() ?>/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="<?= base_url() ?>/assets/js/init/datatables-init.js"></script>

<script src="<?= base_url();?>assets/select2/dist/js/select2.full.min.js"></script>


<script type="text/javascript">


$(function() {
    //Initialize Select2 Elements
    $('.select2').select2();
});



    // Menambahkan event click pada tombol "Pilih Buku"
    $(document).on("click", "#Select_File2", function() {
        // Mendapatkan data ID buku dari atribut data_id
        var kd_buku = $(this).attr("data_id");

        // Melakukan permintaan AJAX untuk mengirim kode buku ke server
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('admin/peminjaman/buku');?>",
            data: 'kode_buku=' + kd_buku,
            beforeSend: function() {
                $("#result_buku").html("");
                $("#result_tunggu_buku").html('<p style="color:green"><blink>tunggu sebentar</blink></p>');
            },
            success: function(html) {
                // Memuat hasilnya ke dalam elemen dengan ID "result_buku"
                $("#result_buku").load("<?= base_url('admin/peminjaman/buku_list');?>");

                // Menghapus pesan "tunggu sebentar"
                $("#result_tunggu_buku").html('');

                // Tutup modal setelah memilih buku
                $("#TableBuku").modal("hide");
            }
        });
    });




    $(document).ready(function(){
    // Menggunakan event 'input' untuk mengubah format saat pengguna mengetikkan
    $('#text-input-nominal').on('input', function(){
        // Mengambil nilai dari input
        var inputVal = $(this).val();
        
        // Menghilangkan karakter selain angka
        var numericVal = inputVal.replace(/\D/g, '');
        
        // Mengubah nilai menjadi format rupiah
        if(numericVal !== ''){
            var nominal = parseInt(numericVal, 10);
            var formattedNominal = 'Rp. ' + nominal.toLocaleString('id-ID');
        } else {
            var formattedNominal = '';
        }
        
        // Mengganti nilai input dengan format rupiah
        $(this).val(formattedNominal);
        
        // Menghapus "Rp." sebelum mengirim nilai
        $(this).closest('form').submit(function() {
            var valueWithoutRp = numericVal;
            $(this).find('[name="nominal"]').val(valueWithoutRp);
        });
    });
});
</script>
<!--Local Stuff-->
<script>
    function searchKategori() {
        var input, filter, select, options, option, i, txtValue;
        input = document.getElementById("kategori_search");
        filter = input.value.toUpperCase();
        select = document.getElementById("id_ktg");
        options = select.getElementsByTagName("option");

        for (i = 0; i < options.length; i++) {
            option = options[i];
            txtValue = option.textContent || option.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                option.style.display = "";
            } else {
                option.style.display = "none";
            }
        }

    // Tampilkan atau sembunyikan <select> berdasarkan hasil pencarian
    if (filter === "") {
        select.style.display = "none";
    } else {
        select.style.display = "block";
    }
}
$('#deleteModal').on('show.bs.modal', function(e) {
    $(this).find('.btn-yes').prop('href', $(e.relatedTarget).data('href'));
});


$('#konfPNJM').on('show.bs.modal', function(e) {
    $(this).find('.btn-yes').prop('href', $(e.relatedTarget).data('href'));
});


$('#konfKMB').on('show.bs.modal', function(e) {
    $(this).find('.btn-yes').prop('href', $(e.relatedTarget).data('href'));
});


$(document).ready(function(){
    $("#buku-search").keyup(function(){
        $.ajax({
            type: "POST",
            url: "<?= base_url('admin/peminjaman/buku') ?>",
            data:'kode_buku='+$(this).val(),
            beforeSend: function(){
                $("#result_tunggu_buku").html('<p style="color:green"><blink>tunggu sebentar</blink></p>');
            },
            success: function(html){
                $("#result_buku").load("<?= base_url('admin/peminjaman/buku_list') ?>");
                $("#result_tunggu_buku").html('');
            }
        });
    });
});

$(document).ready(function(){
    $("#search-box").keyup(function(){
        $.ajax({
            type: "POST",
            url: "<?= base_url('admin/peminjaman/result') ?>",
            data:'no_user='+$(this).val(),
            beforeSend: function(){
                $("#result").html("");
                $("#result_tunggu").html('<p style="color:green"><blink>tunggu sebentar</blink></p>');
            },
            success: function(html){
                $("#result").html(html);
                $("#result_tunggu").html('');
            }
        });
    });
});


function isi_otomatisDenda() {
    var id_denda = $("#id_denda").val();
    $.ajax({
        url: '<?= base_url('admin/pengembalian/tampilDenda') ?>',
        data: "id_denda=" + id_denda,
    }).success(function(data) {
        var json = data,
        obj = JSON.parse(json);
        $('#nominal').val(obj.nominal);

    });
} 


$(document).ready(function () {
    $('#simpan').click(function () {
        var durasi_booking = $('#durasi_booking').val();

        $.ajax({
            type: 'POST',
            url: '<?= base_url('admin/peminjaman/setting_durasi') ?>',
            data: { durasi_booking: durasi_booking },
            success: function (response) {
                // Menampilkan pesan sukses
                $('#myModal').modal('hide'); // Menutup modal
                $('.pesan').html(response); // Menampilkan pesan sukses

                // Refresh halaman
                setTimeout(function () {
                    window.location.reload();
                }, 0); // Refresh halaman setelah 2 detik (sesuaikan dengan preferensi Anda)
            }
        });
    });
});


</script>

</body>

</html>