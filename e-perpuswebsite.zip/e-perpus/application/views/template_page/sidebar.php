<body>
    <!-- Left Panel -->
    <aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li <?php if($menu=='Dashboard') echo 'class="active"'; ?>>
                        <a href="<?= base_url('admin/dashboard'); ?>"><i class="menu-icon fa fa-laptop"></i>Dashboard
                        </a>
                    </li>
                    <li class="menu-title">Main Menu</li><!-- /.menu-title -->
                    <li <?php if($menu=='Anggota') echo 'class="active"'; ?>>
                        <a href="<?= base_url('admin/anggota')?>"> <i class="menu-icon fa fa-users"></i>Anggota</a>
                    </li>
                    <li>
                        <a href="<?= base_url('admin/petugas'); ?>"> <i class="menu-icon fa fa-user"></i>Petugas </a>
                    </li>
                    <li class="menu-item-has-children dropdown-a">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false"> <i class="menu-icon fa fa-book"></i>Buku</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="fa fa-dot-circle-o"></i><a 
                                    href="<?= base_url('admin/buku'); ?>">Data Buku</a>
                            </li>
                            <li><i class="fa fa-dot-circle-o"></i><a 
                                    href="<?= base_url('admin/kategori'); ?>">Kategori</a>
                            </li>
                        </ul>
                    </li>


                    <li class="menu-title">Transaksi</li><!-- /.menu-title -->

                    <!-- <li class="menu-item-has-children dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false"> <i class="menu-icon fa fa-file-text"></i>Peminjaman</a>
                        <ul class="sub-menu children dropdown-menu">
                            <li><i class="ti-view-list-alt "></i><a href="tables-data.html">Data Peminjaman</a></li>
                            <li><i class="ti-mobile"></i><a href="tables-data.html">Permintaan Pinjam</a></li>
                        </ul>
                    </li> -->
                    <li>
                        <a href="<?= base_url('admin/peminjaman')?>"> <i
                                class="menu-icon fa fa-file-text"></i>Peminjaman</a>
                    </li>
                    <li>
                        <a href="<?= base_url('admin/pengembalian')?>"> <i
                                class="menu-icon ti-layers-alt"></i>Pengembalian</a>
                    </li>
                     <li>
                        <a href="<?= base_url('admin/denda')?>"> <i
                                class="menu-icon fa fa-exclamation-circle"></i>Denda</a>
                    </li>
                    <li>
                        <a href="<?= base_url('laporan/laporan')?>"> <i class="menu-icon ti-receipt"></i>Laporan</a>
                    </li>

                    <li class="menu-title">Logout</li><!-- /.menu-title -->
                    <li>
                        <a href="" data-toggle="modal" data-target="#logoutModal"> <i
                                class="menu-icon fa fa-power-off"></i>Logout </a>
                    </li>

                </ul>

            </div><!-- /.navbar-collapse -->
        </nav>
    </aside>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <header id="header" class="header">
            <div class="top-left">
                <div class="navbar-header">
                    <a class="navbar-brand" href="<?= base_url('admin/dashboard'); ?>"><img
                            src="<?= base_url();?>assets/images/logsonew.png" alt="Logo"></a>
                    <a class="navbar-brand hidden" href="./"><img src="<?= base_url();?>assets/images/logo2.png"
                            alt="Logo"></a>
                    <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
                </div>
            </div>
            <div class="top-right">
                <div class="header-menu">

                    <div class="user-area dropdown float-right">
                        <a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <?php
                            foreach ($profil as $dataProfil) :
                        ?>
                            <?php if(!empty($dataProfil->foto)) { ?>
                            <img class="user-avatar rounded-circle"
                                src="<?= base_url()?>/api/upload/<?= $dataProfil->foto ?>" alt="User Avatar">
                            <?php } else { ?>
                            <img class="user-avatar rounded-circle" src="<?= base_url()?>/assets/foto/defaultUser.jpeg"
                                alt="User Avatar">
                            <?php } ?>
                        </a>
                        <?php endforeach; ?>
                        <div class="user-menu dropdown-menu">

                            <a class="nav-link" href="<?= base_url('akun/profilAkun') ?>"><i
                                    class="fa fa -cog"></i>Settings</a>

                            <a class="nav-link" href="#" data-toggle="modal" data-target="#logoutModal"><i
                                    class="fa fa-power -off"></i>Logout</a>
                        </div>
                    </div>

                </div>
            </div>
        </header>
        <!-- /#header -->