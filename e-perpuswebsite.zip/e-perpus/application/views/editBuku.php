<div class="breadcrumbs">
    <div class="breadcrumbs-inner">
        <div class="row m-0">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1><?= $menu; ?></h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="#">Main Menu</a></li>
                            <li><a href="#"><?= $menu; ?></a></li>
                            <li class="active">Tambah Data</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Content -->
<div class="content">
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-lg-12">

                <?= $this->session->flashdata('pesan'); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Edit </strong> Data
                    </div>
                    <div class="card-body card-block">
                        <?php foreach( $buku2 as $dataBuku2) :?>
                        <form action="<?= base_url('admin/buku/editBuku') ?>" method="post"
                            enctype="multipart/form-data" class="form-horizontal">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Kode Buku</label>
                                            </div>
                                            <div hidden class="col-8"><input type="text"
                                                    value="<?= $dataBuku2->id_buku; ?>" readonly id="text-input"
                                                    name="id_buku" class="form-control" required></div>
                                            <div class="col-8"><input type="text" value="<?= $dataBuku2->kd_buku; ?>"
                                                    readonly id="text-input" name="kd_buku" class="form-control"
                                                    required></div>

                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Judul</label></div>
                                            <div class="col-8"><input type="text" value="<?= $dataBuku2->judul; ?>"
                                                    id="text-input" name="judul" required placeholder="Text"
                                                    class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">No. Buku / ISSBN
                                                </label></div>
                                            <div class="col-8"><input type="text" value="<?= $dataBuku2->no_buku; ?>"
                                                    id="text-input" name="no_buku" required placeholder="Text"
                                                    class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Kategori
                                                </label></div>
                                            <div class="col-8">
                                                <select name="id_ktg" id="id_ktg" class="form-control" required>
                                                    <option value="">---Pilih kategori---</option>
                                                    <?php foreach ($kategori as $key) : ?>
                                                    <?php
                                                        if ($dataBuku2->id_ktg == $key->id_ktg) {
                                                            echo '<option value="' . $key->id_ktg . '" selected="selected">' . $key->nama_ktg . '</option>';
                                                        } else {
                                                            echo '<option value="' . $key->id_ktg . '" >' . $key->nama_ktg . '</option>';
                                                        }
                                                        ?>

                                                    <?php endforeach; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for=""
                                                    class="form-control-label">Pengarang</label></div>
                                            <div class="col-8">
                                                <input type="text" id="pengarang" value="<?= $dataBuku2->pengarang; ?>"
                                                    placeholder="Text" name="pengarang" required class="form-control">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for=""
                                                    class="form-control-label">Penerbit</label></div>
                                            <div class="col-8">
                                                <input type="text" value="<?= $dataBuku2->penerbit; ?>" id="penerbit"
                                                    placeholder="Text" name="penerbit" required class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 ">

                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Tahun Terbit</label></div>
                                            <div class="col-8"><input type="text" value="<?= $dataBuku2->thn_terbit; ?>"
                                                    id="text-input" name="thn_terbit" required placeholder="Text"
                                                    class="form-control"></div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="text-input"
                                                    class=" form-control-label">Stok</label></div>
                                            <div class="col-8"><input type="number" value="<?= $dataBuku2->stok; ?>"
                                                    Min="1" id="text-input" name="stok" required placeholder="Text"
                                                    class="form-control"></div>
                                        </div>
                                         <div class="form-group row">
                                            <label for="keterangan_buku" class="col-md-4 col-form-label">Keterangan</label>
                                            <div class="col-md-8">
                                                <textarea class="form-control" name="keterangan_buku" id="keterangan_buku"
                                                        name="keterangan_buku"><?= $dataBuku2->keterangan_buku; ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col col-md-4"><label for="file-input"
                                                    class=" form-control-label">Upload
                                                    Sampul</label></div>
                                            <div class="col-md-8">
                                                <input type="hidden" name="fileLama" class="form-control"
                                                    value="<?= $dataBuku2->sampul;  ?>" required>
                                                <?php if(!empty($dataBuku2->sampul)) { ?>
                                                <img class="rounded mb-2"
                                                    src="<?= base_url()?>/assets/foto/<?= $dataBuku2->sampul ?>"
                                                    width="90px" height="110px">
                                                <?php }else { ?>
                                                <img class="rounded mb-2"
                                                    src="<?= base_url()?>/assets/foto/defaultUser.jpeg" width="90px"
                                                    height="110px">
                                                <?php } ?>
                                                <input type="file" name="sampul" class="form-control-file" id="foto">

                                            </div>
                                        </div>

                                        <!-- Input Hidden -->
                                        <div class="row form-group" hidden>
                                            <input type="text" id="text-input" name="status_akun" value="1" required
                                                placeholder="Text" class="form-control">
                                            <input type="text" id="text-input" name="id_role" value="2" required
                                                placeholder="Text" class="form-control">
                                        </div>
                                        <!-- /input hidden -->

                                        <div class="form-group row">
                                            <div class="col-sm-10 mt-3">
                                                <button type="submit" style="width:20%;"
                                                    class="btn custom-btn mr-2">Submit</button>
                                                <button type="reset" style="width:20%;"
                                                    class="btn btn-danger">Reset</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>

                        </form>
                        <?php endforeach; ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
</div>
</div>
</div><!-- .animated -->
</div>


<!-- /.site-footer -->
</div>
<!-- /#right-panel -->