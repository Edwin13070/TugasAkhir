<?php

class perpusModel extends CI_Model
{

    var $tabless = 'detail_sparepartpelayanan';


    public function get_data($table)
    {
        return $this->db->get($table);
    }
    public function insert_data($table, $data)
    {
        return $this->db->insert($table, $data);
    }
    public function update_data($table, $data, $where)
    {
        return $this->db->update($table, $data, $where);
    }
    public function hapus_data($table, $where)
    {
        return $this->db->delete($table, $where);
    }

    public function get_dataPnj()
    {
        $this->_get_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }
    public function KodeOtomatis($where)
    {
        $id_bengkel = $where;
        $this->db->select('RIGHT(pelayanan_servis.kd_plServis,3) as kd_plServis', FALSE);
        $this->db->order_by('kd_plServis', 'DESC');
        $this->db->limit(1);
        $query = $this->db->from('pelayanan_servis')->where('id_bengkel', $id_bengkel)->get();
        if ($query->num_rows() <> 0) {
            $data = $query->row();
            $kode = intval($data->kd_plServis) + 1;
        } else {
            $kode = 1;
        }
        $batas = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $kodetampil = "KD" . $batas;
        return $kodetampil;
    }

    public function KodeBuku()
    {
        $this->db->select('RIGHT(tbl_buku.kd_buku,3) as kd_buku', FALSE);
        $this->db->order_by('kd_buku', 'DESC');
        $this->db->limit(1);

        $query = $this->db->from('tbl_buku')->get();
        if ($query->num_rows() <> 0) {
            $data = $query->row();
            $kode = intval($data->kd_buku) + 1;
        } else {
            $kode = 1;
        }
        $batas = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $kodetampil = "BK" . $batas;
        return $kodetampil;
    }

    public function KodePinjam()
    {
        $this->db->select('RIGHT(tbl_pinjam.kd_pinjam,3) as kd_pinjam', FALSE);
        $this->db->order_by('kd_pinjam', 'DESC');
        $this->db->limit(1);

        $query = $this->db->from('tbl_pinjam')->get();
        if ($query->num_rows() <> 0) {
            $data = $query->row();
            $kode = intval($data->kd_pinjam) + 1;
        } else {
            $kode = 1;
        }
        $batas = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $kodetampil = "PJ" . $batas;
        return $kodetampil;
    }

    public function KodeDenda()
    {
        $this->db->select('RIGHT(tbl_denda.kd_denda,3) as kd_denda', FALSE);
        $this->db->order_by('kd_denda', 'DESC');
        $this->db->limit(1);

        $query = $this->db->from('tbl_denda')->get();
        if ($query->num_rows() <> 0) {
            $data = $query->row();
            $kode = intval($data->kd_denda) + 1;
        } else {
            $kode = 1;
        }
        $batas = str_pad($kode, 3, "0", STR_PAD_LEFT);
        $kodetampil = "DN" . $batas;
        return $kodetampil;
    }


    public function cek_dataPelayananServis()
    {
        $id_servis = set_value('id_servis');


        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel
        $result   = $this->db->query("SELECT*FROM pelayanan_servis WHERE id_servis='$id_servis'");
        if ($result->num_rows() > 0) {
            //mengembalikan nilai ke variabel $result (line 37)
            return false;
        } else {
            return true;
        }
    }

    public function cek_prosesReg()
    {
        $username = set_value('username');


        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel
        $result   = $this->db->query("SELECT*FROM tbl_user WHERE username='$username'");
        if ($result->num_rows() > 0) {
            //mengembalikan nilai ke variabel $result (line 37)
            return false;
        } else {
            return true;
        }
    }


    public function cek_noUser()
    {
        $no_user = set_value('no_user');


        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel
        $result   = $this->db->query("SELECT*FROM tbl_user INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE no_user='$no_user' && tbl_user.id_role='2' ");
        if ($result->num_rows() > 0) {
            //mengembalikan nilai ke variabel $result (line 37)
            return false;
        } else {
            return true;
        }
    }

    // Metode untuk mengambil stok buku berdasarkan ID buku
    public function get_stok_buku($id_buku) {
        $this->db->select('stok');
        $this->db->from('tbl_buku');
        $this->db->where('id_buku', $id_buku);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->stok;
        } else {
            return 0; // Jika buku tidak ditemukan, stok adalah 0
        }
    }

    // Metode untuk mengurangi stok buku berdasarkan ID buku
    public function kurangi_stok_buku($id_buku) {
        $stok = $this->get_stok_buku($id_buku);
        if ($stok > 0) {
            $stok -= 1;
            $data = array('stok' => $stok);
            $this->db->where('id_buku', $id_buku);
            $this->db->update('tbl_buku', $data);
        }
    }

    public function ambil_idDetail($id_pinjam)
    {
        // Mengambil detail peminjaman berdasarkan ID pengembalian
        $this->db->select('id_buku');
        $this->db->where('id_pinjam', $id_pinjam);
        return $this->db->get('tbl_detail')->result();
    }


    public function tambah_stok_buku($id_buku)
    {
        // Menambahkan stok buku dengan ID buku yang diberikan
        $this->db->set('stok', 'stok+1', FALSE);
        $this->db->where('id_buku', $id_buku);
        $this->db->update('tbl_buku');
    }

    public function update_status_peminjaman($id_pinjam, $status_pinjam)
    {
        // Mengubah status peminjaman berdasarkan ID pengembalian
        $this->db->set('status_pinjam', $status_pinjam);
        $this->db->where('id_pinjam', $id_pinjam);
        $this->db->update('tbl_pinjam');
    }
    public function update_id_denda($id_pinjam, $id_denda)
    {
        // Mengubah status peminjaman berdasarkan ID pengembalian
        $this->db->set('id_denda', $id_denda);
        $this->db->where('id_pinjam', $id_pinjam);
        $this->db->update('tbl_kembali');
    }

      public function update_nominal_denda($id_pinjam, $total_denda)
    {
        // Mengubah status peminjaman berdasarkan ID pengembalian
        $this->db->set('total_denda', $total_denda);
        $this->db->where('id_pinjam', $id_pinjam);
        $this->db->update('tbl_kembali');
    }




    public function get_tanggal_kembali_by_id($id_pinjam)
    {
        // Mengambil nilai tanggal_kembali berdasarkan ID pengembalian
        $this->db->select('tanggal_kembali');
        $this->db->where('id_pinjam', $id_pinjam);
        $query = $this->db->get('tbl_kembali');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->tanggal_kembali;
        } else {
            // Jika tidak ditemukan, Anda dapat mengembalikan nilai default atau menangani kasus ini sesuai kebutuhan Anda
            return NULL; // Misalnya, mengembalikan NULL jika tidak ditemukan
        }
    }
    public function get_tanggal_kembali_by_id2($id_pinjam)
    {
        // Mengambil nilai deadline_kembali berdasarkan ID pengembalian
        $this->db->select('deadline_kembali');
        $this->db->where('id_pinjam', $id_pinjam);
        $query = $this->db->get('tbl_pinjam');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->deadline_kembali;
        } else {
            // Jika tidak ditemukan, Anda dapat mengembalikan nilai default atau menangani kasus ini sesuai kebutuhan Anda
            return NULL; // Misalnya, mengembalikan NULL jika tidak ditemukan
        }
    }


    public function get_id_denda_utama()
    {
        // Mendapatkan ID denda "denda utama" dari tabel tbl_denda
        $this->db->select('id_denda');
        $this->db->where('jns_denda', 'Utama');
        $query = $this->db->get('tbl_denda');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->id_denda;
        } else {
            // Jika tidak ditemukan, Anda dapat mengembalikan nilai default atau menangani kasus ini sesuai kebutuhan Anda
            return 0; // Misalnya, mengembalikan nilai 0 jika tidak ditemukan
        }
    }


public function get_nominal_denda($id_denda)
    {
        // Mendapatkan ID denda "denda utama" dari tabel tbl_denda
        $this->db->select('nominal');
        $this->db->where('id_denda', $id_denda);
        $query = $this->db->get('tbl_denda');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->nominal;
        } else {
            // Jika tidak ditemukan, Anda dapat mengembalikan nilai default atau menangani kasus ini sesuai kebutuhan Anda
            return 0; // Misalnya, mengembalikan nilai 0 jika tidak ditemukan
        }
    }

    public function get_id_pinjam($id_pengembalian)
    {
        // Mendapatkan ID denda "denda utama" dari tabel tbl_denda
        $this->db->select('id_pinjam');
        $this->db->where('id_pengembalian', $id_pengembalian);
        $query = $this->db->get('tbl_kembali');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->id_pinjam;
        } else {
            // Jika tidak ditemukan, Anda dapat mengembalikan nilai default atau menangani kasus ini sesuai kebutuhan Anda
            return 0; // Misalnya, mengembalikan nilai 0 jika tidak ditemukan
        }
    }




    public function cek_emailUser()
    {
        $email = set_value('email');


        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel
        $result   = $this->db->query("SELECT*FROM tbl_user WHERE email='$email'");
        if ($result->num_rows() > 0) {
            //mengembalikan nilai ke variabel $result (line 37)
            return false;
        } else {
            return true;
        }
    }

    public function cekDataPinjam()
    {
        $id_anggota = set_value('id_anggota');


        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel
        $result   = $this->db->query("SELECT*FROM tbl_pinjam WHERE id_anggota='$id_anggota' AND  status_pinjam='2' ");
        if ($result->num_rows() > 0) {
            //mengembalikan nilai ke variabel $result (line 37)
            return false;
        } else {
            return true;
        }
    }

    



    public function forgotPswd()
    {
        $email = set_value('email');


        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel
        $result   = $this->db->select('*')
        ->from('bengkel')
        ->where('email', $email)
        ->limit(1)
        ->get();

        if ($result->num_rows() > 0) {
            //mengembalikan nilai ke variabel $result (line 37)
            //ada akun
            // echo "ada akun";
            // die;
            return $result->row();
        } else {
            // echo "tidak ada akun";
            // die;
            return false;
        }
    }



    public function cek_dfServis()
    {
        $no_kendaraan = set_value('no_kendaraan');
        $tanggal_daftar = set_value('tanggal_daftar');
        $id_bengkel = set_value('id_bengkel');


        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel
        $result   = $this->db->query("SELECT*FROM servis WHERE no_kendaraan='$no_kendaraan' AND tanggal_daftar='$tanggal_daftar' AND id_bengkel='$id_bengkel' ");
        if ($result->num_rows() > 0) {
            //mengembalikan nilai ke variabel $result (line 37)
            return false;
        } else {
            return true;
        }
    }

    private function _get_query()
    {
        $this->db->select('*');
        $this->db->join('pelayanan_servis', 'pelayanan_servis.id_plServis = detail_sparepartpelayanan.id_plServis', 'left');
        $this->db->join('sparepart', 'sparepart.id_sparepart = detail_sparepartpelayanan.id_sparepart', 'left');
        $this->db->from($this->tabless);
        $this->db->where('pelayanan_servis.id_plServis', $this->session->userdata('id_plServis'));
    }
    public function get_dataDetailsparepart()
    {
        $this->_get_query();
        if ($_POST['length'] != -1)
            $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }

    

    function count_filtered()
    {
        $this->_get_query();
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function count_all()
    {
        $this->_get_query();
        return $this->db->count_all_results();
    }

    public function cek_login()
    {
        $username = set_value('username');
        $password = MD5(set_value('password'));

        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel


        $result1   = $this->db->query("SELECT*FROM tbl_user INNER JOIN role_user ON tbl_user.id_role=role_user.id_role  WHERE  username='$username' AND password='$password'");
        $result2   = $this->db->query("SELECT*FROM tbl_user INNER JOIN role_user ON tbl_user.id_role=role_user.id_role   WHERE email='$username' AND password='$password'");

        $cek = $result1->num_rows (); 
        $cek2 = $result2->num_rows (); 

        if ($cek != 1 && $cek2 == 1) {
            //mengembalikan nilai ke variabel $result (line 37)
            return $result2->row();
        }else if($cek == 1 && $cek2 != 1){
            return $result1->row();
        } else {
            return FALSE;
        }
    }

    public function cek_Uss()
    {
        $no_user = set_value('no_user');

        //limit 1 artiya data yang diambil hanya 1 , get (mengambil dari table) bengkel


        $resultUss   = $this->db->query("SELECT*FROM tbl_user INNER JOIN role_user ON tbl_user.id_role=role_user.id_role  WHERE  no_user='$no_user' AND hak_akses='anggota'");


        return $resultUss->row();
    }

    public function get_tableid_edit($table_name,$where,$id)
    {
       $this->db->where($where,$id);
       $edit = $this->db->get($table_name);
       return $edit->row();
   }

   public function get_durasi()
    {
        // Ambil durasi dari database (gantilah 'nama_tabel' dengan nama tabel yang sesuai)
        $query = $this->db->get('tbl_maxpinjam');

        if ($query->num_rows() > 0) {
            $row = $query->row();
            return $row->max_hari;
        } else {
            return 0; // Nilai default jika data tidak ditemukan
        }
    }
    public function simpan_durasi($durasi_booking)
    {
        // Di sini, Anda dapat menulis logika untuk menyimpan durasi_booking ke database atau tempat penyimpanan yang sesuai.
        // Contoh:
        $this->db->update('tbl_maxpinjam', array('max_hari' => $durasi_booking));
    }

}