<?php

class profilAkun extends CI_Controller
{
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Setting Akun";


        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('akun/profilAkun', $data);
        $this->load->view('template_page/footer');

        
    }
}