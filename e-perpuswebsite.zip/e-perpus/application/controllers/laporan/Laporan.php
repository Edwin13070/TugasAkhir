<?php

class Laporan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('Pdf');
        
        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
                Silahkan login terlebih dulu
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>');
            redirect('login');
        }
    }

    public function letak($pdf, $gambar)
    {
        // Memasukkan gambar untuk header
        $pdf->Image($gambar, 11, 9, 23, 23);
        // Menggeser posisi sekarang
    }

    public function judul($pdf, $teks1, $teks2, $teks4, $teks5)
    {
        $pdf->Cell(15);
        $pdf->SetFont('Times', 'B', '14');
        $pdf->Cell(0, 5, $teks1, 0, 1, 'C');
        $pdf->Cell(15);
        $pdf->Cell(0, 5, $teks2, 0, 1, 'C');
        $pdf->Cell(15);
        $pdf->SetFont('Times', 'I', '11');
        $pdf->Cell(0, 8, $teks4, 0, 1, 'C');
        $pdf->Cell(15);
        $pdf->Cell(0, 2, $teks5, 0, 1, 'C');
    }

    public function garis($pdf)
    {
        $pdf->SetLineWidth(1);
        $pdf->Line(10, 34, 200, 34);
        $pdf->SetLineWidth(0);
        $pdf->Line(10, 35, 200, 35);
    }



    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Laporan";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar', $data);
        $this->load->view('laporan', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function Laporan_userAnggota()
    {
        error_reporting(0); // AGAR ERROR MASALAH VERSI PHP TIDAK MUNCUL
        $pdf = new FPDF();
        $pdf->SetTitle('Data Anggota');
        // Mulai dokumen
        $pdf->AddPage('P', 'A4');
            // Memanggil metode letak() dengan objek $pdf
        $this->letak($pdf, base_url('assets/images/logosmkn1trc.png'));
        
        // Meletakkan judul disamping logo di atas
        $this->judul($pdf, 'PERPUSTAKAAN SEKOLAH', 'SMK NEGERI 1 TRUCUK',  'Jl. Mlese-Cawas, Sabrang Lor, Kec. Trucuk, Kabupaten Klaten, Jawa Tengah 57467', 'Telp. (027) 23102057  E-Mail:smkn_1_trucuk@yahoo.com');
        
        // Membuat garis ganda tebal dan tipis
        $this->garis($pdf);
        
        $pdf->Cell(10, 10, '', 0, 1);
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(0, 10, 'DATA ANGGOTA PERPUSTAKAAN', 0, 1, 'C');
        
        $pdf->Cell(0, 5, 'LIST DATA', 0, 1, 'C');
        

        //UNTUK TH TABLE
        $pdf ->Cell(5,5,'',0,1);
        $pdf ->SetFont('Arial','B',10);
        $pdf ->Cell(10,10,'  No.',1,0);
        $pdf ->Cell(18,10,'  ID ',1,0);
        $pdf ->Cell(44,10,'  Nama',1,0);
        $pdf ->Cell(46,10,'  Email',1,0);
        $pdf ->Cell(34,10,'  Level',1,0 );
        $pdf ->Cell(34,10,'  No.Telp',1,1);



        $anggota = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role ")->result();
        $no = 0;
        $pdf ->SetFont('Arial','',10);
        foreach ($anggota as $data) {
            $no++;
            $pdf ->Cell(10,10,  $no,1,0,'C');
            $pdf ->Cell(18,10,  $data->no_user,1,0);
            $pdf ->Cell(44,10,  $data->nama_user,1,0);
            $pdf ->Cell(46,10,  $data->email,1,0);
            $pdf ->Cell(34,10,  $data->hak_akses,1,0 );
            $pdf ->Cell(34,10,  $data->no_telp ,1,1);

        }
        
              //bagian mengetahui
        $pdf ->Cell(5,15,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'Klaten,',0,0);
        $pdf ->Cell(15,6,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(25,6,'Koordinator Perpustakaan',0,1);
        $pdf ->Cell(5,20,'',0,1);
         $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'-----------------------------------',0,1);
        $pdf ->Cell(170,6,'',0,0);

        
        $pdf->Output();
    }

    public function Laporan_buku()
    {
        error_reporting(0); // AGAR ERROR MASALAH VERSI PHP TIDAK MUNCUL
        $pdf = new FPDF();
        $pdf->SetTitle('Data Buku ');
        // Mulai dokumen
        $pdf->AddPage('P', 'A4');
        // Memanggil metode letak() dengan objek $pdf
        $this->letak($pdf, base_url('assets/images/logosmkn1trc.png'));
        // Meletakkan judul disamping logo di atas
        $this->judul($pdf, 'PERPUSTAKAAN SEKOLAH', 'SMK NEGERI 1 TRUCUK',  'Jl. Mlese-Cawas, Sabrang Lor, Kec. Trucuk, Kabupaten Klaten, Jawa Tengah 57467', 'Telp. (027) 23102057  E-Mail:smkn_1_trucuk@yahoo.com');
        // Membuat garis ganda tebal dan tipis
        $this->garis($pdf);

        $pdf ->Cell(10,10,'',0,1);
        $pdf ->SetFont('Arial','B',10);
        $pdf ->Cell(0,10,'DATA INVENTORY BUKU',0,1,'C');

        $pdf ->Cell(0,5,'LIST DATA',0,1,'C');


        //UNTUK TH TABLE
        $pdf ->Cell(5,5,'',0,1);
        $pdf ->SetFont('Arial','B',10);
        $pdf ->Cell(10,10,'  No.',1,0);
        $pdf ->Cell(18,10,'  Kode ',1,0);
        $pdf ->Cell(44,10,'  Judul',1,0);
        $pdf ->Cell(46,10,'  Penerbit',1,0);
        $pdf ->Cell(34,10,'  Stok',1,0 );
        $pdf ->Cell(34,10,'  Tahun terbit',1,1);



        $buku = $this->db->query("SELECT * FROM tbl_buku INNER jOIN tbl_kategori ON tbl_buku.id_ktg=tbl_kategori.id_ktg ORDER BY kd_buku DESC")->result();
        $no = 0;
        $pdf ->SetFont('Arial','',10);
        foreach ($buku as $data) {
            $no++;
            $pdf ->Cell(10,10,  $no,1,0,'C');
            $pdf ->Cell(18,10,  $data->kd_buku,1,0);
            $pdf ->Cell(44,10,  $data->judul,1,0);
            $pdf ->Cell(46,10,  $data->penerbit,1,0);
            $pdf ->Cell(34,10,  $data->stok,1,0 );
            $pdf ->Cell(34,10,  $data->thn_terbit ,1,1);

        }
        
        //bagian mengetahui
        $pdf ->Cell(5,15,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'Klaten,',0,0);
        $pdf ->Cell(15,6,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(25,6,'Koordinator Perpustakaan',0,1);
        $pdf ->Cell(5,20,'',0,1);
         $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'-----------------------------------',0,1);
        $pdf ->Cell(170,6,'',0,0);



        $pdf->Output();
    }

    public function lap_detailPnj($id_pengembalian)
    {
        error_reporting(0); // AGAR ERROR MASALAH VERSI PHP TIDAK MUNCUL
        $pdf = new FPDF('L', 'mm', 'Letter');
        $pdf->AddPage();
        $pdf->SetTitle('Laporan Peminjaman');
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(0, 7, 'LAPORAN PEMINJAMAN', 0, 1, 'C');
        $pdf->Cell(10, 7, '', 0, 1);


        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Cell(27, 6, 'Perpustakaan SMKN 1 TRUCUK', 0, 1);
        $pdf->Cell(10, 2, '', 0, 1);

        $pdf->SetFont('Arial', '', 10);

        $pdf->Cell(27, 6, 'Alamat', 0, 0);
        $pdf->Cell(3, 6, ':', 0, 0);
        $pdf->Cell(180, 6, 'Jl. Mlese-Cawas, Sabrang Lor, Kec. Trucuk, Kabupaten Klaten, Jawa Tengah 57467', 0, 0);
        $pdf->Cell(20, 6, 'Tanggal', 0, 0);
        $pdf->Cell(3, 6, ':', 0, 0);
        $pdf->Cell(10, 6, date('d-m-Y'), 0, 1);

        $pdf->Cell(27, 6, 'No. Telp', 0, 0);
        $pdf->Cell(3, 6, ':', 0, 0);
        $pdf->Cell(180, 6, '(027) 23102057', 0, 1);


        $pdf->Cell(10, 10, '', 0, 1);

        $pnj = $this->db->query("SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, anggota.no_user AS no_anggota, anggota.no_telp AS telp_user, admin.nama_user AS nama_admin, tbl_kembali.tanggal_kembali AS tgl_pengembalian, tbl_kembali.id_denda, tbl_kembali.total_denda,tbl_kembali.id_pengembalian
            FROM tbl_kembali
            INNER JOIN tbl_pinjam ON tbl_kembali.id_pinjam = tbl_pinjam.id_pinjam
            LEFT JOIN tbl_denda ON tbl_kembali.id_denda = tbl_denda.id_denda
            INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
            LEFT JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
            WHERE id_pengembalian='$id_pengembalian' ORDER BY kd_pinjam DESC
            ")->result();

        foreach ($pnj as $dataPnj) {




            $pdf->SetFont('Arial', 'B', 14);
            $pdf->Cell(27, 6, 'Data Peminjaman', 0, 1,);
            $pdf->Cell(10, 4, '', 0, 1);
            $pdf->SetFont('Arial', '', 10);
            $pdf->Cell(27, 6, 'Kode Pinjam', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(170, 6, $dataPnj->kd_pinjam, 0, 0);
            $pdf->Cell(30, 6, 'Tgl. Kembali', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(10, 6, date('d F Y', strtotime($dataPnj->tgl_pengembalian)), 0, 1);

            $pdf->Cell(27, 6, 'Nama', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(170, 6, $dataPnj->nama_anggota, 0, 0);



        //Keterangan
            $tanggalPengembalian = new DateTime($dataPnj->tgl_pengembalian);
            $deadlineKembali = new DateTime($dataPnj->deadline_kembali);

         // Hitung selisih antara dua tanggal
            $selisih = $tanggalPengembalian->diff($deadlineKembali);

        // Ambil selisih dalam format hari
            $keterangan = $selisih->days;

            if ($tanggalPengembalian > $deadlineKembali){
                $pdf->Cell(30, 6, 'Keterangan', 0, 0);
                $pdf->Cell(3, 6, ':', 0, 0);
                $pdf->Cell(10, 6,  'Telat '.$keterangan.' Hari', 0, 1);
            } else {
                $pdf->Cell(30, 6, 'Keterangan', 0, 0);
                $pdf->Cell(3, 6, ':', 0, 0);
                $pdf->Cell(10, 6,  'Tepat Waktu', 0, 1);

            }


            $pdf->Cell(27, 6, 'No. Anggota', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(170, 6, $dataPnj->no_anggota, 0, 0);

            $pdf->Cell(30, 6, 'Total Denda', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(10, 6, 'Rp.'.number_format($dataPnj->total_denda, 0, ',', '.'), 0, 1);



            $pdf->Cell(27, 6, 'Tgl. Pinjam', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(170, 6, date('d F Y', strtotime($dataPnj->tanggal_pinjam)) , 0, 0);
            $pdf->Cell(30, 6, 'Petugas', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(10, 6, $dataPnj->nama_admin, 0, 1);




            $pdf->Cell(27, 6, 'Durasi', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(170, 6, $dataPnj->durasi.' Hari', 0, 1);
            $pdf->Cell(27, 6, 'Deadline', 0, 0);
            $pdf->Cell(3, 6, ':', 0, 0);
            $pdf->Cell(170, 6, date('d F Y', strtotime($dataPnj->deadline_kembali)), 0, 1);
            $pdf->Cell(10, 5, '', 0, 1);
            
            break;
        }


        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(27, 6, 'Data Buku', 0, 1,);
        $pdf->Cell(10, 4, '', 0, 1);


        
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(10, 6, 'No', 1, 0, 'C');
        $pdf->Cell(40, 6, 'Kode', 1, 0, 'C');
        $pdf->Cell(40, 6, 'Judul ', 1, 0, 'C');
        $pdf->Cell(40, 6, 'No Buku ', 1, 0, 'C');
        $pdf->Cell(40, 6, 'Pengarang', 1, 0, 'C');
        $pdf->Cell(40, 6, 'Penerbit', 1, 0, 'C');
        $pdf->Cell(50, 6, 'Thn Terbit', 1, 1, 'C');
        $pdf->SetFont('Arial', '', 10);


        $ambilid = $this->perpusModel->get_id_pinjam($id_pengembalian);
        $buku=$this->db->query("SELECT * FROM tbl_detail  
            INNER JOIN tbl_buku ON tbl_detail.id_buku=tbl_buku.id_buku
            INNER JOIN tbl_pinjam ON tbl_detail.id_pinjam=tbl_pinjam.id_pinjam 
            WHERE tbl_detail.id_pinjam='$ambilid'
            ")->result();

        $no = 0;
        foreach ($buku as $data) {
            $no++;
            $pdf->Cell(10, 6, $no, 1, 0, 'C');
            $pdf->Cell(40, 6, $data->kd_buku, 1, 0);
            $pdf->Cell(40, 6, $data->judul, 1, 0);
            $pdf->Cell(40, 6, $data->no_buku, 1, 0);
            $pdf->Cell(40, 6, $data->pengarang, 1, 0);
            $pdf->Cell(40, 6, $data->penerbit, 1, 0);
            $pdf->Cell(50, 6, $data->thn_terbit, 1, 1);

            
        }
        
              //bagian mengetahui
        $pdf ->Cell(5,15,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(220,6,'',0,0);
        $pdf ->Cell(15,6,'Klaten,',0,0);
        $pdf ->Cell(15,6,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(220,6,'',0,0);
        $pdf ->Cell(25,6,'Koordinator Perpustakaan',0,1);
        $pdf ->Cell(5,20,'',0,1);
         $pdf ->Cell(220,6,'',0,0);
        $pdf ->Cell(15,6,'-----------------------------------',0,1);
        $pdf ->Cell(170,6,'',0,0);


        $pdf->Output();
    }


    public function laporan_peminjaman()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Laporan";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar', $data);
        $this->load->view('laporan_pnj', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function data_lapPnj($tanggal_mulai, $tanggal_selesai)
    {
        error_reporting(0); // AGAR ERROR MASALAH VERSI PHP TIDAK MUNCUL
        $pdf = new FPDF();
        $pdf->SetTitle('Data Laporan Peminjaman ');
        // Mulai dokumen
        $pdf->AddPage('P', 'A4');
        // Memanggil metode letak() dengan objek $pdf
        $this->letak($pdf, base_url('assets/images/logosmkn1trc.png'));
        // Meletakkan judul disamping logo di atas
        $this->judul($pdf, 'PERPUSTAKAAN SEKOLAH', 'SMK NEGERI 1 TRUCUK',  'Jl. Mlese-Cawas, Sabrang Lor, Kec. Trucuk, Kabupaten Klaten, Jawa Tengah 57467', 'Telp. (027) 23102057  E-Mail:smkn_1_trucuk@yahoo.com');
        // Membuat garis ganda tebal dan tipis
        $this->garis($pdf);

        $pdf->Cell(10, 10, '', 0, 1);
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(0, 10, 'Laporan Peminjaman Buku ', 0,1, 'C');
        $pdf->SetFont('Arial', '', 10);
    


        //UNTUK TH TABLE
        $pdf ->Cell(5,5,'',0,1);
        $pdf ->SetFont('Arial','B',10);
        $pdf ->Cell(10,10,'  No.',1,0);
        $pdf ->Cell(28,10,'  KD Pinjam ',1,0);
        $pdf ->Cell(25,10,'  Tgl Pinjam',1,0);
        $pdf ->Cell(35,10,'  Status',1,0);
        $pdf ->Cell(44,10,'  Peminjam',1,0 );
        $pdf ->Cell(44,10,'  Petugas',1,1);



        $buku = $this->db->query("SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, admin.nama_user AS nama_admin 
            FROM tbl_pinjam
            INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
            INNER JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
            WHERE tanggal_pinjam BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' AND (status_pinjam = 2 OR status_pinjam = 3) ORDER BY tanggal_pinjam ASC")->result();
        $no = 0;
        $pdf ->SetFont('Arial','',10);
        foreach ($buku as $data) {
            $no++;
            $pdf ->Cell(10,10,  $no,1,0,'C');
            $pdf ->Cell(28,10,  $data->kd_pinjam,1,0);
            $pdf ->Cell(25,10,  $data->tanggal_pinjam,1,0);
            $status ="";
            if ( $data->status_pinjam == "3") {
                $status ="Telah Dikembalikan";
            }else if ( $data->status_pinjam == "2") {
                $status ="Belum Dikembalikan";
            }
            $pdf ->Cell(35,10,  $status,1,0);
            $pdf ->Cell(44,10,  $data->nama_anggota,1,0 );
            $pdf ->Cell(44,10,  $data->nama_admin ,1,1);

        }
        
              //bagian mengetahui
        $pdf ->Cell(5,15,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'Klaten,',0,0);
        $pdf ->Cell(15,6,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(25,6,'Koordinator Perpustakaan',0,1);
        $pdf ->Cell(5,20,'',0,1);
         $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'-----------------------------------',0,1);
        $pdf ->Cell(170,6,'',0,0);

        
        $pdf->Output();
    }

    public function laporan_pengembalian()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Laporan";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar', $data);
        $this->load->view('laporan_kmb', $data);
        $this->load->view('template_page/footer', $data);
    }

     public function data_lapKmb($tanggal_mulai, $tanggal_selesai)
    {
        error_reporting(0); // AGAR ERROR MASALAH VERSI PHP TIDAK MUNCUL
        $pdf = new FPDF();
        $pdf->SetTitle('Data Laporan Peminjaman ');
        // Mulai dokumen
        $pdf->AddPage('P', 'A4');
        // Memanggil metode letak() dengan objek $pdf
        $this->letak($pdf, base_url('assets/images/logosmkn1trc.png'));
        // Meletakkan judul disamping logo di atas
        $this->judul($pdf, 'PERPUSTAKAAN SEKOLAH', 'SMK NEGERI 1 TRUCUK',  'Jl. Mlese-Cawas, Sabrang Lor, Kec. Trucuk, Kabupaten Klaten, Jawa Tengah 57467', 'Telp. (027) 23102057  E-Mail:smkn_1_trucuk@yahoo.com');
        // Membuat garis ganda tebal dan tipis
        $this->garis($pdf);

        $pdf->Cell(10, 10, '', 0, 1);
        $pdf->SetFont('Arial', 'B', 10);
        $pdf->Cell(0, 10, 'Laporan Pengembalian Buku ', 0,1, 'C');
        $pdf->SetFont('Arial', '', 10);



        //UNTUK TH TABLE
        $pdf ->Cell(5,5,'',0,1);
        $pdf ->SetFont('Arial','B',10);
        $pdf ->Cell(10,10,'  No.',1,0);
        $pdf ->Cell(28,10,'  KD Pinjam ',1,0);
        $pdf ->Cell(44,10,'  Peminjam',1,0);
        $pdf ->Cell(25,10,'  Tgl Kembali',1,0 );
        $pdf ->Cell(45,10,'  Status',1,0);
        $pdf ->Cell(34,10,'  Denda',1,1);



        $buku = $this->db->query("SELECT tbl_kembali.*,tbl_pinjam.*, anggota.nama_user AS nama_anggota, admin.nama_user AS nama_admin 
            FROM tbl_kembali
            INNER JOIN tbl_pinjam ON tbl_kembali.id_pinjam = tbl_pinjam.id_pinjam
            INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
            INNER JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
            WHERE tanggal_pinjam BETWEEN '$tanggal_mulai' AND '$tanggal_selesai' AND (status_pinjam = 2 OR status_pinjam = 3) ORDER BY kd_pinjam ASC")->result();
        $no = 0;
        $pdf ->SetFont('Arial','',10);
        foreach ($buku as $data) {
            $no++;
            $pdf ->Cell(10,10,  $no,1,0,'C');
            $pdf ->Cell(28,10,  $data->kd_pinjam,1,0);
            $pdf ->Cell(44,10,  $data->nama_anggota,1,0 );
            $pdf ->Cell(25,10,  $data->tanggal_kembali,1,0);
            $status ="";
            if ( $data->tanggal_kembali > $data->deadline_kembali) {
                $status ="Telat Mengembalikan";
            }else {
                $status ="Tepat Waktu";
            }
            $pdf ->Cell(45,10,  $status,1,0);
            $pdf->Cell(34, 10, 'Rp. ' . number_format($data->total_denda, 0, ',', '.'), 1, 1);


        }
        
              //bagian mengetahui
        $pdf ->Cell(5,15,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'Klaten,',0,0);
        $pdf ->Cell(15,6,'',0,1);
        $pdf ->SetFont('Arial','',10);
        $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(25,6,'Koordinator Perpustakaan',0,1);
        $pdf ->Cell(5,20,'',0,1);
         $pdf ->Cell(140,6,'',0,0);
        $pdf ->Cell(15,6,'-----------------------------------',0,1);
        $pdf ->Cell(170,6,'',0,0);

        
        $pdf->Output();
    }


}

