<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->_rules();

		if ($this->form_validation->run() == FALSE) {
			$data['title'] = "E-Perpustakaan";
			$this->load->view('login', $data);
		} else {
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			//cek username dan password lewat functuin cek_login di model yang digunakan
			$cekQuery = $this->perpusModel->cek_login($username, $password);

			//Cek Aktivasi akun
			$query   = $this->db->query("SELECT * FROM tbl_user WHERE status_akun='1' AND username='$username' ");
			$query2   = $this->db->query("SELECT * FROM tbl_user WHERE status_akun='1' AND email='$username' ");

			$cek = $query->num_rows (); 
			$cek2 = $query2->num_rows (); 
			//Tutup Cek Aktivasi akun


			if ($cekQuery == FALSE) {
				$this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
				<span class="badge badge-pill badge-danger">Gagal Login</span>
				Username atau Password Salah!
				<button type="button" class="close" data-dismiss="alert"  aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				</div>');
				redirect('login');
			} 

			// if ($cek == 0 && $cek2 != 1 ) {
			// 	$this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-warning alert-dismissible fade show mt-3">
			// 	<span class="badge badge-pill badge-warning">Gagal Login</span>
			// 	Akun Anda belum aktif. Cek email anda untuk mengaktifkan akun.
			// 	<button type="button" class="close" data-dismiss="alert"  aria-label="Close">
			// 		<span aria-hidden="true">&times;</span>
			// 	</button>
			// 	</div>');
			// 	redirect('login');
			//} 
			else {
				//membuat dan mengirimkan session hakakses
		
				$this->session->set_userdata('id_user', $cekQuery->id_user);
				$this->session->set_userdata('hak_akses', $cekQuery->hak_akses);
				$this->session->set_userdata('jenkel', $cekQuery->jenkel);
				$this->session->set_userdata('nama_user', $cekQuery->nama_user);
	
				if ($cekQuery->hak_akses == "admin") {
					//memanggil file dasboard pada controller admin
					redirect('admin/dashboard');
				} else {
					$this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
					<span class="badge badge-pill badge-danger">Gagal Login</span>
					Akun yang anda gunakan bukan akun admin!
					<button type="button" class="close" data-dismiss="alert" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
					</div>');
					redirect('login');
				}
			}
		}
	}
	public function _rules()
	{
		$this->form_validation->set_rules('username', 'username', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
	}

	public function logout()
	{
		//menghapus (menghancurkan) session
		$this->session->sess_destroy();
		redirect('login');
	}
}
