<?php

class Dashboard extends CI_Controller
{
    public function __construct()
    {


        parent::__construct();
        //untuk mengecek apakah sudah ada session di dasbord

        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
                Silahkan login terlebih dulu
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>');
            redirect('login');
        }
    }
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Dashboard";

        //jumlah anggota
        $jml_anggota = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE tbl_user.id_role='2'");
        $data['anggota'] = $jml_anggota->num_rows();

        //jumlah buku
        $jml_buku = $this->db->query("SELECT * FROM tbl_buku");
        $data['buku'] = $jml_buku->num_rows();

        //jumlah peminjam
        $jml_pinjam = $this->db->query("SELECT * FROM tbl_pinjam WHERE status_pinjam='1' OR status_pinjam='2' ");
        $data['pinjam'] = $jml_pinjam->num_rows();

        //jumlah pengembalian
        $jml_kembali = $this->db->query("SELECT * FROM tbl_kembali");
        $data['kmb'] = $jml_kembali->num_rows();



        $data['view_pnj'] = $this->db->query("SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, anggota.no_user AS no_user, admin.nama_user AS nama_admin
            FROM tbl_pinjam
            INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
            LEFT JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
            WHERE status_pinjam='1' ORDER BY kd_pinjam ASC
        ")->result();


        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('dashboard', $data);
        $this->load->view('template_page/footer', $data);
        
    }
}