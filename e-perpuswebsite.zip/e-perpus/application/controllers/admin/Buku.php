<?php

class Buku extends CI_Controller
{
    public function __construct()
    {


        parent::__construct();
        //untuk mengecek apakah sudah ada session di dasbord

        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
            Silahkan login terlebih dulu
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('login');
        }
    }
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Buku";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['buku'] = $this->db->query("SELECT * FROM tbl_buku INNER jOIN tbl_kategori ON tbl_buku.id_ktg=tbl_kategori.id_ktg ORDER BY kd_buku DESC")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('buku', $data);
        $this->load->view('template_page/footer', $data);
        
    }

     public function create()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Buku";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['kategori'] = $this->db->query("SELECT * FROM tbl_kategori")->result();
        
        
        //kode otomatis
        $this->load->model('perpusModel');
        $data['kdBk'] = $this->perpusModel->KodeBuku();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('createBuku', $data);
        $this->load->view('template_page/footer');
    }

     public function InputProses()
    {
        $kd_buku = $this->input->post('kd_buku');
        $judul = $this->input->post('judul');
        $no_buku = $this->input->post('no_buku');
        $pengarang = $this->input->post('pengarang');
        $penerbit = $this->input->post('penerbit');
        $thn_terbit = $this->input->post('thn_terbit');
        $stok = $this->input->post('stok');
        $keterangan_buku = $this->input->post('keterangan_buku');
        $id_ktg = $this->input->post('id_ktg');
        $sampul   = $_FILES['sampul']['name'];
 
        if ($sampul = '') {
        } else {
            $config['upload_path'] = './assets/foto';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('sampul')) {
                echo $this->upload->display_errors();
                die();
            } else {
                $sampul = $this->upload->data('file_name');
            }
        }
       
            $data = array(
                'kd_buku'    => $kd_buku,
                'judul'  => $judul,
                'no_buku'       => $no_buku,
                'pengarang'  => $pengarang,
                'penerbit'        => $penerbit,
                'thn_terbit'        => $thn_terbit,
                'stok'     => $stok,
                'keterangan_buku'     => $keterangan_buku,
                'id_ktg'       => $id_ktg,
                'sampul'           => $sampul
            );
            $this->perpusModel->insert_data('tbl_buku', $data);
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-success">Sukses</span>
           Data Berhasil Ditambahkan
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('admin/Buku');
        
    
    }

    public function hapusData($id_buku)
    {
        $where = array('id_buku' => $id_buku);
        $this->perpusModel->hapus_data('tbl_buku', $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>');
        redirect('admin/Buku');
    }

     public function editData($id_buku)
    {
        $where = $id_buku;
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Buku";
        
        $sess = $this->session->userdata('id_user');

        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$sess'")->result();

        $data['buku2'] = $this->db->query("SELECT * FROM tbl_buku INNER jOIN tbl_kategori ON tbl_buku.id_ktg=tbl_kategori.id_ktg WHERE id_buku='$where'")->result();

        $data['kategori'] = $this->db->query("SELECT * FROM tbl_kategori ORDER BY nama_ktg ASC")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('editBuku', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function editBuku()
    {
        $id_buku = $this->input->post('id_buku');
        $kd_buku = $this->input->post('kd_buku');
        $judul = $this->input->post('judul');
        $no_buku = $this->input->post('no_buku');
        $pengarang = $this->input->post('pengarang');
        $penerbit = $this->input->post('penerbit');
        $thn_terbit = $this->input->post('thn_terbit');
        $stok = $this->input->post('stok');
        $keterangan_buku = $this->input->post('keterangan_buku');
        $id_ktg = $this->input->post('id_ktg');

        $fileLama   = $this->input->post('fileLama');
        if ($_FILES['sampul']['error'] === 4) {
            $sampul = $fileLama;
        } else {
            $config['upload_path'] = './assets/foto';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('sampul')) {
                echo $this->upload->display_errors();
                die();
            } else {
                $sampul = $this->upload->data('file_name');
            }
        }
        $data = array(
            'kd_buku'       => $kd_buku,
            'judul'       => $judul,
            'no_buku'       => $no_buku,
            'pengarang'       => $pengarang,
            'penerbit'       => $penerbit,
            'thn_terbit'       => $thn_terbit,
            'stok'       => $stok,
            'keterangan_buku'       => $keterangan_buku,
            'id_ktg'       => $id_ktg,
            'sampul'       => $sampul
        );
        $where = array(
            'id_buku' => $id_buku
        );
        $this->perpusModel->update_data('tbl_buku', $data, $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil diubah
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('admin/Buku');   

    }
}