<?php

class Pengembalian extends CI_Controller
{
    public function __construct()
    {


        parent::__construct();
        //untuk mengecek apakah sudah ada session di dasbord

        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
                Silahkan login terlebih dulu
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>');
            redirect('login');
        }
    }
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Pengembalian";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();


        $data['pengembalian'] = $this->db->query("SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, admin.nama_user AS nama_admin, tbl_kembali.tanggal_kembali AS tgl_pengembalian, tbl_kembali.id_denda, tbl_kembali.total_denda,tbl_kembali.id_pengembalian
            FROM tbl_kembali
            INNER JOIN tbl_pinjam ON tbl_kembali.id_pinjam = tbl_pinjam.id_pinjam
            LEFT JOIN tbl_denda ON tbl_kembali.id_denda = tbl_denda.id_denda
            INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
            LEFT JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
            WHERE status_pinjam='3' ORDER BY id_pengembalian DESC
            ")->result();


        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('pengembalian', $data);
        $this->load->view('template_page/footer', $data);
        
    }


    public function detailPnj($id_pengembalian)
    {
        $where = $id_pengembalian;
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Detail Pengembalian";

        $sess = $this->session->userdata('id_user');

        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$sess'")->result();

        $data['pengembalian'] = $this->db->query("SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, anggota.no_user AS no_anggota, anggota.no_telp AS telp_user, admin.nama_user AS nama_admin, tbl_kembali.tanggal_kembali AS tgl_pengembalian, tbl_kembali.id_denda, tbl_kembali.total_denda,tbl_kembali.id_pengembalian
            FROM tbl_kembali
            INNER JOIN tbl_pinjam ON tbl_kembali.id_pinjam = tbl_pinjam.id_pinjam
            LEFT JOIN tbl_denda ON tbl_kembali.id_denda = tbl_denda.id_denda
            INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
            LEFT JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
            WHERE id_pengembalian='$id_pengembalian' ORDER BY kd_pinjam DESC
            ")->result();


        $data['peminjam'] = $this->db->query("SELECT * FROM tbl_user  
            INNER JOIN role_user ON tbl_user.id_role=role_user.id_role ")->result();

        $ambilid = $this->perpusModel->get_id_pinjam($id_pengembalian);

        $data['buku'] = $this->db->query("SELECT * FROM tbl_detail  
            INNER JOIN tbl_buku ON tbl_detail.id_buku=tbl_buku.id_buku
            INNER JOIN tbl_pinjam ON tbl_detail.id_pinjam=tbl_pinjam.id_pinjam 
            WHERE tbl_detail.id_pinjam='$ambilid'
            ")->result();


        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('detailPengembalian', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function hapusData($id_pengembalian)
    {
        $where = array('id_pengembalian' => $id_pengembalian);

        $id_pinjam = $this->perpusModel->get_id_pinjam($id_pengembalian);
        $where2 = array('id_pinjam' => $id_pinjam);


        //hapus pengembalian dan data detail
        $this->perpusModel->hapus_data('tbl_kembali', $where);
        $this->perpusModel->hapus_data('tbl_detail', $where2);
        $this->perpusModel->hapus_data('tbl_pinjam', $where2);

        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-success">Success</span>
            Data berhasil dihapus
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>');

           redirect('admin/pengembalian');
    }

    public function editData($id_pengembalian)
    {
        $where = $id_pengembalian;
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Pengembalian";
        
        $sess = $this->session->userdata('id_user');

        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$sess'")->result();

        $data['pengembalian'] = $this->db->query("SELECT * FROM tbl_kembali 
            INNER JOIN tbl_pinjam ON tbl_kembali.id_pinjam = tbl_pinjam.id_pinjam
            WHERE id_pengembalian='$id_pengembalian'")->result();
        

            $data['denda'] = $this->db->query("SELECT * FROM tbl_denda")->result();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('editPengembalian', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function editPengembalian()
    {
        $id_pengembalian = $this->input->post('id_pengembalian');
        $id_denda = $this->input->post('id_denda');
        $nominal_denda = $this->perpusModel->get_nominal_denda($id_denda);
        $total_denda = $nominal_denda;

            $data = array(
                'id_denda'    => $id_denda,               
                'total_denda'    => $total_denda             
            );
        $where = array(
            'id_pengembalian' => $id_pengembalian
        );
        $this->perpusModel->update_data('tbl_kembali', $data, $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil diubah
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('admin/pengembalian');   

    }

    public function tampilDenda()
    {
        $id_denda = $_GET['id_denda'];
        $query = "SELECT * FROM tbl_denda WHERE id_denda='$id_denda'";
        $result = $this->db->query($query)->row_array();
        // print_r($result);
        echo json_encode($result);
    }

}