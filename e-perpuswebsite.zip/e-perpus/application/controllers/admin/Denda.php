<?php

class Denda extends CI_Controller
{
    public function __construct()
    {


        parent::__construct();
        //untuk mengecek apakah sudah ada session di dasbord

        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
            Silahkan login terlebih dulu
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('login');
        }
    }
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Denda";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['denda'] = $this->db->query("SELECT * FROM tbl_denda")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('denda', $data);
        $this->load->view('template_page/footer', $data);
        
    }

     public function create()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Denda";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $this->load->model('perpusModel');
        $data['dn'] = $this->perpusModel->KodeDenda();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('createDenda', $data);
        $this->load->view('template_page/footer');
    }

     public function InputProses()
    {
        $kd_denda = $this->input->post('kd_denda');
        $jns_denda = "Tambahan";
        $nominal = $this->input->post('nominal');
        $keterangan = $this->input->post('keterangan');



            $data = array(
                'kd_denda'    => $kd_denda,               
                'jns_denda'    => $jns_denda,               
                'nominal'    => $nominal,               
                'keterangan'    => $keterangan              
            );
            $this->perpusModel->insert_data('tbl_denda', $data);
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-success">Sukses</span>
           Data Berhasil Ditambahkan
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('admin/Denda');
        
    
    }

    public function hapusData($id_denda)
    {
        $where = array('id_denda' => $id_denda);
        $this->perpusModel->hapus_data('tbl_denda', $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>');
        redirect('admin/denda');
    }

     public function editData($id_denda)
    {
        $where = $id_denda;
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Denda";
        
        $sess = $this->session->userdata('id_user');

        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$sess'")->result();

        $data['denda'] = $this->db->query("SELECT * FROM tbl_denda WHERE id_denda='$id_denda'")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('editDnd', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function editDenda()
    {
        $id_denda = $this->input->post('id_denda');
        $kd_denda = $this->input->post('kd_denda');
        $nominal = $this->input->post('nominal');
        $keterangan = $this->input->post('keterangan');

            $data = array(
                'kd_denda'    => $kd_denda,               
                'nominal'    => $nominal,               
                'keterangan'    => $keterangan              
            );
        $where = array(
            'id_denda' => $id_denda
        );
        $this->perpusModel->update_data('tbl_denda', $data, $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil diubah
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('admin/denda');   

    }
}