<?php

class Anggota extends CI_Controller
{
    public function __construct()
    {


        parent::__construct();
        //untuk mengecek apakah sudah ada session di dasbord

        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
            Silahkan login terlebih dulu
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('login');
        }
    }
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Anggota";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['anggota'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE tbl_user.id_role='2'")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('anggota', $data);
        $this->load->view('template_page/footer', $data);
        
    }

     public function create()
    {
         $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Anggota";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('createAnggota', $data);
        $this->load->view('template_page/footer');
    }

     public function InputProses()
    {
        $no_user = $this->input->post('no_user');
        $nama_user = $this->input->post('nama_user');
        $jenkel = $this->input->post('jenkel');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $alamat = $this->input->post('alamat');
        $no_telp = $this->input->post('no_telp');
        $email = $this->input->post('email');
        $username = $this->input->post('username');
        $password = MD5($this->input->post('password'));
        $foto   = $_FILES['foto']['name'];
        $status_akun="1";
        $id_role="2";
     
        if ($foto = '') {
        } else {
            $config['upload_path'] = './api/upload';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('foto')) {
                echo $this->upload->display_errors();
                die();
            } else {
                $foto = $this->upload->data('file_name');
            }
        }
         //CEK APAKAH DATA SUDAH TERINPUT
        //cek email
        $cekNo = $this->perpusModel->cek_noUser($no_user);
        if ($cekNo == FALSE) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-danger">Data Gagal Ditambahkan</span>
            NIS Siswa telah terdaftar, silahkan input NIS lain!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('admin/anggota/create');
        }   

        $cekEmail = $this->perpusModel->cek_emailUser($email);
        if ($cekEmail == FALSE) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-danger">Data Gagal Ditambahkan</span>
            Email telah digunakan, silahkan input email lain!
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('admin/anggota/create');
       }

         $cekQuery = $this->perpusModel->cek_prosesReg($username);

        if ($cekQuery == FALSE) {
             $this->session->set_flashdata('pesen', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
             <span class="badge badge-pill badge-danger">Register Gagal!</span>
             Username telah digunakan, silahkan input data lain!
             <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
             </button>
             </div>');
             redirect('admin/anggota/create');
        } else {
            $data = array(
                'no_user'    => $no_user,
                'nama_user'  => $nama_user,
                'jenkel'       => $jenkel,
                'tempat_lahir'  => $tempat_lahir,
                'tgl_lahir'        => $tgl_lahir,
                'alamat'        => $alamat,
                'no_telp'     => $no_telp,
                'email'     => $email,
                'username'       => $username,
                'password'       => $password,
                'foto'           => $foto,
                'status_akun'      => $status_akun,
                'id_role'      => $id_role
            );
            $this->perpusModel->insert_data('tbl_user', $data);
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-success">Sukses</span>
           Data Berhasil Ditambahkan
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            // $token=hash('sha256', md5(date('Y-m-d'))) ;
            // $email_bkl =$_POST['email_bkl'];
            // $token_bkl=$email_bkl.$token;
			// $this->load->file('api/customer/email3.php');
            redirect('admin/anggota');
        }
    
    }

    public function hapusData($id_user)
    {
        $where = array('id_user' => $id_user);
        $this->perpusModel->hapus_data('tbl_user', $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>');
        redirect('admin/anggota');
    }

     public function editData($id_user)
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Anggota";
        
        $where = $id_user;
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['anggota'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE tbl_user.id_role='2'")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('editAnggota', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function editAkun()
    {
        $id_user = $this->input->post('id_user');
        $no_user = $this->input->post('no_user');
        $nama_user = $this->input->post('nama_user');
        $jenkel = $this->input->post('jenkel');
        $tempat_lahir = $this->input->post('tempat_lahir');
        $tgl_lahir = $this->input->post('tgl_lahir');
        $alamat = $this->input->post('alamat');
        $no_telp = $this->input->post('no_telp');
        $username = $this->input->post('username');
        $password = $this->input->post('password');
        $konfirmasiPass = $this->input->post('konfirmasiPass');

        // var_dump($id_user);
        // die;

        $fileLama   = $this->input->post('fileLama');
        if ($_FILES['foto']['error'] === 4) {
            $foto = $fileLama;
        } else {
            $config['upload_path'] = './api/upload';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('foto')) {
                echo $this->upload->display_errors();
                die();
            } else {
                $foto = $this->upload->data('file_name');
            }
        }

        if (!empty($password)) {
            if ($password != $konfirmasiPass) {
                $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                        <span class="badge badge-pill badge-danger">Gagal!</span>
                        Konfirmasi Password tidak sama!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>');
                redirect('admin/anggota/editData/'.$id_user);
            } else {
                $tes = $this->input->post('password');
                $password = MD5($this->input->post('password'));
            }
        } else {
            $password = $this->input->post('passwordLama');
        }
        $data = array(
            'no_user'       => $no_user,
            'nama_user'       => $nama_user,
            'jenkel'       => $jenkel,
            'tempat_lahir'       => $tempat_lahir,
            'tgl_lahir'       => $tgl_lahir,
            'alamat'       => $alamat,
            'no_telp'       => $no_telp,
            'username'       => $username,
            'password'       => $password,
            'foto'       => $foto
        );
        $where = array(
            'id_user' => $id_user
        );
        $this->perpusModel->update_data('tbl_user', $data, $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil diubah
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('admin/anggota');   

    }
}