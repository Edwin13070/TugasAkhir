<?php

class Peminjaman extends CI_Controller
{
    public function __construct()
    {


        parent::__construct();
        //untuk mengecek apakah sudah ada session di dasbord

        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
                Silahkan login terlebih dulu
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>');
            redirect('login');
        }
    }
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Peminjaman";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['pinjam'] = $this->db->query("SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, admin.nama_user AS nama_admin
            FROM tbl_pinjam
            INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
            LEFT JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
            WHERE status_pinjam='1' OR status_pinjam='2' OR status_pinjam='5' ORDER BY id_pinjam DESC
            ")->result();

        //setting durasi booking (mengambil durasi saat ini)
        $this->load->model('perpusModel');
        $data['max_hari'] = $this->perpusModel->get_durasi();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('peminjaman', $data);
        $this->load->view('template_page/footer', $data);
        
    }

    public function create()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Peminjaman";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['peminjam'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE hak_akses='anggota'")->result();

        //kode otomatis
        $this->load->model('perpusModel');
        $data['pnj'] = $this->perpusModel->KodePinjam();

        $data['buku'] = $this->db->query("SELECT * FROM tbl_buku INNER jOIN tbl_kategori ON tbl_buku.id_ktg=tbl_kategori.id_ktg ORDER BY kd_buku DESC")->result();
        
        

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('createPinjam', $data);
        $this->load->view('template_page/footer');
    }

    public function InputProses()
    {
        $kd_pinjam = $this->input->post('kd_pinjam');
        $tanggal_pinjam = $this->input->post('tanggal_pinjam');
        $tanggal_booking = date('Y-M-d');
        $durasi = $this->input->post('durasi');
        $deadline_kembali = date('Y-m-d', strtotime($tanggal_pinjam . ' + ' . $durasi . ' days'));
        $status_pinjam = "2";
        $notifikasi_email = "0";
        $id_anggota = $this->input->post('id_anggota');
        $id_admin = $this->session->userdata('id_user');


        //CEK APAKAH DATA SUDAH TERINPUT
        $cekPeminjam = $this->perpusModel->cekDataPinjam($id_anggota);


        if ($cekPeminjam == FALSE) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                <span class="badge badge-pill badge-danger">Peminjaman Gagal!</span>
                Peminjam terdaftar belum mengembalikan buku yang sebelumnya
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>');
            $this->session->unset_userdata('cart');
            redirect('admin/peminjaman');
            die;
        }

        $data_pinjam = array(
            'kd_pinjam' => $kd_pinjam,
            'tanggal_booking' => $tanggal_pinjam,
            'tanggal_pinjam' => $tanggal_pinjam,
            'durasi' => $durasi,
            'deadline_kembali' => $deadline_kembali,
            'status_pinjam' => $status_pinjam,
            'notifikasi_email' => $notifikasi_email,
            'id_anggota' => $id_anggota,
            'id_admin' => $id_admin
        );


        $hitungcart = array_values(unserialize($this->session->userdata('cart')));
        if (empty($hitungcart)) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                <span class="badge badge-pill badge-danger">Gagal</span>
                Anda belum memilih buku, tidak dapat melakukan peminjaman
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>');
            redirect('admin/peminjaman');
            die;
        }

        $proses1 = $this->perpusModel->insert_data('tbl_pinjam', $data_pinjam);

        if ($proses1) {
            $kd_pinjam = $this->input->post('kd_pinjam');

            // Ambil id_pinjam dari tabel tbl_pinjam berdasarkan kd_pinjam yang baru saja ditambahkan
            $query = $this->db->query("SELECT id_pinjam FROM tbl_pinjam WHERE kd_pinjam='$kd_pinjam'");

            if ($query->num_rows() > 0) {
                $row = $query->row();
                $id_pinjam = $row->id_pinjam;

                $hasil_cart = array_values(unserialize($this->session->userdata('cart')));
                $data_detail = array(); // Inisialisasi array untuk data detail

                foreach ($hasil_cart as $isi) {
                    $id_buku = $isi['id_buku'];

                // Cek stok buku sebelum menambahkan data detail
                    $stok_buku = $this->perpusModel->get_stok_buku($id_buku);

                    if ($stok_buku >= 1) {
                    // Stok buku mencukupi, tambahkan ke data detail
                        $data_detail[] = array(
                            'id_pinjam' => $id_pinjam,
                            'id_buku' => $id_buku
                        );

                    // Kurangi stok buku sebanyak 1
                        $this->perpusModel->kurangi_stok_buku($id_buku);
                    } else {
                     $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
                        <span class="badge badge-pill badge-danger">Gagal</span>
                        Mohon Maaf Stok Buku Kosong
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                        </div>');
                     $this->session->unset_userdata('cart');
                     $where = array('id_pinjam' => $id_pinjam);
                     $this->perpusModel->hapus_data('tbl_pinjam', $where);
                     redirect('admin/peminjaman');
                     die;
                 }
             }

             $total_array = count($data_detail);
             if ($total_array != 0) {
                // Gunakan 'tbl_detail' sebagai tabel untuk memasukkan detail peminjaman
                $this->db->insert_batch('tbl_detail', $data_detail);

                // Kosongkan session 'cart' setelah data berhasil ditambahkan
                $this->session->unset_userdata('cart');
            }
        }
    }

    $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Sukses</span>
        Data Berhasil Ditambahkan
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>');
    redirect('admin/peminjaman');
}





public function buku()
{
    $id = $this->input->post('kode_buku');
    $cart = unserialize($this->session->userdata('cart'));

    if (!empty($cart)) {
        $index = $this->exists($id);

        if ($index !== -1) {
            $this->del_cart($id); // Hapus item jika sudah ada dalam keranjang belanja
        }
    }

    $row = $this->db->query("SELECT * FROM tbl_buku WHERE kd_buku ='$id'");

    if ($row->num_rows() > 0) {
        $tes = $row->row();
        $item = array(
            'id'      => $id,
            'qty'     => 1,
            'id_buku' => $tes->id_buku,
            'name'    => $tes->judul,
            'options' => array('no_buku' => $tes->no_buku, 'thn' => $tes->thn_terbit, 'penerbit' => $tes->penerbit)
        );

        if (!$this->session->has_userdata('cart')) {
            $cart = array($item);
            $this->session->set_userdata('cart', serialize($cart));
        } else {
            $cart = array_values(unserialize($this->session->userdata('cart')));
            $index = $this->exists($id);

            if ($index == -1) {
                array_push($cart, $item);
                $this->session->set_userdata('cart', serialize($cart));
            } else {
                $cart[$index]['qty']++;
                $this->session->set_userdata('cart', serialize($cart));
            }
        }
    } else {
        // Handle jika ID buku tidak ditemukan
    }
}



public function buku_list()
{
    ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Judul</th>
                <th>Penerbit</th>
                <th>Tahun</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach (array_values(unserialize($this->session->userdata('cart'))) as $items) {
                ?>
                <tr>
                    <td><?= $no; ?></td>
                    <td><?= $items['name']; ?></td>
                    <td><?= $items['options']['penerbit']; ?></td>
                    <td><?= $items['options']['thn']; ?></td>
                    <td style="width:17%">
                      <a href="javascript:void(0)" class="btn btn-danger btn-sm delete-buku" data-id="<?= $items['id']; ?>">
                        <i class="fa fa-trash"></i>
                    </a>

                </td>
            </tr>
            <script type="text/javascript">
                $(document).on("click", ".delete-buku", function() {
                    var id = $(this).data("id");
                    var tombolHapus = $(this); // Simpan referensi ke elemen tombol

                    // Tambahkan kode AJAX untuk menghapus item dengan ID tertentu di sini
                    $.ajax({
                        type: "POST",
                        url: "<?php echo base_url('admin/peminjaman/del_cart');?>",
                        data: { buku_id: id },
                        success: function() {
                            // Hapus baris tabel yang sesuai dengan ID jika diperlukan
                            tombolHapus.closest("tr").remove(); // Menggunakan referensi tombolHapus
                            console.log("Menghapus item dengan ID: " + id);
                        },
                        error: function(xhr, status, error) {
                            console.log("Terjadi kesalahan: " + error);
                        }
                    });

                });

            </script>

            <?php
            $no++;
        }
        ?>
    </tbody>
</table>
<?php
foreach (array_values(unserialize($this->session->userdata('cart'))) as $items) {
    ?>
    <input type="hidden" value="<?= $items['id']; ?>" name="idbuku[]">
    <?php
}
?>
<div id="tampil"></div>
<?php
}


public function del_cart()
{
    $id = $this->input->post('buku_id');
    $cart = unserialize($this->session->userdata('cart'));

    if ($cart !== FALSE) {
        $index = $this->exists($id, $cart);

        if ($index !== -1) {
            unset($cart[$index]);
            $cart = array_values($cart);
            $this->session->set_userdata('cart', serialize($cart));

            if (empty($cart)) {
                $this->session->unset_userdata('cart');
            }

            // Kembalikan tampilan keranjang belanja dengan AJAX
            echo '<script>$("#tampil").load("'.base_url('admin/peminjaman/buku_list').'");</script>';
        } else {
            echo "Buku tidak ditemukan dalam keranjang belanja.";
        }
    } else {
        echo "Keranjang belanja kosong.";
    }
}




private function exists($id)
{
    $cart = unserialize($this->session->userdata('cart'));
    
    if (!empty($cart)) {
        for ($i = 0; $i < count($cart); $i++) {
            if ($cart[$i]['id'] == $id) {
                return $i;
            }
        }
    }
    
    return -1;
}


public function hapusData($id_pinjam)
{
    $where = array('id_pinjam' => $id_pinjam);
    $this->perpusModel->hapus_data('tbl_pinjam', $where);
    $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>');
    redirect('admin/Peminjaman');
}

public function editData($id_pinjam)
{
    $where = $id_pinjam;
    $data['title'] = "E-Perpustakaan";
    $data['menu'] = "Peminjaman";

    $sess = $this->session->userdata('id_user');

    $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$sess'")->result();

    $data['pinjam'] = $this->db->query("SELECT * FROM tbl_pinjam WHERE id_pinjam='$id_pinjam'")->result();


    $data['peminjam'] = $this->db->query("SELECT * FROM tbl_user  
        INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE hak_akses='anggota'")->result();

    $data['buku'] = $this->db->query("SELECT * FROM tbl_detail  
        INNER JOIN tbl_buku ON tbl_detail.id_buku=tbl_buku.id_buku
        INNER JOIN tbl_pinjam ON tbl_detail.id_pinjam=tbl_pinjam.id_pinjam 
        WHERE tbl_detail.id_pinjam='$id_pinjam'
        ")->result();


    $this->load->view('template_page/header', $data);
    $this->load->view('template_page/sidebar',$data);
    $this->load->view('editPinjam', $data);
    $this->load->view('template_page/footer', $data);
}


public function detailPnj($id_pinjam)
{
    $where = $id_pinjam;
    $data['title'] = "E-Perpustakaan";
    $data['menu'] = "Detail Peminjaman";

    $sess = $this->session->userdata('id_user');

    $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$sess'")->result();

    $data['pinjam'] = $this->db->query("SELECT * FROM tbl_pinjam WHERE id_pinjam='$id_pinjam'")->result();


    $data['peminjam'] = $this->db->query("SELECT * FROM tbl_user  
        INNER JOIN role_user ON tbl_user.id_role=role_user.id_role ")->result();

    $data['buku'] = $this->db->query("SELECT * FROM tbl_detail  
        INNER JOIN tbl_buku ON tbl_detail.id_buku=tbl_buku.id_buku
        INNER JOIN tbl_pinjam ON tbl_detail.id_pinjam=tbl_pinjam.id_pinjam 
        WHERE tbl_detail.id_pinjam='$id_pinjam'
        ")->result();


    $this->load->view('template_page/header', $data);
    $this->load->view('template_page/sidebar',$data);
    $this->load->view('detailPinjam', $data);
    $this->load->view('template_page/footer', $data);
}

public function editPeminjaman()
{
    $id_pinjam = $this->input->post('id_pinjam');
    $tanggal_pinjam = $this->input->post('tanggal_pinjam');
    $durasi = $this->input->post('durasi');
    $deadline_kembali = date('Y-m-d', strtotime($tanggal_pinjam . ' + ' . $durasi . ' days'));
    $id_admin = $this->session->userdata('id_user');

    // Periksa apakah tanggal yang diinput telah berlalu
    $tanggal_sekarang = date('Y-m-d');
    if (strtotime($tanggal_pinjam) < strtotime($tanggal_sekarang)) {
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-danger">Edit Gagal!</span>
            Tanggal yang diinput telah berlalu, permintaan ditolak.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>');
        redirect('admin/peminjaman');
        return;
    }

    $data = array(
        'tanggal_pinjam' => $tanggal_pinjam,
        'durasi' => $durasi,
        'deadline_kembali' => $deadline_kembali,
        'id_admin' => $id_admin
    );
    $where = array(
        'id_pinjam' => $id_pinjam
    );
    $this->perpusModel->update_data('tbl_pinjam', $data, $where);
    $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Sukses</span>
        Data berhasil diubah
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>');
    redirect('admin/peminjaman');
}


public function konfPNJ($id_pinjam)
{
    $where = array('id_pinjam' => $id_pinjam);

    $this->load->model('perpusModel');
    $Confirm_kd = $this->perpusModel->KodePinjam();
    $kd_pinjam = $Confirm_kd;
    $status_pinjam = "5";
    $id_admin = $this->session->userdata('id_user');

    // var_dump($id_pinjam);
    // var_dump($kd_pinjam);
    // var_dump($status_pinjam);
    // var_dump($id_admin);
    // die;

    $data = array(
        'kd_pinjam' => $kd_pinjam,
        'status_pinjam' => $status_pinjam,
        'id_admin' => $id_admin
    );
    $where = array(
        'id_pinjam' => $id_pinjam
    );
    $this->perpusModel->update_data('tbl_pinjam', $data, $where);
    $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Sukses</span>
        Konfirmasi peminjaman berhasil dilakukan.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>');
    redirect('admin/peminjaman');
}

public function konfKMB($id_pinjam)
{
    //edit tbl_pinjam
    $id_pinjam = $id_pinjam;
    $tgl_kembali = date('Y-m-d');
    $status_pinjam = "3";
    $id_admin = $this->session->userdata('id_user');
    $data = array(
        'status_pinjam' => $status_pinjam,
        'id_admin' => $id_admin
    );


    $detail_peminjaman = $this->perpusModel->ambil_idDetail($id_pinjam);


    if (!empty($detail_peminjaman)) {
        foreach ($detail_peminjaman as $detail) {
        // Ambil ID buku dari setiap detail peminjaman
            $id_buku = $detail->id_buku;

        // Tambahkan stok buku dengan ID buku yang sesuai
            $this->perpusModel->tambah_stok_buku($id_buku);
        }
    }

    // Ubah status peminjaman menjadi "Pengembalian" atau sesuai dengan kebutuhan
    $this->perpusModel->update_status_peminjaman($id_pinjam, 3); // Misalnya, status "Pengembalian" adalah 3

    $data_kembali = array(
        'tanggal_kembali' => $tgl_kembali,
        'id_pinjam`' => $id_pinjam,
        'id_admin' => $id_admin
    );

    //insert tbl_kembali
    $proses = $this->perpusModel->insert_data('tbl_kembali', $data_kembali);
    

    //fungsi untuk menghitung denda.. dengan syarat apabila tgl_kembali > $deadline
    $id_pinjam = $id_pinjam;

    $tanggal_kembali = strtotime($this->perpusModel->get_tanggal_kembali_by_id($id_pinjam));
    $deadline = strtotime($this->perpusModel->get_tanggal_kembali_by_id2($id_pinjam));


    $id_denda = $this->perpusModel->get_id_denda_utama();


    if ($tanggal_kembali > $deadline) {
         $this->perpusModel->update_id_denda($id_pinjam, $id_denda);


         //Menghitung nominal total denda
        $id_denda = $this->perpusModel->get_id_denda_utama();
        $nominal_denda = $this->perpusModel->get_nominal_denda($id_denda);
        $selisihDetik2 = $tanggal_kembali - $deadline;
        $selisihHari = floor($selisihDetik2 / (60 * 60 * 24));
        $total_denda = $nominal_denda*$selisihHari;

        $this->perpusModel->update_nominal_denda($id_pinjam, $total_denda);
    }


    $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Sukses</span>
        Konfirmasi pengembalian berhasil dilakukan.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>');
    redirect('admin/pengembalian');
}

    public function setting_durasi()
    {
        if ($this->input->post('durasi_booking')) {
            $durasi_booking = $this->input->post('durasi_booking');
            // Simpan durasi_booking ke database atau tempat penyimpanan yang sesuai
            // Contoh:
            $this->perpusModel->simpan_durasi($durasi_booking);
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-success">Sukses</span>
            Konfirmasi pengembalian berhasil dilakukan.
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('admin/peminjaman');
        }
    }


}