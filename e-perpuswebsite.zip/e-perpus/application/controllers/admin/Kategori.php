<?php

class Kategori extends CI_Controller
{
    public function __construct()
    {


        parent::__construct();
        //untuk mengecek apakah sudah ada session di dasbord

        if (!isset($this->session->userdata['hak_akses'])) {
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-danger">Akses Dilarang!!!</span>
            Silahkan login terlebih dulu
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('login');
        }
    }
    public function index()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "kategori";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['kategori'] = $this->db->query("SELECT * FROM tbl_kategori")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('kategori', $data);
        $this->load->view('template_page/footer', $data);
        
    }

     public function create()
    {
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "Kategori";
        
        $where = $this->session->userdata('id_user');
        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$where'")->result();

        $data['kategori'] = $this->db->query("SELECT * FROM tbl_kategori")->result();

        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('createKategori', $data);
        $this->load->view('template_page/footer');
    }

     public function InputProses()
    {
        $nama_ktg = $this->input->post('nama_ktg');
            $data = array(
                'nama_ktg'    => $nama_ktg              
            );
            $this->perpusModel->insert_data('tbl_kategori', $data);
            $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
            <span class="badge badge-pill badge-success">Sukses</span>
           Data Berhasil Ditambahkan
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>');
            redirect('admin/Kategori');
        
    
    }

    public function hapusData($id_ktg)
    {
        $where = array('id_ktg' => $id_ktg);
        $this->perpusModel->hapus_data('tbl_kategori', $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil dihapus
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>');
        redirect('admin/Kategori');
    }

     public function editData($id_ktg)
    {
        $where = $id_ktg;
        $data['title'] = "E-Perpustakaan";
        $data['menu'] = "kategori";
        
        $sess = $this->session->userdata('id_user');

        $data['profil'] = $this->db->query("SELECT * FROM tbl_user  INNER JOIN role_user ON tbl_user.id_role=role_user.id_role WHERE id_user='$sess'")->result();

        $data['kategori'] = $this->db->query("SELECT * FROM tbl_kategori WHERE id_ktg='$id_ktg'")->result();
        
        $this->load->view('template_page/header', $data);
        $this->load->view('template_page/sidebar',$data);
        $this->load->view('editKtg', $data);
        $this->load->view('template_page/footer', $data);
    }

    public function editKategori()
    {
        $id_ktg = $this->input->post('id_ktg');
        $nama_ktg = $this->input->post('nama_ktg');
        $data = array(
            'nama_ktg'       => $nama_ktg
        );
        $where = array(
            'id_ktg' => $id_ktg
        );
        $this->perpusModel->update_data('tbl_kategori', $data, $where);
        $this->session->set_flashdata('pesan', '<div class="sufee-alert alert with-close alert-success alert-dismissible fade show mt-3">
        <span class="badge badge-pill badge-success">Success</span>
        Data berhasil diubah
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>');
        redirect('admin/Kategori');   

    }
}