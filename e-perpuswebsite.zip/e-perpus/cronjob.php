<?php
// Sambungan ke database (sesuaikan dengan database Anda)
$conn = new mysqli('localhost', 'username', 'password', 'nama_database');

if ($conn->connect_error) {
    die("Koneksi database gagal: " . $conn->connect_error);
}

// Query untuk mendapatkan data peminjaman yang kurang dari 1 hari
$query = "SELECT * FROM peminjaman WHERE DATEDIFF(tanggal_kembali, tanggal_peminjaman) < 1";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Kirim email kepada peminjam buku
        $to = $row['email_peminjam'];
        $subject = 'Pemberitahuan Durasi Peminjaman';
        $message = 'Anda memiliki buku yang harus dikembalikan dalam waktu kurang dari 1 hari.';

        // Gunakan PHPMailer atau fungsi mail() untuk mengirim email
        // ...

        // Setelah mengirim email, Anda bisa menandai peminjaman sebagai sudah diberitahu
        $peminjaman_id = $row['id'];
        $update_query = "UPDATE peminjaman SET sudah_diberitahu = 1 WHERE id = $peminjaman_id";
        $conn->query($update_query);
    }
}

$conn->close();
?>
