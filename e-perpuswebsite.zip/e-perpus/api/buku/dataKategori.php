<?php
require '../connect.php';

if ($con) {
    $sql = "SELECT * FROM tbl_kategori ORDER BY nama_ktg ASC";
    $result = $con->query($sql);
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($outp);
}
mysqli_close($con);
