<?php
require '../connect.php';

$id_buku = $_POST['id_buku'];
if ($con) {
    $sql = "SELECT 
                id_buku, kd_buku, judul,
                no_buku, pengarang, penerbit,
                thn_terbit, stok, CONCAT('assets/foto/',sampul) AS sampul, keterangan_buku, tbl_kategori.id_ktg, tbl_kategori.nama_ktg 
                FROM tbl_buku 
                INNER JOIN tbl_kategori ON tbl_buku.id_ktg=tbl_kategori.id_ktg 
                WHERE id_buku='$id_buku' ";
    $result = $con->query($sql);
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($outp);
}
mysqli_close($con);
