<?php
require '../connect.php';

$id_pinjam = $_POST['id_pinjam'];
if ($con) {
    $sql = "SELECT 
                tbl_buku.id_buku, tbl_buku.kd_buku, tbl_buku.judul,
                tbl_buku.no_buku, tbl_buku.pengarang, tbl_buku.penerbit,
                tbl_buku.thn_terbit, tbl_buku.stok, CONCAT('assets/foto/',tbl_buku.sampul) AS sampul, tbl_buku.keterangan_buku, tbl_kategori.id_ktg, tbl_kategori.nama_ktg 
                FROM tbl_detail 
                INNER JOIN tbl_buku ON tbl_detail.id_buku=tbl_buku.id_buku 
                INNER JOIN tbl_kategori ON tbl_buku.id_ktg=tbl_kategori.id_ktg 
                WHERE tbl_detail.id_pinjam='$id_pinjam' ";
    $result = $con->query($sql);
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($outp);
}
mysqli_close($con);
