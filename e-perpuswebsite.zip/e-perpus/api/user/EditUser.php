<?php

error_reporting(0);
include '../connect.php';

    $id_user = $_POST["id_user"];
    $password = $_POST["password"];
    if ($con) {
        $cek_password=mysqli_query($con,"SELECT * FROM tbl_user WHERE password='$password' AND id_user='$id_user'");
        $r_cek2=mysqli_num_rows($cek_password);

        if ($r_cek2 > 0) {
            $password_fix = $_POST["password"];
            $password = $_POST["password"];
            $hasil= "ini password Lama,TIDAK terenkripsi";
        }else{
            $password = $_POST["password"];
            $password_fix = md5($_POST["password"]);
            $hasil= "ini password baru, terenkripsi";
            
        } 
    }


    $id_user = $_POST["id_user"];
    $nama_user = $_POST["nama_user"];
    $jenkel = $_POST["jenkel"];
    $tempat_lahir = $_POST["tempat_lahir"];
    $tgl_lahir = $_POST["tgl_lahir"];
    $alamat = $_POST["alamat"];
    $no_telp = $_POST["no_telp"];
    $email = $_POST["email"];
    $username = $_POST["username"];
    $password_simpan = $password_fix;


    if($_FILES['foto']['name']!= null){

        //UPLOAD FOTO
        $namaFile   =$_FILES['foto']['name'];
        $ukuranFile =$_FILES['foto']['size'];
        $error      =$_FILES['foto']['error'];
        $tmpName    =$_FILES['foto']['tmp_name'];

        //cek apakah tidak ada gambar yang diuoload

        //cek apakah yg diupload adalah gambar
        $ekstensiGambarValid=['jpg','jpeg','png'];
        $ekstensiGambar     = explode('.',$namaFile);
        $ekstensiGambar     = strtolower(end($ekstensiGambar));
        if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
            $response = array(
                'status' => 0,
                'message' => 'yang anda upload bukan gambar!',
                'result_code' => false
            );
            echo json_encode($response);
            die;
        }

        //cek jika ukurannya terlalu besar
        if ($ukuranFile > 1000000) {
            $response = array(
                'status' => 0,
                'message' => 'Ukuran Gambar terlalu besar!',
                'result_code' => false
            );
            echo json_encode($response);
            die;
        }

        // lolos pengecekan, gambar siap di upload

        //generate nama gambar baruu

        $namaFileBaru  = uniqid();
        $namaFileBaru .='.';
        $namaFileBaru .=$ekstensiGambar;
        
        move_uploaded_file($tmpName,'../upload/'.$namaFileBaru);

        // end upload
    }



    //CEK USERNAME
    if ($con) {
        $sql = "SELECT * FROM tbl_user WHERE username='$username' AND !id_user='$id_user'";
        $result = mysqli_query($con, $sql);
        
 

        $sql2 = "SELECT * FROM tbl_user WHERE email='$email' AND !id_user='$id_user'";
        $result2 = mysqli_query($con, $sql2);

            
        //CEK EMAIL
        if (mysqli_num_rows($result2) > 0) {
            $response = array(
                'status' => 0,
                'message' => 'Email sudah terdaftar!',
                'result_code' => false
            );
            echo json_encode($response);
            die;
        }
        
        else if (mysqli_num_rows($result) > 0) {
            $response = array(
                'status' => 0,
                'message' => 'Username Sudah Digunakan!',
                'result_code' => false
            );
            echo json_encode($response);
            die;
        } 
       
        else {

            $sql = "UPDATE tbl_user SET nama_user='$nama_user', jenkel='$jenkel', tempat_lahir='$tempat_lahir', tgl_lahir='$tgl_lahir',alamat='$alamat', no_telp='$no_telp', email='$email', username='$username',  password='$password_simpan', foto='$namaFileBaru' WHERE id_user='$id_user'";
            
          
            if (mysqli_query($con, $sql)) {
                $response = array(
                    'status' => 1,
                    'message' => 'Data Berhasil Diubah',
                    'result_code' => true
                );
                echo json_encode($response);
                die;
            } else {
                $response = array(
                    'status' => 0,
                    'message' => 'Gagal Membuat Akun',
                    'result_code' => false
                );
                echo json_encode($response);
                die;
            }
        }
    } else {
        $response = array(
            'status' => 0,
            'message' => 'Gagal Terhubung',
            'result_code' => false
        );
        echo json_encode($response);
        die;
    }

