<?php
require '../connect.php';

$id_user = $_POST['id_user'];
$hak_akses = $_POST['hak_akses'];

//Cek Hak Akses
$aksesUser = mysqli_query($con,"SELECT tbl_user.*, role_user.hak_akses FROM tbl_user 
 INNER JOIN role_user ON tbl_user.id_role=role_user.id_role  WHERE id_user='$id_user' AND hak_akses='anggota' ");

if (mysqli_num_rows($aksesUser) > 0) {
   $row = mysqli_fetch_assoc($aksesUser);
   $filename   = $row['foto'];
   $dir        = '/api/upload/';
   $img_path   = $dir.$filename;
   $status = "Data User";
   $result_code = true;
   $data = [
      'id' => $row['id_user'],
      'nis' => $row['no_user'],
      'nama' => $row['nama_user'],
      'jenkel' => $row['jenkel'],
      'tempat_lahir' => $row['tempat_lahir'],
      'tgl_lahir' => $row['tgl_lahir'],
      'alamat' => $row['alamat'],
      'no_telp' => $row['no_telp'],
      'username' => $row['username'],
      'password' => $row['password'],
      'email' => $row['email'],
      'hak_akses' => $row['hak_akses'],
      'foto' => $img_path
   ];
   echo json_encode(array($data));
   die;
   
}
else{
 $data = [
   'Pesan_Error' => "TIDAK ADA DATA!"
];
echo json_encode(array($data));
die;
}


mysqli_close($con);
?>
