<?php
require '../connect.php';

//tangkap id
$email = $_POST["email"];

if ($con) {
   $sql_cek=mysqli_query($con,"SELECT * FROM tbl_user WHERE email='$email'");
   $email_cek=mysqli_num_rows($sql_cek);

   if ($email_cek == 0) {
         $response = array(
            'status' => 0,
            'message' => 'Akun anda tidak ditemukan, Ingat kembali email yang anda gunakan!',
            'result_code' => false
         );
      echo json_encode($response);
      die;
   }else{
      $tok_usr=hash('sha256', md5(date('Y-m-d'))) ;
      $token_akun=$email.$tok_usr;
      $status_akun ="1";
      $sql = "UPDATE tbl_user SET token_akun='$token_akun', status_akun='$status_akun' WHERE email='$email'";

      //include kirim email
      include("email_ForgPass.php"); 
      
      if (mysqli_query($con, $sql)) {
         $response = array(
            'status' => 1,
            'message' => 'Kode Verifikasi telah dikirim, cek email anda untuk verifikasi!',
            'result_code' => true
         );
         echo json_encode($response);
         die;
      }
   }     

}
mysqli_close($con);

?>
