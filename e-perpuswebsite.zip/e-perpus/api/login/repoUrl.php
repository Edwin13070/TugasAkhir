<?php 
include '../connect.php';

$urlTujuan ='https://e-perpussmkn1trucuk.000webhostapp.com';

?>