<?php

error_reporting(0);
include '../connect.php';

$no_user = $_POST["no_user"];
$nama_user = $_POST["nama_user"];
$jenkel = $_POST["jenkel"];
$tempat_lahir = $_POST["tempat_lahir"];
$tgl_lahir = $_POST["tgl_lahir"];
$alamat = $_POST["alamat"];
$no_telp = $_POST["no_telp"];
$email = $_POST["email"];
$username = $_POST["username"];
$password = md5($_POST["password"]);
$tokenhas=hash('sha256', md5(date('Y-m-d'))) ;
$token=$email.$tokenhas;

if($_FILES['foto']['name']!= null){

        //UPLOAD FOTO
    $namaFile   =$_FILES['foto']['name'];
    $ukuranFile =$_FILES['foto']['size'];
    $error      =$_FILES['foto']['error'];
    $tmpName    =$_FILES['foto']['tmp_name'];

        //cek apakah tidak ada gambar yang diuoload

        //cek apakah yg diupload adalah gambar
    $ekstensiGambarValid=['jpg','jpeg','png'];
    $ekstensiGambar     = explode('.',$namaFile);
    $ekstensiGambar     = strtolower(end($ekstensiGambar));
    if (!in_array($ekstensiGambar, $ekstensiGambarValid)) {
        $response = array(
            'status' => 0,
            'message' => 'yang anda upload bukan gambar!',
            'result_code' => false
        );
        echo json_encode($response);
        die;
    }

        //cek jika ukurannya terlalu besar
    if ($ukuranFile > 5000000) {
        $response = array(
            'status' => 0,
            'message' => 'Ukuran Gambar terlalu besar!',
            'result_code' => false
        );
        echo json_encode($response);
        die;
    }

        // lolos pengecekan, gambar siap di upload

        //generate nama gambar baruu

    $namaFileBaru  = uniqid();
    $namaFileBaru .='.';
    $namaFileBaru .=$ekstensiGambar;

    move_uploaded_file($tmpName,'../upload/'.$namaFileBaru);

        // end upload
}


if ($con) {

    //cek nis apabila sudah terdaftar
    $sql_nis = "SELECT * FROM tbl_user WHERE no_user='$no_user'";
    $result_nis = mysqli_query($con, $sql_nis);

    //Cek username
    $sql = "SELECT * FROM tbl_user WHERE username='$username'";
    $result = mysqli_query($con, $sql);

    //cek email user
    $sql_cek = mysqli_query($con, "SELECT * FROM tbl_user WHERE email='" . $email . "'");
    $r_cek = mysqli_num_rows($sql_cek);

    if ($r_cek > 0) {
        $response = array(
            'status' => 0,
            'message' => 'Email sudah pernah terdaftar!',
            'result_code' => false
        );
        echo json_encode($response);
        die;
    } else if (mysqli_num_rows($result) > 0) {
        $response = array(
            'status' => 0,
            'message' => 'Username Sudah Digunakan!',
            'result_code' => false
        );
        echo json_encode($response);
        die;
    }else if(mysqli_num_rows($result_nis) > 0){
        $response = array(
            'status' => 0,
            'message' => 'NIS Sudah Terdaftar!',
            'result_code' => false
        );
        echo json_encode($response);
        die;
    } else {
        // Jika data kosong maka insert ke tabel;
        $sql = "INSERT INTO tbl_user (no_user, nama_user, jenkel, tempat_lahir, tgl_lahir, alamat, no_telp, email, username, password, status_akun, token_akun, foto , id_role)
        VALUES ('$no_user','$nama_user','$jenkel','$tempat_lahir','$tgl_lahir','$alamat', '$no_telp', '$email', '$username', '$password' , '0' , '$token' ,'$namaFileBaru', '2')";

        // Include kirim email verifikasi akun
        include("mail.php");

        if (mysqli_query($con, $sql)) {
            $response = array(
                'status' => 1,
                'message' => 'Berhasil membuat akun, Cek email anda untuk verifikasi',
                'result_code' => true
            );
            echo json_encode($response);
            die;
        } else {
            $response = array(
                'status' => 0,
                'message' => 'Gagal membuat akun',
                'result_code' => false
            );
            echo json_encode($response);
            die;
        }
    }
} else {
    $response = array(
        'status' => 0,
        'message' => 'Gagal Terhubung',
        'result_code' => false
    );
    echo json_encode($response);
    die;
}
?>