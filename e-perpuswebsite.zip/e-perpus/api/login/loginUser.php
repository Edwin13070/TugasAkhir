<?php
include '../connect.php';

$username = $_POST["username"];
$password = md5($_POST["password"]);


if ($con) {
    $query_a = mysqli_query($con, " SELECT tbl_user.*, role_user.hak_akses FROM tbl_user 
        INNER JOIN role_user ON tbl_user.id_role=role_user.id_role 
        WHERE email='$username' OR username='$username' AND password='$password' AND hak_akses='anggota'");

    if (mysqli_num_rows($query_a) > 0) {
        $cek_aktivasi = mysqli_query($con, " SELECT * FROM tbl_user WHERE email='$username' OR username='$username' AND password='$password'");
        while ($data=mysqli_fetch_array($cek_aktivasi)) {
            if ($data['status_akun'] =='0') {
           
                $status = "Akun Anda belum aktif, silahkan verifikasi email terlebih dulu";
                $result_code = false;
                echo json_encode(array('status' => $status, 'result_code' => $result_code));
            }
            else{
                $row = mysqli_fetch_assoc($query_a);
                $filename   = $row['foto'];
                $dir        = '/api/upload/';
                $img_path   = $dir.$filename;
                $status = "Anda Berhasil Login";
                $result_code = true;
                $data = [
                    'id' => $row['id_user'],
                    'nis' => $row['no_user'],
                    'nama' => $row['nama_user'],
                    'jenkel' => $row['jenkel'],
                    'tempat_lahir' => $row['tempat_lahir'],
                    'tgl_lahir' => $row['tgl_lahir'],
                    'alamat' => $row['alamat'],
                    'no_telp' => $row['no_telp'],
                    'username' => $row['username'],
                    'password' => $row['password'],
                    'email' => $row['email'],
                    'hak_akses' => $row['hak_akses'],
                    'foto' => $img_path
            ];
                echo json_encode(array('status' => $status, 'result_code' => $result_code, 'data' => $data));
            }
        }
    } else {
        $status = "Username atau Password Salah!";
        $result_code = false;
        echo json_encode(array('status' => $status, 'result_code' => $result_code));
    }
} else {
    $status = "failed";
    echo json_encode(array('status' => $status), JSON_FORCE_OBJECT);
}

mysqli_close($con);
