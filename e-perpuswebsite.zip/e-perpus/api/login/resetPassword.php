<?php
require '../connect.php';

//tangkap id
$email = $_POST["email"];
$password = md5($_POST["password"]);

if ($con) {
   $sql_cek=mysqli_query($con,"SELECT * FROM tbl_user WHERE email='$email' AND status_akun='1' ");
   $email_cek=mysqli_num_rows($sql_cek);

   if ($email_cek > 0) {
         $response = array(
            'status' => 0,
            'message' => 'Harap konfirmasi email Anda terlebih dulu untuk merubah password.',
            'result_code' => false
         );
      echo json_encode($response);
      die;
   }else{
      $sql = "UPDATE tbl_user SET password='$password', status_akun='1' WHERE email='$email'";
  
      if (mysqli_query($con, $sql)) {
         $response = array(
            'status' => 1,
            'message' => 'Password berhasil diubah. Silakan login dengan password baru.',
            'result_code' => true
         );
         echo json_encode($response);
         die;
      }
   }     

}
mysqli_close($con);

?>
