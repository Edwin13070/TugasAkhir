<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require "vendor/autoload.php";
include "repoUrl.php";
$mail = new PHPMailer(true);
$mail->SMTPDebug = 0; 
$mail->isSMTP();
$mail->Host = "ssl://smtp.gmail.com";
$mail->SMTPAuth = true;

//ganti dengan email dan password yang akan di gunakan sebagai email pengirim
$mail->Username = '';
$mail->Password = 'jcjikbwobdxfaprs';
$mail->SMTPSecure = 'ssl';
$mail->SMTPOptions = array(
'ssl' => array(
'verify_peer' => false,
'verify_peer_name' => false,
'allow_self_signed' => true
)
);
$mail->Port = 465;
$email = $_POST["email"];
$tokenhas=hash('sha256', md5(date('Y-m-d'))) ;
$token_akun=$email.$tokenhas;
//ganti dengan email yg akan di gunakan sebagai email pengirim
$mail->setFrom('aseggaf27@gmail.com', 'E-Bengkel');
$mail->addAddress($_POST['email'], $_POST['nama_user']);
$mail->isHTML(true);
$mail->Subject = "Aktivasi pendaftaran Member";
$mail->Body = "Selamat, anda berhasil membuat akun. Untuk mengaktifkan akun anda silahkan klik link dibawah ini.<a href='".$urlTujuan."/api/login/activation.php?t=".$token_akun."'>"."Klik Disini"."</a>";
$mail->send();






