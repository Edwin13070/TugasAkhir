<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require "vendor/autoload.php";
include "repoUrl.php";
$mail = new PHPMailer(true);
$mail->SMTPDebug = 0; 
$mail->isSMTP();
$mail->Host = "ssl://smtp.gmail.com";
$mail->SMTPAuth = true;
//ganti dengan email dan password yang akan di gunakan sebagai email pengirim
$mail->Username = '';
$mail->Password = 'jcjikbwobdxfaprs';
$mail->SMTPSecure = 'ssl';
$mail->SMTPOptions = array(
'ssl' => array(
'verify_peer' => false,
'verify_peer_name' => false,
'allow_self_signed' => true
)
);
$mail->Port = 465;
$email =$_POST['email'];
$tok_usr=hash('sha256', md5(date('Y-m-d'))) ;
$token_akun=$email.$tok_usr;
//ganti dengan email yg akan di gunakan sebagai email pengirim
$mail->setFrom('aseggaf27@gmail.com', 'E-Bengkel');
$mail->addAddress($email);
$mail->isHTML(true);
$mail->Subject = "Verifikasi akun email";
$mail->Body = "Klik link berikut ini untuk verikasi email anda.<a href='".$urlTujuan."/api/login/activation_ForgPass.php?t=".$token_akun."'>"."Klik Disini"."</a>";
$mail->send();






