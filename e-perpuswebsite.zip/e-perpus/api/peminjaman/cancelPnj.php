<?php
include '../connect.php';
$id_pinjam = $_POST["id_pinjam"];


//cek apakah sudah di konfirmasi apa belum
$cekKonfirmasi = mysqli_query($con, "SELECT status_pinjam FROM tbl_pinjam WHERE id_pinjam='$id_pinjam'");
$cek = mysqli_fetch_assoc($cekKonfirmasi); // Mengambil hasil query
$status_pinjam = $cek['status_pinjam'];
if ($status_pinjam == "2") {
    $response = array(
            'status' => 0,
            'message' => 'Mohon maaf permintaan anda baru saja dikonfirmasi admin, silahkan hubungi admin untuk pembatalan',
            'result_code' => false
        );
    echo json_encode($response);
    die();
}



//menambah stok apabila ada user cancel peminjaman
$ambilidBuku = mysqli_query($con, "SELECT id_buku FROM tbl_detail WHERE id_pinjam='$id_pinjam'");
 if (mysqli_num_rows($ambilidBuku) > 0) {
    $row = mysqli_fetch_assoc($ambilidBuku); // Mengambil hasil query
    $id_buku = $row['id_buku'];

    $stok = mysqli_query($con, "SELECT stok FROM tbl_buku WHERE id_buku='$id_buku'");
    $rowStok = mysqli_fetch_assoc($stok);
    $stok = $rowStok['stok'];
    $stok += 1;
    $update = mysqli_query($con, "UPDATE tbl_buku SET stok='$stok' WHERE id_buku='$id_buku'");
 }


if ($con) {
    $sql = "UPDATE tbl_pinjam SET status_pinjam='4' WHERE id_pinjam='$id_pinjam' ";
    if (mysqli_query($con, $sql)) {
        $response = array(
            'status' => 1,
            'message' => 'Cancel Berhasil, silahkan refresh halaman aktivitas anda',
            'result_code' => true
        );
        echo json_encode($response);
        die();

    } else {
        $response = array(
            'status' => 0,
            'message' => 'Terjadi Kesalahan',
            'result_code' => false
        );
        echo json_encode($response);
        die();
    }



}