<?php
require '../connect.php';

$today = date('Y-m-d'); // Tanggal hari ini dalam format Y-m-d

// Mengambil data peminjaman yang memiliki deadline kembali yang sudah terlampaui
$query = mysqli_query($con, "SELECT * FROM tbl_pinjam WHERE status_pinjam='1' AND deadline_kembali < '$today'");

while ($row = mysqli_fetch_assoc($query)) {
    $id_pinjam = $row['id_pinjam'];

    // Mengambil id_buku yang terkait dengan peminjaman
    $ambilidBuku = mysqli_query($con, "SELECT id_buku FROM tbl_detail WHERE id_pinjam='$id_pinjam'");
    
    while ($rowBuku = mysqli_fetch_assoc($ambilidBuku)) {
        $id_buku = $rowBuku['id_buku'];

        // Mengambil dan mengupdate stok buku
        $stokQuery = mysqli_query($con, "SELECT stok FROM tbl_buku WHERE id_buku='$id_buku'");
        $rowStok = mysqli_fetch_assoc($stokQuery);
        $stok = $rowStok['stok'] + 1;
        
        // Update stok buku
        $update = mysqli_query($con, "UPDATE tbl_buku SET stok='$stok' WHERE id_buku='$id_buku'");
    }
    
    // Update status_pinjam setelah selesai memperbarui stok buku
    $updateStatus = mysqli_query($con, "UPDATE tbl_pinjam SET status_pinjam='6' WHERE id_pinjam='$id_pinjam'");
}

?>
