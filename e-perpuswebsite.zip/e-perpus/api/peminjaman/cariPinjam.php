<?php
require '../connect.php';

$kata_cari = $_POST['kata_cari'];
$id_anggota = $_POST["id_anggota"];

if ($con) {
    $sql = "SELECT id_pinjam, kd_pinjam, tanggal_pinjam, durasi, deadline_kembali, status_pinjam 
           FROM tbl_pinjam WHERE id_anggota='$id_anggota'";

    // Cek apakah 'kata_cari' adalah format tanggal
    if (!empty($kata_cari)) {
        if (strtotime($kata_cari) !== false) {
            // Jika 'kata_cari' adalah format tanggal, ubah formatnya menjadi 'Y-m-d'
            $kata_cari = date('Y-m-d', strtotime($kata_cari));
        }

        // Tambahkan filter berdasarkan kata_cari jika tidak kosong
        $sql .= " AND (kd_pinjam LIKE '%$kata_cari%' OR tanggal_pinjam LIKE '%$kata_cari%')";
    }

    $sql .= " ORDER BY id_pinjam DESC";
    $result = $con->query($sql);
    $outp = $result->fetch_all(MYSQLI_ASSOC);

    // Ubah format tanggal
    foreach ($outp as &$row) {
        // Ubah format tanggal dari Y-m-d menjadi d-m-Y
        $row['tanggal_pinjam'] = date('d-m-Y', strtotime($row['tanggal_pinjam']));
        $row['deadline_kembali'] = date('d-m-Y', strtotime($row['deadline_kembali']));
    }

    echo json_encode($outp);
}
