<?php
require '../connect.php';

// Tangkap id
$id_pinjam = $_POST["id_pinjam"];

if ($con) {
   $sql = "SELECT id_pinjam, kd_pinjam, tanggal_pinjam, durasi, deadline_kembali, status_pinjam 
           FROM tbl_pinjam WHERE id_pinjam='$id_pinjam' ORDER BY id_pinjam DESC";
    $result = $con->query($sql);
    $outp = $result->fetch_all(MYSQLI_ASSOC);

     // Ubah format tanggal
    foreach ($outp as &$row) {
        // Ubah format tanggal dari Y-m-d menjadi d-m-Y
        $row['tanggal_pinjam'] = date('d-m-Y', strtotime($row['tanggal_pinjam']));
        $row['deadline_kembali'] = date('d-m-Y', strtotime($row['deadline_kembali']));
    }

    echo json_encode($outp);
}

mysqli_close($con);


?>
