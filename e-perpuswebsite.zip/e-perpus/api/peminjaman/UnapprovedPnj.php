<?php
include '../connect.php';
$id_pinjam = $_POST["id_pinjam"];

if ($con) {
    $sql = "UPDATE tbl_pinjam SET kd_pinjam='', status_pinjam='1' WHERE id_pinjam='$id_pinjam' ";
    if (mysqli_query($con, $sql)) {
        $response = array(
            'status' => 1,
            'message' => 'Unapprove, Terima kasih atas konfirmasi anda',
            'result_code' => true
        );
        echo json_encode($response);
        die();

    } else {
        $response = array(
            'status' => 0,
            'message' => 'Terjadi Kesalahan',
            'result_code' => false
        );
        echo json_encode($response);
        die();
    }



}