<?php
include '../connect.php';
$tanggal_pinjam = $_POST["tanggal_pinjam"];
$tanggal_booking = $_POST["tanggal_pinjam"];
$durasi = $_POST["durasi"];
$id_buku = $_POST["id_buku"];
$id_anggota = $_POST["id_anggota"];
$tokenInp = date("Y-m-d H:i:s");
$deadline_kembali = date('Y-m-d', strtotime($tanggal_pinjam . ' + ' . $durasi . ' days'));


    // CEK TANGGAL INPUT
if($tanggal_pinjam < date('Y-m-d') ){
 $response = array(
    'status' => 0,
    'message' => 'Tanggal yang anda pilih sudah berlalu, silahkan input kembali',
    'result_code' => false
);
 echo json_encode($response);
 die();
}


$cekMax = mysqli_query($con, "SELECT max_hari FROM tbl_maxpinjam");
$cek = mysqli_fetch_assoc($cekMax); // Mengambil hasil query
$maxPinjam = $cek['max_hari'];

$tujuh_hari        = mktime(0,0,0,date("n"),date("j")+$maxPinjam,date("Y"));
$kembali        = date("Y-m-d", $tujuh_hari);

//cek durasi
// if($durasi > $maxPinjam) {
//     $response = array(
//         'status' => 0,
//         'message' => 'Maksimal durasi adalah '.$maxPinjam.' Hari. silakan input ulang',
//         'result_code' => false
//     );
//     echo json_encode($response);
//     die();
// }

//cek maksimal peminjaman
$cekmaxinput = mysqli_query($con, "SELECT *
                        FROM tbl_detail 
                        INNER JOIN tbl_pinjam ON tbl_detail.id_pinjam = tbl_pinjam.id_pinjam
                        WHERE tbl_pinjam.id_anggota='$id_anggota' AND (status_pinjam != '3' AND status_pinjam != '4' AND status_pinjam != '6')");
$cek3 = mysqli_fetch_assoc($cekmaxinput); // Mengambil hasil query
if($cek3 > $maxPinjam) {
    $response = array(
        'status' => 0,
        'message' => 'Mksimal peminjaman adalah '.$maxPinjam.' Hari. silakan input ulang',
        'result_code' => false
    );
    echo json_encode($response);
    die();
}


if ($tanggal_pinjam > $kembali) {
    $response = array(
        'status' => 0,
        'message' => 'Input tanggal peminjaman maksimal '.$maxPinjam.' Hari dari hari ini. silakan input ulang',
        'result_code' => false
    );
    echo json_encode($response);
    die();
}

// Cek apakah data dengan parameter yang sama sudah ada
$checkDuplicate = mysqli_query($con, "SELECT *
                        FROM tbl_detail 
                        INNER JOIN tbl_pinjam ON tbl_detail.id_pinjam = tbl_pinjam.id_pinjam
                        WHERE id_buku='$id_buku' AND tbl_pinjam.id_anggota='$id_anggota' AND (status_pinjam != '3' AND status_pinjam != '4' AND status_pinjam != '6')");
if (mysqli_num_rows($checkDuplicate) > 0) {
    $response = array(
        'status' => 0,
        'message' => 'Data Anda sudah ada di database, cek kembali aktivitas Anda',
        'result_code' => false
    );
    echo json_encode($response);
    die();
}


if ($con) {
    $sql = "INSERT INTO tbl_pinjam(kd_pinjam, tanggal_booking, tanggal_pinjam, durasi, deadline_kembali, tokenInp, status_pinjam, notifikasi_email, id_admin, id_anggota)
    VALUES ('','$tanggal_booking','$tanggal_pinjam','$maxPinjam','$deadline_kembali','$tokenInp','1','0', '0', '$id_anggota')";
    if (mysqli_query($con, $sql)) {

            $ambiltoken = mysqli_query($con, "SELECT id_pinjam FROM tbl_pinjam WHERE tokenInp='$tokenInp'");
              if ($ambiltoken) { // Periksa apakah query berhasil dijalankan
                    if (mysqli_num_rows($ambiltoken) > 0) { // Periksa apakah ada hasil yang ditemukan
                        $row = mysqli_fetch_assoc($ambiltoken); // Mengambil hasil query
                        $id_pinjam = $row['id_pinjam']; // Mengambil nilai kolom 'id_pinjam'

                        //cek apakah stok tersedia atau tidak
                        $stok = mysqli_query($con, "SELECT stok FROM tbl_buku WHERE id_buku='$id_buku'");
                        if(mysqli_num_rows($stok) > 0){
                            $rowStok = mysqli_fetch_assoc($stok);
                            $stok = $rowStok['stok'];

                            if ($stok >= 1) {
                                $stok -= 1;
                                $update = mysqli_query($con, "UPDATE tbl_buku SET stok='$stok' WHERE id_buku='$id_buku'");
                                //input ke tabel detail
                                $sqldetail = "INSERT INTO tbl_detail(id_pinjam, id_buku) VALUES ('$id_pinjam','$id_buku')"; 
                                if (mysqli_query($con, $sqldetail)) {
                                       $response = array(
                                        'status' => 1,
                                        'message' => 'Input Data Berhasil, silahkan refresh halaman menu aktivitas anda',
                                        'result_code' => true
                                    );
                                    echo json_encode($response);
                                    die();
                                }
                            }else{

                                $hapusPnj = mysqli_query($con, "DELETE FROM tbl_pinjam WHERE id_pinjam='$id_pinjam'");
                                $response = array(
                                'status' => 0,
                                'message' => 'Stok Buku habis',
                                'result_code' => false
                                );
                                echo json_encode($response);
                                die();   
                            }
                        }

                    } else {
                       $response = array(
                        'status' => 0,
                        'message' => 'Terjadi Kesalahan Input pada sistem',
                        'result_code' => false
                        );
                       echo json_encode($response);
                       die();   
                   }
               }

           } else {
            $response = array(
                'status' => 0,
                'message' => 'Gagal Proses Input Data',
                'result_code' => false
            );
            echo json_encode($response);
            die();
        }

    } else {
        $response = array(
            'status' => 0,
            'message' => 'Gagal Terhubung',
            'result_code' => false
        );
        echo json_encode($response);
        die();
    }



 