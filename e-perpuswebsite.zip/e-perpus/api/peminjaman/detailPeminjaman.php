<?php
require '../connect.php';

// Tangkap id
$id_pinjam = $_POST["id_pinjam"];

$cekStatus = mysqli_query($con, "SELECT status_pinjam FROM tbl_pinjam WHERE id_pinjam='$id_pinjam'");
$cek = mysqli_fetch_assoc($cekStatus); // Mengambil hasil query
$status_pinjam = $cek['status_pinjam'];
if ($status_pinjam == "1" || $status_pinjam == "4" ) {
    //query tbl_pinjam (non petugas)
    $query1="SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, anggota.no_user AS no_anggota, anggota.email AS email_user
    FROM tbl_pinjam
    INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
    WHERE id_pinjam='$id_pinjam'";
    $result = $con->query($query1);
    $outp = $result->fetch_all(MYSQLI_ASSOC);
     // Ubah format tanggal
    foreach ($outp as &$row) {
        // Ubah format tanggal dari Y-m-d menjadi d-m-Y
        $row['tanggal_pinjam'] = date('d-m-Y', strtotime($row['tanggal_pinjam']));
        $row['deadline_kembali'] = date('d-m-Y', strtotime($row['deadline_kembali']));
    }

     $data = [
        'id_pinjam' => $row['id_pinjam'],
        'kd_pinjam' => $row['kd_pinjam'],
        'tanggal_pinjam' => $row['tanggal_pinjam'],
        'durasi' => $row['durasi'],
        'deadline_kembali' => $row['deadline_kembali'],
        'telat' => "0",
        'selisih_hari' => "0",
        'status_pinjam' => $row['status_pinjam'],
        'id_admin' => $row['id_admin'],
        'id_anggota' => $row['id_anggota'],
        'nama_anggota' => $row['nama_anggota'],
        'no_anggota' => $row['no_anggota'],
        'email_user' => $row['email_user'],
        'nama_admin' => "0",
        'tgl_pengembalian' =>"0",
        'id_denda' => "0",
        'total_denda' =>"0",
        'id_pengembalian' => "0",
        'status_telat' =>"0"
    ];

    echo json_encode(array($data));
    die();

}else if($status_pinjam == "2" OR $status_pinjam == "5"){
    //query tbl_pinjam (+petugas)
    $query2="SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, anggota.no_user AS no_anggota, anggota.email AS email_user, admin.nama_user AS nama_admin
    FROM tbl_pinjam
    INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
    LEFT JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
    WHERE id_pinjam='$id_pinjam'";

    $result = $con->query($query2);
    $outp = $result->fetch_all(MYSQLI_ASSOC);
     // Ubah format tanggal
    foreach ($outp as &$row) {
        // Ubah format tanggal dari Y-m-d menjadi d-m-Y
        $row['tanggal_pinjam'] = date('d-m-Y', strtotime($row['tanggal_pinjam']));
        $row['deadline_kembali'] = date('d-m-Y', strtotime($row['deadline_kembali']));
    }


    $today = strtotime(date('Y-m-d'));  // Timestamp hari ini
    $deadline = strtotime($row['deadline_kembali']);  // Timestamp deadline kembali

    $telat = ($today - $deadline) / (60 * 60 * 24);  // Menghitung selisih hari

        //ambil denda
    $ambilDenda = mysqli_query($con, "SELECT nominal FROM tbl_denda WHERE jns_denda='Utama'");
    $ambilDnd = mysqli_fetch_assoc($ambilDenda); // Mengambil hasil query
    $nominalDnd = $ambilDnd['nominal'];

    $TotalDenda= $nominalDnd*$telat;
    function formatRupiah($angka) {
            $rupiah = "Rp " . number_format($angka, 0, ',', '.');
            return $rupiah;
        }
    $TotalDenda2 = formatRupiah($TotalDenda);


    //menghitung selisih hari
    if ($today > $deadline) {
        
         $data = [
            'id_pinjam' => $row['id_pinjam'],
            'kd_pinjam' => $row['kd_pinjam'],
            'tanggal_pinjam' => $row['tanggal_pinjam'],
            'durasi' => $row['durasi'],
            'deadline_kembali' => $row['deadline_kembali'],
            'telat' => $telat,
            'status_pinjam' => $row['status_pinjam'],
            'id_admin' => $row['id_admin'],
            'id_anggota' => $row['id_anggota'],
            'nama_anggota' => $row['nama_anggota'],
            'no_anggota' => $row['no_anggota'],
            'email_user' => $row['email_user'],
            'nama_admin' => $row['nama_admin'],
            'tgl_pengembalian' =>"0",
            'id_denda' => "0",
            'total_denda' =>$TotalDenda2,
            'id_pengembalian' => "0",
            'status_telat' =>"0"
        ];

     echo json_encode(array($data));
    die();
    }else{
         $data = [
            'id_pinjam' => $row['id_pinjam'],
            'kd_pinjam' => $row['kd_pinjam'],
            'tanggal_pinjam' => $row['tanggal_pinjam'],
            'durasi' => $row['durasi'],
            'deadline_kembali' => $row['deadline_kembali'],
            'telat' => "0",
            'status_pinjam' => $row['status_pinjam'],
            'id_admin' => $row['id_admin'],
            'id_anggota' => $row['id_anggota'],
            'nama_anggota' => $row['nama_anggota'],
            'no_anggota' => $row['no_anggota'],
            'email_user' => $row['email_user'],
            'nama_admin' => $row['nama_admin'],
            'tgl_pengembalian' =>"0",
            'id_denda' => "0",
            'total_denda' =>"0",
            'id_pengembalian' => "0",
            'status_telat' =>"0"
        ];

     echo json_encode(array($data));
    die();

    }

   
}else if($status_pinjam == "3"){
    //query tbl_pengembalian
    $query3="SELECT tbl_pinjam.*, anggota.nama_user AS nama_anggota, anggota.no_user AS no_anggota, anggota.email AS email_user, admin.nama_user AS nama_admin, tbl_kembali.tanggal_kembali AS tgl_pengembalian, tbl_kembali.id_denda, tbl_kembali.total_denda,tbl_kembali.id_pengembalian
    FROM tbl_kembali
    INNER JOIN tbl_pinjam ON tbl_kembali.id_pinjam = tbl_pinjam.id_pinjam
    LEFT JOIN tbl_denda ON tbl_kembali.id_denda = tbl_denda.id_denda
    INNER JOIN tbl_user AS anggota ON tbl_pinjam.id_anggota = anggota.id_user
    LEFT JOIN tbl_user AS admin ON tbl_pinjam.id_admin = admin.id_user
    WHERE tbl_kembali.id_pinjam='$id_pinjam'";

    $result = $con->query($query3);
    $outp = $result->fetch_all(MYSQLI_ASSOC);

    $status_telat = "tidak terlambat"; // Defaultnya tidak terlambat
     // Ubah format tanggal
    foreach ($outp as &$row) {
        // Ubah format tanggal dari Y-m-d menjadi d-m-Y
        $row['tanggal_pinjam'] = date('d-m-Y', strtotime($row['tanggal_pinjam']));
        $row['deadline_kembali'] = date('d-m-Y', strtotime($row['deadline_kembali']));
        $row['tgl_pengembalian'] = date('d-m-Y', strtotime($row['tgl_pengembalian']));
    }

    $kembali = strtotime($row['tgl_pengembalian']); 
    $deadline = strtotime($row['deadline_kembali']);  // Timestamp deadline kembali

    $telat = ($kembali - $deadline) / (60 * 60 * 24);  // Menghitung selisih hari
     // Menghitung selisih hari, pastikan menangani tanggal yang mungkin null
        if (!empty($row['tgl_pengembalian'])) {
            $tgl_pengembalian = strtotime($row['tgl_pengembalian']);
            $telat = ($tgl_pengembalian - $deadline) / (60 * 60 * 24);  // Menghitung selisih hari

            // Periksa apakah terlambat
            if ($tgl_pengembalian > $deadline) {
                $status_telat = "terlambat";
            }
        }
    function formatRupiah($angka) {
        $rupiah = "Rp " . number_format($angka, 0, ',', '.');
        return $rupiah;
    }

    // Mengkonversi total denda ke dalam format Rupiah
    $total_denda_rupiah = formatRupiah($row['total_denda']);

    if ($row['tgl_pengembalian'] > $row['deadline_kembali']) {
        $status_telat="terlambat";
    }


    if ($kembali > $deadline) {
         $data = [
            'id_pinjam' => $row['id_pinjam'],
            'kd_pinjam' => $row['kd_pinjam'],
            'tanggal_pinjam' => $row['tanggal_pinjam'],
            'durasi' => $row['durasi'],
            'deadline_kembali' => $row['deadline_kembali'],
            'telat' => $telat,
            'status_pinjam' => $row['status_pinjam'],
            'id_admin' => $row['id_admin'],
            'id_anggota' => $row['id_anggota'],
            'nama_anggota' => $row['nama_anggota'],
            'no_anggota' => $row['no_anggota'],
            'email_user' => $row['email_user'],
            'nama_admin' => $row['nama_admin'],
            'tgl_pengembalian' =>$row['tgl_pengembalian'],
            'id_denda' =>$row['id_denda'],
            'total_denda' =>$total_denda_rupiah,
            'id_pengembalian' =>$row['id_pengembalian'],
            'status_telat' =>$status_telat
        ];

     echo json_encode(array($data));
    die();
    
    }else{
     $data = [
            'id_pinjam' => $row['id_pinjam'],
            'kd_pinjam' => $row['kd_pinjam'],
            'tanggal_pinjam' => $row['tanggal_pinjam'],
            'durasi' => $row['durasi'],
            'deadline_kembali' => $row['deadline_kembali'],
            'telat' => "0",
            'status_pinjam' => $row['status_pinjam'],
            'id_admin' => $row['id_admin'],
            'id_anggota' => $row['id_anggota'],
            'nama_anggota' => $row['nama_anggota'],
            'no_anggota' => $row['no_anggota'],
            'email_user' => $row['email_user'],
            'nama_admin' => $row['nama_admin'],
            'tgl_pengembalian' =>$row['tgl_pengembalian'],
            'id_denda' =>$row['id_denda'],
            'total_denda' =>$total_denda_rupiah,
            'id_pengembalian' =>$row['id_pengembalian'],
            'status_telat' =>$status_telat
        ];

         echo json_encode(array($data));
        die();
    }

   

}


mysqli_close($con);


?>
