<?php
include '../connect.php';
$id_pinjam = $_POST["id_pinjam"];
$tanggal_pinjam = $_POST["tanggal_pinjam"];
$durasi = $_POST["durasi"];
$deadline_kembali = date('Y-m-d', strtotime($tanggal_pinjam . ' + ' . $durasi . ' days'));


    // CEK TANGGAL INPUT
if($tanggal_pinjam < date('Y-m-d') ){
   $response = array(
    'status' => 0,
    'message' => 'Tanggal yang anda pilih sudah berlalu, silahkan input kembali',
    'result_code' => false
);
   echo json_encode($response);
   die();
}

$tujuh_hari        = mktime(0,0,0,date("n"),date("j")+7,date("Y"));
$kembali        = date("Y-m-d", $tujuh_hari);
if ($tanggal_pinjam > $kembali) {
    $response = array(
        'status' => 0,
        'message' => 'Input tanggal peminjaman maksimal 7 Hari dari hari ini. silakan input ulang',
        'result_code' => false
    );
    echo json_encode($response);
    die();
}




if ($con) {
    $sql = "UPDATE tbl_pinjam SET tanggal_pinjam='$tanggal_pinjam', durasi='$durasi', deadline_kembali='$deadline_kembali' WHERE id_pinjam='$id_pinjam' ";
    if (mysqli_query($con, $sql)) {
        $response = array(
            'status' => 1,
            'message' => 'Edit Berhasil Silahakan refresh halaman aktivitas anda',
            'result_code' => true
        );
        echo json_encode($response);
        die();

    } else {
        $response = array(
            'status' => 0,
            'message' => 'Terjadi Kesalahan',
            'result_code' => false
        );
        echo json_encode($response);
        die();
    }



}