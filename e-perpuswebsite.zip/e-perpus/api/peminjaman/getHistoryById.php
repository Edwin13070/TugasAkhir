<?php
require '../connect.php';

// Tangkap id
$id_anggota = $_POST["id_anggota"];

if ($con) {
   $sql = "SELECT tbl_pinjam.id_pinjam, tbl_pinjam.kd_pinjam, tbl_pinjam.tanggal_pinjam, tbl_pinjam.status_pinjam, tbl_buku.judul, tbl_pinjam.id_anggota
           FROM tbl_detail 
           INNER JOIN tbl_pinjam ON tbl_detail.id_pinjam=tbl_pinjam.id_pinjam
           INNER JOIN tbl_buku ON tbl_detail.id_buku=tbl_buku.id_buku
           WHERE tbl_pinjam.id_anggota='$id_anggota' AND tbl_pinjam.status_pinjam='3' ORDER BY tbl_pinjam.id_pinjam DESC";
    $result = $con->query($sql);
    $outp = $result->fetch_all(MYSQLI_ASSOC);

    // Ubah format tanggal
    foreach ($outp as &$row) {
        // Ubah format tanggal dari Y-m-d menjadi d-m-Y
        $row['tanggal_pinjam'] = date('d-m-Y', strtotime($row['tanggal_pinjam']));
    }

    echo json_encode($outp);
}

mysqli_close($con);


?>
