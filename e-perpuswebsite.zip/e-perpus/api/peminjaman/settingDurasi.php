<?php
require '../connect.php';
if ($con) {
    $sql = "SELECT max_hari FROM tbl_maxpinjam";
    $result = $con->query($sql);
    $outp = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($outp);
}
mysqli_close($con);
