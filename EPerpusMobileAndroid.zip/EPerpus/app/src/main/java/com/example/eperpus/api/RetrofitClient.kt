package com.example.eperpus.api

import com.example.eperpus.api.repo.base_url
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.google.gson.GsonBuilder


class RetrofitClient {

    private fun getRetrofitClient(): Retrofit {
        val gson = GsonBuilder()
            .setLenient()
            .create()

        return Retrofit.Builder()
            .baseUrl(base_url+"/api/")
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build()

        val dirAccountProfile = base_url+"upload/"
    }

    fun getInstances() : Api {
        return getRetrofitClient().create(Api::class.java)
    }
}