package com.example.eperpus.model.data_class

class Buku (
    val id_buku : String?,
    val kd_buku : String?,
    val judul : String?,
    val no_buku : String?,
    val pengarang : String?,
    val penerbit : String?,
    val thn_terbit : String?,
    val stok : String?,
    val sampul : String?,
    val keterangan_buku : String?,
    val id_ktg : String?,
    val nama_ktg : String?
)