package com.example.eperpus.ui.kelolaAkun

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.*
import androidx.core.content.ContentProviderCompat.requireContext
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.api.repo
import com.example.eperpus.model.data_class.Register
import com.example.eperpus.model.login.DataLogin
import com.example.eperpus.model.storage.SharedPrefManager
import com.example.eperpus.support.RealPathUtils
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_edit_profil.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class EditProfilActivity : AppCompatActivity() {

    private lateinit var profilUserArrayList : ArrayList<DataLogin>
    lateinit var s: SharedPrefManager
    private lateinit var foto : File
    private var password : String =""
    private var jenkel : String =""
    private lateinit var builder : AlertDialog.Builder

    private lateinit var tvDate : TextView
    private  lateinit var datePickerButton : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profil)
        loadContainer2.visibility = View.VISIBLE
        //Tampil data edit


        //FUNCTION TAMPIL TANGGAL
        tvDate = findViewById(R.id.tv_date2)
        datePickerButton = findViewById(R.id.datePickerButton2)

        val myCalendar = Calendar.getInstance()

        val datePicker = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            myCalendar.set(Calendar.YEAR, year)
            myCalendar.set(Calendar.MONTH, month)
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateAble(myCalendar)
        }

        datePickerButton.setOnClickListener{
            DatePickerDialog(this, datePicker, myCalendar.get(Calendar.YEAR), myCalendar.get(
                Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }


        tampilEdit()

        val btn_edit = findViewById<TextView>(R.id.btn_editProfil)
        val Edt_id_user = findViewById<TextView>(R.id.etEditId)
        val Edt_nama_user = findViewById<TextView>(R.id.etEditNama)
        val Edt_alamat_user = findViewById<TextView>(R.id.etEditAlamat)
        val Edt_tempat_lahir = findViewById<TextView>(R.id.etEditTmLahir)
        val Edt_tanggal_lahir = findViewById<TextView>(R.id.tv_date2)
        val Edt_no_telp_user = findViewById<TextView>(R.id.etEditNotelp)
        val Edt_email_user = findViewById<TextView>(R.id.etEditEmail)
        val Edt_jenkel_user = findViewById<RadioGroup>(R.id.jenkel_Grup)
        val Edt_jenkel_lk = findViewById<RadioButton>(R.id.jenkel_laki)
        val Edt_jenkel_pr = findViewById<RadioButton>(R.id.jenkel_prp)
        val Edt_username_user = findViewById<TextView>(R.id.etEditUsername)
        val Edt_password_user = findViewById<TextView>(R.id.etEditPassword)
        val Edt_hak_akses = findViewById<TextView>(R.id.etEditHakAkses)
        val Edt_passwordLama_user = findViewById<TextView>(R.id.etEditPasswordlama)
        val Edt_ImgFoto : ImageView = findViewById(R.id.imgLoad)



        //Proses Button Edit
        btn_edit.setOnClickListener{
            loading.visibility = View.VISIBLE
            val id_user = Edt_id_user.text.toString().trim()
            val nama_user = Edt_nama_user.text.toString().trim()
            val alamat_user = Edt_alamat_user.text.toString().trim()
            val tempat = Edt_tempat_lahir.text.toString().trim()
            val tanggal = Edt_tanggal_lahir.text.toString().trim()
            val no_telp = Edt_no_telp_user.text.toString().trim()
            val email_cus = Edt_email_user.text.toString().trim()
            val jenkel_lk = Edt_jenkel_lk.text.toString().trim()
            val jenkel_prm = Edt_jenkel_pr.text.toString().trim()
            val username = Edt_username_user.text.toString().trim()
            val password_user = Edt_password_user.text.toString().trim()
            val passwordLama_user = Edt_passwordLama_user.text.toString().trim()
            val hak_akses = Edt_hak_akses.text.toString().trim()
            val fotoUser = Edt_ImgFoto.toString()


            //Cek Value jenkel
            if(Edt_jenkel_lk.isChecked == true){
                jenkel = "Laki-laki"
            }else if (Edt_jenkel_pr.isChecked == true){
                jenkel = "Perempuan"
            }else{
                jenkel = "Laki-laki"
            }

            //cek value password
            if(password_user.isEmpty()){
                password = passwordLama_user
            }else {
                password = password_user
            }

            try{

                val file = RequestBody.create("multipart/form-data".toMediaTypeOrNull(), foto)
                val body = MultipartBody.Part.createFormData("foto", this.foto.name, file)

                val api = RetrofitClient().getInstances()
                api.editUser(
                    toRequestBody(id_user), toRequestBody(nama_user),
                    toRequestBody(jenkel), toRequestBody(tempat),
                    toRequestBody(tanggal), toRequestBody(alamat_user),
                    toRequestBody(no_telp),toRequestBody(email_cus),
                    toRequestBody(username),toRequestBody(password), body)
                    .enqueue(object :retrofit2.Callback<Register>{

                        override fun onResponse(call: Call<Register>, response: Response<Register>) {
                            if (response.isSuccessful()) {
                                loading.visibility = View.GONE
                                if (response.body() != null && response.body()?.result_code == true) {
                                    val msg : String? =response.body()?.message
                                    showCustomDialogBox(msg)
                                } else {
                                    loading.visibility = View.GONE
                                    Toast.makeText(
                                        this@EditProfilActivity,
                                        response.body()?.message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }else{
                                loading.visibility = View.GONE
                                Toast.makeText(
                                    this@EditProfilActivity,
                                    "Terjadi Kesalahan",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }

                        override fun onFailure(call: Call<Register>, t: Throwable) {
                            loading.visibility = View.GONE
                            Log.e("pesan error","${t.message}")
                        }

                    })
            }catch (e:Exception){
                loading.visibility = View.GONE
                Toast.makeText(this, "Upload foto!!", Toast.LENGTH_SHORT).show()
            }

        }


    }

    fun upload(v : View){
        var intents = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intents.setType("image/*")
        startActivityForResult(Intent.createChooser(intents, "Pilih Foto"), 121)
    }


    fun toRequestBody(txt:String) : RequestBody {
        return RequestBody.create("multipart/form-data".toMediaTypeOrNull(), txt)
    }

    private fun tampilEdit(){

        val id_userLogIn = SharedPrefManager.getInstance(this).user.id.toString()
        val hak_aksesUser = SharedPrefManager.getInstance(this).user.hak_akses.toString()
        val api = RetrofitClient().getInstances()
        api.getIdUser(id_userLogIn, hak_aksesUser).enqueue(object  :
            Callback<List<DataLogin>> {
            override fun onResponse(call: Call<List<DataLogin>>, response: Response<List<DataLogin>>) {
                if (response.body() != null && response.isSuccessful()){
                    profilUserArrayList  = ArrayList()
                    for (i in response.body()!!.indices){
                        val prl = DataLogin(
                            response.body()!![i]!!.id,
                            response.body()!![i]!!.nis,
                            response.body()!![i]!!.nama,
                            response.body()!![i]!!.jenkel,
                            response.body()!![i]!!.tempat_lahir,
                            response.body()!![i]!!.tgl_lahir,
                            response.body()!![i]!!.alamat,
                            response.body()!![i]!!.no_telp,
                            response.body()!![i]!!.username,
                            response.body()!![i]!!.password,
                            response.body()!![i]!!.email,
                            response.body()!![i]!!.hak_akses,
                            response.body()!![i]!!.foto

                        )
                        val id_customer = findViewById<TextView>(R.id.etEditId)
                        val nama_customer = findViewById<TextView>(R.id.etEditNama)
                        val alamat_customer = findViewById<TextView>(R.id.etEditAlamat)
                        val tmptLahir = findViewById<TextView>(R.id.etEditTmLahir)
                        val tglLahir = findViewById<TextView>(R.id.tv_date2)
                        val no_telp_customer = findViewById<TextView>(R.id.etEditNotelp)
                        val email_customer = findViewById<TextView>(R.id.etEditEmail)
                        val jenkel_customer = findViewById<RadioGroup>(R.id.jenkel_Grup)
                        val jenkel_lk = findViewById<RadioButton>(R.id.jenkel_laki)
                        val jenkel_pr = findViewById<RadioButton>(R.id.jenkel_prp)
                        val username_customer = findViewById<TextView>(R.id.etEditUsername)
                        val password_customer = findViewById<TextView>(R.id.etEditPassword)
                        val hak_akses = findViewById<TextView>(R.id.etEditHakAkses)
                        val passwordLama_customer = findViewById<TextView>(R.id.etEditPasswordlama)
                        val ImgFoto : ImageView = findViewById(R.id.imgLoad)


                        //hasil query retrofit
                        val id_usr = response.body()!![i].id
                        val nm_usr = response.body()!![i].nama
                        val almt_usr = response.body()!![i].alamat
                        val tmLhr = response.body()!![i].tempat_lahir
                        val tgLhr = response.body()!![i].tgl_lahir
                        val notelp_usr = response.body()!![i].no_telp
                        val email_usr = response.body()!![i].email
                        val jenkel_cus = response.body()!![i].jenkel
                        val usrnm_usr = response.body()!![i].username
                        val pswd_usr = response.body()!![i].password
                        val foto_user = response.body()!![i].foto


                        val urlFoto = repo.base_url +"/$foto_user"

                        id_customer.text = id_usr
                        nama_customer.text = nm_usr
                        alamat_customer.text = almt_usr
                        tmptLahir.text=tmLhr
                        tglLahir.text = tgLhr
                        no_telp_customer.text = notelp_usr

                        if (response.body()!![i]!!.jenkel == "Laki-laki"){
                            jenkel_lk.setChecked(true)
                        }else if (response.body()!![i]!!.jenkel == "Perempuan"){
                            jenkel_pr.setChecked(true)
                        }

                        txt_Hdemail.visibility = View.VISIBLE
                        etEditEmail.visibility = View.VISIBLE
                        email_customer.text = email_usr

                        username_customer.text = usrnm_usr
                        passwordLama_customer.text = pswd_usr
                        Picasso.get().load(urlFoto).into(ImgFoto)
                        loadContainer2.visibility = View.GONE
                    }


                }else {
                    Toast.makeText(this@EditProfilActivity,"Tidak Ada Data Profil!",
                        Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<List<DataLogin>>, t: Throwable) {
                Toast.makeText(this@EditProfilActivity,t.message, Toast.LENGTH_LONG).show()
            }
        })

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode) {
            121 -> {
                if(resultCode == Activity.RESULT_OK){
                    val dt = data?.data as Uri
                    findViewById<ImageView>(R.id.imgLoad).setImageURI(dt)

//                  this.fileFoto = Utilitas().getBitmapFile(dt, getApplicationContext())
                    this.foto =  File(RealPathUtils().getRealPath(this@EditProfilActivity, dt))
//                    this.fileFoto.getAbsolutePath()?.let { Log.e("File", it) }
                    RealPathUtils().getRealPath(this@EditProfilActivity, dt)

                }
            }
            157 -> {
                if(resultCode == Activity.RESULT_OK){
                    setResult(RESULT_OK)
                } else {
                    setResult(RESULT_CANCELED)
                }
                finish()
            }
        }
    }

    //ambil value tanggal
    private fun updateAble(myCalendar: Calendar) {
        val myFormat = "yyyy-MM-dd"
        val sdf = SimpleDateFormat(myFormat, Locale.UK)
        tvDate.setText(sdf.format(myCalendar.time))

    }

    fun btn_backListener(v:View){
        finish()
    }

    private fun showCustomDialogBox(msg: String?) {
        loadingEdt.visibility = View.GONE
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.layout_alert2)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog.findViewById(R.id.btnYes)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            dialog.dismiss()
            finish()
        }
        dialog.show()
    }

}