package com.example.eperpus.ui.fragment

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.eperpus.*
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.api.repo
import com.example.eperpus.model.login.DataLogin
import com.example.eperpus.model.storage.SharedPrefManager
import com.example.eperpus.ui.kelolaAkun.EditProfilActivity
//import com.example.eperpus.ui.kelolaAkun.EditProfilActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_profile.*


class ProfileFragment : Fragment() {

    private lateinit var profilCusArrayList : ArrayList<DataLogin>
    private lateinit var swipeRefresh : SwipeRefreshLayout
    lateinit var btnLogout: Button
    lateinit var btn_layEdit: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view: View = inflater.inflate(R.layout.fragment_profile, container, false)
        val id_userLogIn = SharedPrefManager.getInstance(requireActivity()).user.id.toString()
        val hak_aksesUser = SharedPrefManager.getInstance(requireActivity()).user.hak_akses.toString()



        val api = RetrofitClient().getInstances()
        api.getIdUser(id_userLogIn,hak_aksesUser).enqueue(object  : Callback<List<DataLogin>> {
            override fun onResponse(call: Call<List<DataLogin>>, response: Response<List<DataLogin>>) {
                if (response.body() != null && response.isSuccessful()){
                    profilCusArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val prl = DataLogin(
                            response.body()!![i]!!.id,
                            response.body()!![i]!!.nis,
                            response.body()!![i]!!.nama,
                            response.body()!![i]!!.jenkel,
                            response.body()!![i]!!.tempat_lahir,
                            response.body()!![i]!!.tgl_lahir,
                            response.body()!![i]!!.alamat,
                            response.body()!![i]!!.no_telp,
                            response.body()!![i]!!.username,
                            response.body()!![i]!!.password,
                            response.body()!![i]!!.email,
                            response.body()!![i]!!.hak_akses,
                            response.body()!![i]!!.foto

                        )

                        //panggil Id element xml
//                        val tvIdUser : TextView = view.findViewById(R.id.txt_iduser)
                        val tvMember : TextView = view.findViewById(R.id.txt_idUser)
                        val tvNama : TextView = view.findViewById(R.id.txt_Enama)
                        val tvTelp : TextView = view.findViewById(R.id.txt_Etelp)
                        val tvMail : TextView = view.findViewById(R.id.txt_Email)
                        val tvNamaProf : TextView = view.findViewById(R.id.txt_NamaProfil)
                        val tvAlamat : TextView = view.findViewById(R.id.txt_Ealamat)
                        val tvjenkel : TextView = view.findViewById(R.id.txt_jenkel)
                        val ImgFoto : ImageView = view.findViewById(R.id.gambar_profil)


                        //hasil query retrofit
                        val id_user = response.body()!![i].id
                        val nama_Prof = response.body()!![i].nama
                        val nama_user = response.body()!![i].nama
                        val alamat_user = response.body()!![i].alamat
                        val no_telp = response.body()!![i].no_telp
                        val email_usr = response.body()!![i].email
                        val jenkel_usr = response.body()!![i].jenkel
                        val foto_user = response.body()!![i].foto

                        //Menampilkan foto profil
                        val urlFoto = repo.base_url +"/$foto_user"
                        Picasso.get().load(urlFoto).into(ImgFoto)

//                        tvIdUser.text = id_user
                        tvMember.text = id_user
                        tvNamaProf.text = nama_Prof
                        tvNama.text = nama_user
                        tvAlamat.text = alamat_user
                        tvTelp.text = no_telp
                        tvMail.text = email_usr
                        tvjenkel.text = jenkel_usr
                    }

                }else {
                    Toast.makeText(requireActivity().applicationContext,"Tidak Ada Data profil!",
                        Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<List<DataLogin>>, t: Throwable) {
                Toast.makeText(requireActivity().applicationContext,t.message, Toast.LENGTH_LONG).show()
            }
        })


        btn_layEdit = view.findViewById(R.id.btn_Lpedit)
        btn_layEdit.setOnClickListener(){
            val hasilId = id_userLogIn.toString()
            val i = Intent(activity, EditProfilActivity::class.java)
            i.putExtra("id_user",hasilId)
            startActivity(i)

        }

        btnLogout = view.findViewById(R.id.btn_logout)
        btnLogout.setOnClickListener(){
            val msg : String? ="Anda yakin akan keluar?"
            showCustomDialogBox(msg)
        }

        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnRefreshListener{

            Toast.makeText(requireActivity().applicationContext,"Memperbarui Data", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                swipeRefresh.isRefreshing = false
                //Api Untuk menampilkan data profil
                val args = this.arguments
                val hakUser = args?.get("id")
                val tvHakakses : TextView = view.findViewById(R.id.txt_hakakses)
                tvHakakses.text = hakUser.toString()

                val api = RetrofitClient().getInstances()
                api.getIdUser(id_userLogIn,hak_aksesUser).enqueue(object  : Callback<List<DataLogin>> {
                    override fun onResponse(call: Call<List<DataLogin>>, response: Response<List<DataLogin>>) {
                        if (response.body() != null && response.isSuccessful()){
                            profilCusArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val prl = DataLogin(
                                    response.body()!![i]!!.id,
                                    response.body()!![i]!!.nis,
                                    response.body()!![i]!!.nama,
                                    response.body()!![i]!!.jenkel,
                                    response.body()!![i]!!.tempat_lahir,
                                    response.body()!![i]!!.tgl_lahir,
                                    response.body()!![i]!!.alamat,
                                    response.body()!![i]!!.no_telp,
                                    response.body()!![i]!!.username,
                                    response.body()!![i]!!.password,
                                    response.body()!![i]!!.email,
                                    response.body()!![i]!!.hak_akses,
                                    response.body()!![i]!!.foto

                                )

                                //panggil Id element xml
//                        val tvIdUser : TextView = view.findViewById(R.id.txt_iduser)
                                val tvMember : TextView = view.findViewById(R.id.txt_idUser)
                                val tvNama : TextView = view.findViewById(R.id.txt_Enama)
                                val tvTelp : TextView = view.findViewById(R.id.txt_Etelp)
                                val tvMail : TextView = view.findViewById(R.id.txt_Email)
                                val tvNamaProf : TextView = view.findViewById(R.id.txt_NamaProfil)
                                val tvAlamat : TextView = view.findViewById(R.id.txt_Ealamat)
                                val tvjenkel : TextView = view.findViewById(R.id.txt_jenkel)
                                val ImgFoto : ImageView = view.findViewById(R.id.gambar_profil)


                                //hasil query retrofit
                                val id_user = response.body()!![i].id
                                val nama_Prof = response.body()!![i].nama
                                val nama_user = response.body()!![i].nama
                                val alamat_user = response.body()!![i].alamat
                                val no_telp = response.body()!![i].no_telp
                                val email_usr = response.body()!![i].email
                                val jenkel_usr = response.body()!![i].jenkel
                                val foto_user = response.body()!![i].foto

                                //Menampilkan foto profil
                                val urlFoto = repo.base_url +"/$foto_user"
                                Picasso.get().load(urlFoto).into(ImgFoto)

//                        tvIdUser.text = id_user
                                tvMember.text = id_user
                                tvNamaProf.text = nama_Prof
                                tvNama.text = nama_user
                                tvAlamat.text = alamat_user
                                tvTelp.text = no_telp
                                tvMail.text = email_usr
                                tvjenkel.text = jenkel_usr
                            }

                        }else {
                            Toast.makeText(requireActivity().applicationContext,"Tidak Ada Data profil!",
                                Toast.LENGTH_LONG).show()
                        }
                    }

                    override fun onFailure(call: Call<List<DataLogin>>, t: Throwable) {
                        Toast.makeText(requireActivity().applicationContext,t.message, Toast.LENGTH_LONG).show()
                    }
                })

                Toast.makeText(requireActivity().applicationContext,"Memperbarui Data Selesai", Toast.LENGTH_LONG).show()
            }, 3000L)
        }
        return view

    }

    private fun showCustomDialogBox(msg: String?) {
         val dialog = Dialog(requireContext())
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.layout_alert)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog.findViewById(R.id.btnYes)
        val btnNo : Button = dialog.findViewById(R.id.btnNo)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            SharedPrefManager.getInstance(requireContext()).clear()
            val intent = Intent(activity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
        btnNo.setOnClickListener{
            dialog.dismiss()
        }
        dialog.show()
    }


}

