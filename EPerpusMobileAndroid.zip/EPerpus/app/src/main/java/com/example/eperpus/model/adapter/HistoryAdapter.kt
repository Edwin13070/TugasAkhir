package com.example.eperpus.model.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.eperpus.R
import com.example.eperpus.model.data_class.History

class HistoryAdapter(private val mContext : Activity, private val arrayList:ArrayList<History>): ArrayAdapter<History>(mContext, R.layout.list_history, arrayList) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater: LayoutInflater = LayoutInflater.from(mContext)
        val view: View = inflater.inflate(R.layout.list_history, null)

        val namaBk: TextView = view.findViewById(R.id.tv_tglpnjm)
        val pnbt: TextView = view.findViewById(R.id.jdl)
        val kdBk: TextView = view.findViewById(R.id.tv_kdPinjam)

        namaBk.text = arrayList[position].tanggal_pinjam
        pnbt.text = arrayList[position].judul
        kdBk.text = arrayList[position].kd_pinjam
        return view
    }
}