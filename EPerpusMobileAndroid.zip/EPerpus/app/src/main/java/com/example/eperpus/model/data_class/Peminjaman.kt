package com.example.eperpus.model.data_class

data class Peminjaman (
    val status : String,
    val message: String,
    val result_code : Boolean

)