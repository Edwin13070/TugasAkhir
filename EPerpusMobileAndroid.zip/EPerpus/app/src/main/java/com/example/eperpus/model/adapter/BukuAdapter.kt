package com.example.eperpus.model.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.eperpus.R
import com.example.eperpus.api.repo
import com.example.eperpus.model.data_class.Buku
import com.squareup.picasso.Picasso

class BukuAdapter(private val mContext : Activity, private val arrayList:ArrayList<Buku>): ArrayAdapter<Buku>(mContext, R.layout.list_buku2, arrayList)  {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater : LayoutInflater = LayoutInflater.from(mContext)
        val view : View = inflater.inflate(R.layout.list_buku2,null)

        val imageView : ImageView = view.findViewById(R.id.foto_buku)
        val namaBk : TextView = view.findViewById(R.id.txt_namaBuku)
        val pnbt : TextView = view.findViewById(R.id.txt_penerbit)
        val kdBk : TextView = view.findViewById(R.id.txt_kdBuku)
        val stk : TextView = view.findViewById(R.id.txt_Stok)

        val fotoBuku = arrayList[position].sampul
        val urlFoto = repo.base_url +"/$fotoBuku"

        namaBk.text = arrayList[position].judul
        pnbt.text = arrayList[position].penerbit
        kdBk.text = arrayList[position].kd_buku
        stk.text = arrayList[position].stok
        Picasso.get().load(urlFoto).into(imageView)

        return view
    }

}