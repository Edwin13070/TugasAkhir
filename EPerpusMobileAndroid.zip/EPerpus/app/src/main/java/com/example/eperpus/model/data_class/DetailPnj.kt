package com.example.eperpus.model.data_class

class DetailPnj (
    val id_pinjam : String?,
    val kd_pinjam : String?,
    val tanggal_pinjam : String?,
    val durasi : String?,
    val deadline_kembali : String?,
    val telat : String?,
    val status_pinjam : String?,
    val id_admin : String?,
    val id_anggota : String?,
    val nama_anggota : String?,
    val no_anggota : String?,
    val email_user : String?,
    val nama_admin : String?,
    val tgl_pengembalian : String?,
    val id_denda : String?,
    val total_denda : String?,
    val id_pengembalian : String?,
    val status_telat : String?,
)