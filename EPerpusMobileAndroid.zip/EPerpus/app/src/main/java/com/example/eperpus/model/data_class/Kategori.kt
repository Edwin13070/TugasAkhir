package com.example.eperpus.model.data_class

class Kategori (
    val id_ktg : String?,
    val nama_ktg : String?
)