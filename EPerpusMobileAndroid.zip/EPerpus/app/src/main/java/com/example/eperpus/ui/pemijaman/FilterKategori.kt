package com.example.eperpus.ui.pemijaman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.model.adapter.BukuAdapter2
import com.example.eperpus.model.adapter.KategoriAdapter
import com.example.eperpus.model.data_class.Buku
import com.example.eperpus.model.data_class.Kategori
import kotlinx.android.synthetic.main.activity_detail_buku.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FilterKategori : AppCompatActivity() {

    private lateinit var swipeRefresh : SwipeRefreshLayout
    private lateinit var kategoriArrayList : ArrayList<Kategori>
    private lateinit var cari : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter_kategori)

        //kontrol refresh -> refresh akan bekerja jika hanya layout berada di list 1
        swipeRefresh = findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnChildScrollUpCallback(object : SwipeRefreshLayout.OnChildScrollUpCallback {
            override fun canChildScrollUp(parent: SwipeRefreshLayout, child: View?): Boolean {
                if (gridView != null) {
                    return gridView.canScrollVertically(-1)
                }
                return false
            }
        })

        val api = RetrofitClient().getInstances()
        api.viewKategori().enqueue(object  : Callback<List<Kategori>> {
            override fun onResponse(call: Call<List<Kategori>>, response: Response<List<Kategori>>) {
                if (response.body() != null && response.isSuccessful()){
                    kategoriArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Kategori(
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        kategoriArrayList.add(bk)
                    }
                    gridView.adapter = KategoriAdapter(this@FilterKategori,kategoriArrayList)
                    gridView.setOnItemClickListener { parent, view, position, id ->
                        val id_ktg = response.body()!![position]!!.id_ktg
                        val nama_ktg = response.body()!![position]!!.nama_ktg

                        val i = Intent(this@FilterKategori, KategoriBuku::class.java)
                        i.putExtra("id_ktg",id_ktg)
                        i.putExtra("nama_ktg",nama_ktg)
                        startActivity(i)
                    }
                }
            }

            override fun onFailure(call: Call<List<Kategori>>, t: Throwable) {
                Toast.makeText(this@FilterKategori,t.message, Toast.LENGTH_LONG).show()
            }
        })


        swipeRefresh =findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnRefreshListener{

            Toast.makeText(applicationContext,"Memperbarui Data", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                swipeRefresh.isRefreshing = false
                //Api Untuk menampilkan data buku
                val api = RetrofitClient().getInstances()
                api.viewKategori().enqueue(object  : Callback<List<Kategori>> {
                    override fun onResponse(call: Call<List<Kategori>>, response: Response<List<Kategori>>) {
                        if (response.body() != null && response.isSuccessful()){
                            kategoriArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val bk = Kategori(
                                    response.body()!![i]!!.id_ktg,
                                    response.body()!![i]!!.nama_ktg
                                )
                                kategoriArrayList.add(bk)
                            }
                            gridView.adapter = KategoriAdapter(this@FilterKategori,kategoriArrayList)
                            gridView.setOnItemClickListener { parent, view, position, id ->
                                val id_ktg = response.body()!![position]!!.id_ktg
                                val nama_ktg = response.body()!![position]!!.nama_ktg

                                val i = Intent(this@FilterKategori, KategoriBuku::class.java)
                                i.putExtra("id_ktg",id_ktg)
                                i.putExtra("nama_ktg",nama_ktg)
                                startActivity(i)
                            }
                        }
                    }

                    override fun onFailure(call: Call<List<Kategori>>, t: Throwable) {
                        Toast.makeText(this@FilterKategori,t.message, Toast.LENGTH_LONG).show()
                    }
                })
                Toast.makeText(applicationContext,"Memperbarui Data Selesai", Toast.LENGTH_LONG).show()
            }, 3000L)
        }


    }

    fun btn_backListener(v: View){
        finish()
    }
}
