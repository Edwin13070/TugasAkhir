package com.example.eperpus.error

class AppConstant {
    companion object{
        @JvmStatic
        val L0CATION_REQUEST_CODE =200
    }
}