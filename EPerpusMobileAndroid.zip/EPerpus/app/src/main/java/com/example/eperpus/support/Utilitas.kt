package com.example.eperpus.support

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import com.bumptech.glide.Glide
import java.util.concurrent.Executors

class Utilitas {
    fun setImageFromUrl(url : String, imgView : ImageView, context : Context){
//        Executors.newSingleThreadExecutor().execute{
//            try{
//                val getData = java.net.URL(url).openStream()
//                val img = BitmapFactory.decodeStream(getData)
//                Handler(Looper.getMainLooper()).post {
//                    imgView.setImageBitmap(img)
//                }
//            } catch (e : java.lang.Exception){
//                e.printStackTrace()
//            }
//        }
        Glide.with(context)
            .load(url)
            .centerCrop()
            .into(imgView);
    }
    fun setImageFromUrl(url : String, imgView : de.hdodenhof.circleimageview.CircleImageView){
        Executors.newSingleThreadExecutor().execute{
            try{
                val getData = java.net.URL(url).openStream()
                val img = BitmapFactory.decodeStream(getData)
                Handler(Looper.getMainLooper()).post {
                    imgView.setImageBitmap(img)
                }
            } catch (e : java.lang.Exception){
                e.printStackTrace()
            }
        }
    }
    fun getExtraString(bundle: Bundle?, key : String, intent:Intent):String?{
        val newString = if (bundle == null) {
            val extras = intent.extras
            extras?.getString(key)
        } else {
            bundle.getSerializable(key) as String?
        }
        return newString
    }
}