package com.example.eperpus.ui.kelolaAkun

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.eperpus.LoginActivity
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.model.data_class.LupaPassword
import kotlinx.android.synthetic.main.activity_forgot_password.*
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.txt_signIn
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ForgotPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        txt_signInListener()

        val tv_ForgotEmail = findViewById<EditText>(R.id.txt_ForgotEmail)
        val buttonReset = findViewById<Button>(R.id.btn_reset)

        buttonReset.setOnClickListener {
            val email = tv_ForgotEmail.text.toString().trim()
            if(email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                tv_ForgotEmail.error = "Email kosong atau tidak sesuai format"
                tv_ForgotEmail.requestFocus()
                return@setOnClickListener
            }
            else{
                loadingReg.visibility = View.VISIBLE
                val api = RetrofitClient().getInstances()
                api.cekEmailCus(email)
                    .enqueue(object  : Callback<LupaPassword> {
                        override fun onResponse(call: Call<LupaPassword>, response: Response<LupaPassword>) {
                            if (response.isSuccessful()) {
                                if (response.body() != null && response.body()?.result_code == true) {
                                    Toast.makeText(
                                        applicationContext,
                                        response.body()?.message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                    val i = Intent(this@ForgotPassword, ResetPassword::class.java)
                                    i.putExtra("email",email)
                                    startActivity(i)

                                } else {
                                    loadingReg.visibility = View.GONE
                                    Toast.makeText(
                                        applicationContext,
                                        response.body()?.message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                }

                            }else{
                                loadingReg.visibility = View.GONE
                                Toast.makeText(
                                    applicationContext,
                                    "Proses gagal, Terjadi Kesalahan",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }

                        override fun onFailure(call: Call<LupaPassword>, t: Throwable) {
                            Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
                        }

                    })


            }

        }

    }

    fun btn_backListener(v: View){
        finish()
    }

    private fun txt_signInListener(){
        txt_signIn.setOnClickListener{
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }
}