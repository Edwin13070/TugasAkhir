package com.example.eperpus.ui.pemijaman

import android.app.DatePickerDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.*
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.api.repo
import com.example.eperpus.model.adapter.AktivitasAdapter
import com.example.eperpus.model.adapter.DetailBukuAdapter
import com.example.eperpus.model.data_class.AktivitasUser
import com.example.eperpus.model.data_class.Buku
import com.example.eperpus.model.data_class.Peminjaman
import com.example.eperpus.model.login.DataLogin
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_edit_pinjam.*
import kotlinx.android.synthetic.main.activity_edit_profil.*
import kotlinx.android.synthetic.main.activity_tambah_peminjaman.*
import kotlinx.android.synthetic.main.fragment_aktivitas.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class EditPinjam : AppCompatActivity() {

    private lateinit var tvDate : TextView
    private  lateinit var datePickerButton : Button
    private lateinit var dataPinjamArrayList: ArrayList<AktivitasUser>
    private lateinit var bukuArrayList : ArrayList<Buku>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_pinjam)

        //FUNCTION TAMPIL TANGGAL
        tvDate = findViewById(R.id.et_ETtanggalPinjam)
        datePickerButton = findViewById(R.id.datePickerButton2)

        val myCalendar = Calendar.getInstance()

        val datePicker = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            myCalendar.set(Calendar.YEAR, year)
            myCalendar.set(Calendar.MONTH, month)
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateAble(myCalendar)
        }

        datePickerButton.setOnClickListener{
            DatePickerDialog(this, datePicker, myCalendar.get(Calendar.YEAR), myCalendar.get(
                Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }


        tampilEdit()
        tampilBuku()
        eventEditPinjam()

    }

    private fun tampilEdit(){
        val id_pinjam = intent.getStringExtra("id_pinjam").toString()
        val api = RetrofitClient().getInstances()
        api.getIdPinjam(id_pinjam).enqueue(object  : Callback<List<AktivitasUser>> {
            override fun onResponse(call: Call<List<AktivitasUser>>, response: Response<List<AktivitasUser>>) {
                if (response.body() != null && response.isSuccessful()){
                    dataPinjamArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val Cstmr = AktivitasUser(
                            response.body()!![i]!!.id_pinjam,
                            response.body()!![i]!!.kd_pinjam,
                            response.body()!![i]!!.tanggal_pinjam,
                            response.body()!![i]!!.durasi,
                            response.body()!![i]!!.deadline_kembali,
                            response.body()!![i]!!.status_pinjam,
                            response.body()!![i]!!.id_anggota
                        )
                        val durasi = findViewById<TextView>(R.id.et_ETdurasi)
                        val tglpnj = findViewById<TextView>(R.id.et_ETtanggalPinjam)

                        val drs = response.body()!![i].durasi
                        val tgl = response.body()!![i].tanggal_pinjam

                        durasi.text = drs
                        tglpnj.text = tgl
                    }

                }
                if (response.body()!!.isEmpty()) {
                    text_blank.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<List<AktivitasUser>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message, Toast.LENGTH_LONG).show()
            }
        })

    }

    fun tampilBuku(){
        val id_pinjam = intent.getStringExtra("id_pinjam").toString()
        val api = RetrofitClient().getInstances()
        api.getBukuByIdPinjam(id_pinjam).enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        bukuArrayList.add(bk)
                    }
                    listDetail2.adapter = DetailBukuAdapter(this@EditPinjam,bukuArrayList)

                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message,Toast.LENGTH_LONG).show()
            }
        })


    }

    fun eventEditPinjam(){
        val id_pinjam = intent.getStringExtra("id_pinjam").toString()
        btn_ubah.setOnClickListener {
            loadinged.visibility = View.VISIBLE
            val tanggal_pinjam = et_ETtanggalPinjam.text.toString().trim()
            val durasi = et_ETdurasi.text.toString().trim()

            //validasi inputan
            if (tanggal_pinjam.isEmpty()){
                et_ETtanggalPinjam.error="Tanggal pinjam tidak boleh kosong!"
                et_ETtanggalPinjam.requestFocus()
                return@setOnClickListener
            }
            else if (durasi.isEmpty()){
                et_ETdurasi.error="Durasi tidak boleh kosong!"
                et_ETdurasi.requestFocus()
                return@setOnClickListener
            }
            else{
                val api = RetrofitClient().getInstances()
                api.editPnj(id_pinjam,tanggal_pinjam, durasi)
                    .enqueue(object :retrofit2.Callback<Peminjaman>{
                        override fun onResponse(call: Call<Peminjaman>, response: Response<Peminjaman>) {
                            if (response.isSuccessful()) {
                                if (response.body() != null && response.body()?.result_code == true) {
                                    val msg : String? =response.body()?.message
                                    showCustomDialogBox(msg)
                                } else {
                                    Toast.makeText(
                                        this@EditPinjam,
                                        response.body()?.message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                    loadinged.visibility = View.GONE
                                }
                            }else{
                                Toast.makeText(
                                    this@EditPinjam,
                                    "Terjadi Kesalahan",
                                    Toast.LENGTH_LONG
                                ).show()
                                loadinged.visibility = View.GONE
                            }
                        }

                        override fun onFailure(call: Call<Peminjaman>, t: Throwable) {
                            Log.e("pesan error","${t.message}")
                            loadinged.visibility = View.GONE
                        }


                    })
            }
        }
    }
    //ambil value tanggal
    private fun updateAble(myCalendar: Calendar) {
        val myFormat = "yyyy-MM-dd"
        val sdf = SimpleDateFormat(myFormat, Locale.UK)
        tvDate.setText(sdf.format(myCalendar.time))

    }
    private fun showCustomDialogBox(msg: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.layout_alert2)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog.findViewById(R.id.btnYes)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            dialog.dismiss()
        }
        dialog.show()
    }
}