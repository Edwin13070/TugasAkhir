package com.example.eperpus.model.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.example.eperpus.R
import com.example.eperpus.api.repo
import com.example.eperpus.model.data_class.Buku
import com.squareup.picasso.Picasso

class DetailBukuAdapter(private val mContext : Activity, private val arrayList:ArrayList<Buku>): ArrayAdapter<Buku>(mContext, R.layout.list_buku_pinjam, arrayList)  {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater : LayoutInflater = LayoutInflater.from(mContext)
        val view : View = inflater.inflate(R.layout.list_buku_pinjam,null)

        val a_kd_buku : TextView = view.findViewById(R.id.dt_kd_buku)
        val a_judul : TextView = view.findViewById(R.id.dt_judul)
        val a_penerbit : TextView = view.findViewById(R.id.dt_penerbit)

        a_kd_buku.text = arrayList[position].kd_buku
        a_judul.text = arrayList[position].judul
        a_penerbit.text = arrayList[position].penerbit

        return view
    }

}