package com.example.eperpus.api

object repo {
    val base_url ="https://e-perpussmknegeri1trucuk.000webhostapp.com/"
}