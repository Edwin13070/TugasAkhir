package com.example.eperpus.model.login

data class Login (
        val status : String,
        val result_code : Boolean,
        val data : DataLogin
    )