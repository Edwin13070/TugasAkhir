package com.example.eperpus.model.login

data class DataLogin (
    val id : String?,
    val nis : String?,
    val nama : String?,
    val jenkel: String?,
    val tempat_lahir : String?,
    val tgl_lahir : String?,
    val alamat: String?,
    val no_telp : String?,
    val username : String?,
    val password : String?,
    val email : String?,
    val hak_akses : String?,
    val foto : String?
    )