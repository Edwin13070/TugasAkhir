package com.example.eperpus.ui.kelolaAkun

import android.app.Activity
import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.util.Patterns
import android.view.View
import android.view.Window
import android.widget.*
import com.example.eperpus.LoginActivity
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.databinding.ActivityRegisterBinding

import com.example.eperpus.model.data_class.Register
import com.example.eperpus.support.RealPathUtils

import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_register.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Response
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class RegisterActivity : AppCompatActivity() {

    //    Deklarasi variabel REGISTER
    private var binding : ActivityRegisterBinding? =null
    private var no_user : String =""
    private var nama_user : String =""
    var jenkel : String =""
    private var tempat_lahir : String =""
    private var tgl_lahir : String =""
    private var alamat : String =""
    private var notelp : String =""
    private var email : String =""
    private var username : String =""
    private var password : String =""
    private lateinit var foto : File

    private lateinit var tvDate : TextView
    private  lateinit var datePickerButton : Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        txt_signInListener()

        //FUNCTION TAMPIL TANGGAL
        tvDate = binding!!.tvDate2
        datePickerButton = binding!!.datePickerButton2

        val myCalendar = Calendar.getInstance()

        val datePicker = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            myCalendar.set(Calendar.YEAR, year)
            myCalendar.set(Calendar.MONTH, month)
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateAble(myCalendar)
        }

        datePickerButton.setOnClickListener{
            DatePickerDialog(this, datePicker, myCalendar.get(Calendar.YEAR), myCalendar.get(
                Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }

        binding!!.jenkelGrup.setOnCheckedChangeListener { group, checkedId ->
            jenkel = when(checkedId){
                R.id.jenkel_laki -> "Laki-laki"
                R.id.jenkel_prp -> "Perempuan"
                else -> "Tidak memilih"
            }
        }

        binding!!.btnSignIn.setOnClickListener{
            no_user = binding!!.etRegNis.text.toString()
            nama_user = binding!!.etRegNama.text.toString()
            tempat_lahir = binding!!.etRegTmLahir.text.toString()
            tgl_lahir = binding!!.tvDate2.text.toString()
            alamat = binding!!.etRegAlamat.text.toString()
            notelp = binding!!.etRegNotelp.text.toString()
            email = binding!!.etRegEmail.text.toString()
            username = binding!!.etRegUsername.text.toString()
            password = binding!!.etRegPassword.text.toString()

            when{
                //Validasi nis
                no_user == "" -> {
                    binding!!.etRegNis.error = "NIS tidak boleh kosong"
                }
                !no_user.matches("[0-9]*".toRegex())  -> {
                    binding!!.etRegNis.error = "NIS tidak boleh mengandung huruf,spasi atapun karakter tertentu"
                }

                //Validasi nama
                nama_user == "" -> {
                    binding!!.etRegNama.error = "Nama tidak boleh kosong"
                }
                !nama_user.matches("[A-Za-z ]*".toRegex())  -> {
                    binding!!.etRegNama.error = "Nama tidak boleh mengandung angka ataupun karakter tertentu"
                }
                nama_user.length < 5  -> {
                    binding!!.etRegNama.error = "Input nama terlalu pendek, Minimal 5 kata!"
                }

                //validasi tempat lahir
                tempat_lahir == "" -> {
                    binding!!.etRegTmLahir.error = "Tempat lahir tidak boleh kosong"
                }
                !tempat_lahir.matches("[A-Za-z ]*".toRegex())  -> {
                    binding!!.etRegTmLahir.error = "Tempat lahir tidak boleh mengandung angka ataupun karakter tertentu"
                }
                tempat_lahir.length < 5  -> {
                    binding!!.etRegTmLahir.error = "Input tempat lahir terlalu pendek, Minimal 5 kata!"
                }

                //validasi tgl lahir
                tgl_lahir == "" -> {
                    binding!!.tvDate2.error = "Tanggal lahir tidak boleh kosong"
                }

                //validasi alamat
                alamat == "" -> {
                    binding!!.etRegAlamat.error = "Alamat tidak boleh kosong"
                }
                alamat.length < 5  -> {
                    binding!!.etRegAlamat.error = "Input alamat terlalu pendek, Minimal 5 kata!"
                }


                //validasi no telp
                notelp == "" -> {
                    binding!!.etRegNotelp.error = "No Telp tidak boleh kosong"
                }
                !notelp.matches("[0-9]*".toRegex())  -> {
                    binding!!.etRegNotelp.error = "Nomor telfon tidak boleh mengandung huruf,spasi atapun karakter tertentu"
                }
                notelp.length < 10 || notelp.length > 13  -> {
                    binding!!.etRegNotelp.error = "Input no.telp tidak sesuai, Min.10 angka, Max.13 angka!"
                }
                //validasi email
                email == "" || !Patterns.EMAIL_ADDRESS.matcher(email).matches() -> {
                    binding!!.etRegEmail.error = "Email kosong atau tidak sesuai format"
                }

                //validasi username
                username == "" -> {
                    binding!!.etRegUsername.error = "Username tidak boleh kosong"
                }
                !username.matches("[A-Za-z0-9]+".toRegex())  -> {
                    binding!!.etRegUsername.error = "Username tidak boleh mengandung spasi"
                }
                username.length < 5  -> {
                    binding!!.etRegUsername.error = "Input username terlalu pendek, Minimal 5 kata!"
                }

                //validasi password
                password == "" -> {
                    binding!!.etRegPassword.error = "Password tidak boleh kosong"
                }
                !password.matches("[A-Za-z0-9]+".toRegex())  -> {
                    binding!!.etRegPassword.error = "Password tidak boleh mengandung spasi"
                }

                else -> {
                    binding!!.loading.visibility = View.VISIBLE
                    addRegister()
                }
            }
        }

    }

    fun toRequestBody(txt:String) : RequestBody{
        return RequestBody.create("multipart/form-data".toMediaTypeOrNull(), txt)
    }

    private fun addRegister(){
        //UPLOAD FOTO
        try{
            val file = RequestBody.create("multipart/form-data".toMediaTypeOrNull(), this.foto)
            val body = MultipartBody.Part.createFormData("foto", this.foto.name, file)

            val api = RetrofitClient().getInstances()
            api.userRegister(
                toRequestBody(no_user),toRequestBody(nama_user),
                toRequestBody(jenkel),toRequestBody(tempat_lahir),
                toRequestBody(tgl_lahir),toRequestBody(alamat),
                toRequestBody(notelp), toRequestBody(email),
                toRequestBody(username),toRequestBody(password),body).enqueue(object :retrofit2.Callback<Register>{

                override fun onResponse(call: Call<Register>, response: Response<Register>) {
                    if (response.isSuccessful) {
                        binding!!.loading.visibility = View.GONE
                        if (response.body() != null && response.body()?.result_code == true) {
                            binding!!.loading.visibility = View.GONE
                            val msg: String? = response.body()?.message
                            showCustomDialogBox(msg)
                        } else {
                            binding!!.loading.visibility = View.GONE
                            Toast.makeText(
                                this@RegisterActivity,
                                response.body()?.message,
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    } else {
                        Log.e("RegisterActivity", "Gagal melakukan permintaan: ${response.code()}")
                        Toast.makeText(
                            this@RegisterActivity,
                            "Terjadi Kesalahan",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onFailure(call: Call<Register>, t: Throwable) {
                    Log.e("pesan error","${t.message}")
                }


            })
        } catch (e:Exception){
            binding!!.loading.visibility = View.GONE
            Toast.makeText(this, "Upload foto!!", Toast.LENGTH_SHORT).show()
        }
    }

    private fun txt_signInListener(){
        txt_signIn.setOnClickListener{
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    fun upload(v : View){
        var intents = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intents.setType("image/*")
        startActivityForResult(Intent.createChooser(intents, "Pilih Foto"), 121)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode) {
            121 -> {
                if(resultCode == Activity.RESULT_OK){
                    val dt = data?.data as Uri
                    binding!!.imgLoad.visibility = View.VISIBLE
                    findViewById<ImageView>(R.id.imgLoad).setImageURI(dt)

                    this.foto =  File(RealPathUtils().getRealPath(this@RegisterActivity, dt))
                    RealPathUtils().getRealPath(this@RegisterActivity, dt)

                }
            }
            157 -> {
                if(resultCode == Activity.RESULT_OK){
                    setResult(RESULT_OK)
                } else {
                    setResult(RESULT_CANCELED)
                }
                finish()
            }
        }
    }
    //ambil value tanggal
    private fun updateAble(myCalendar: Calendar) {
        val myFormat = "yyyy-MM-dd"
        val sdf = SimpleDateFormat(myFormat, Locale.UK)
        tvDate.setText(sdf.format(myCalendar.time))

    }

    private fun showCustomDialogBox(msg: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.layout_alert2)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog.findViewById(R.id.btnYes)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            dialog.dismiss()
            finish()
        }
        dialog.show()
    }

    fun btn_backListener(v:View){
        finish()
    }
}
