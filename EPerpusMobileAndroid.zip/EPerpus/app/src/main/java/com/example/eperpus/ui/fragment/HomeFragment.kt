package com.example.eperpus.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.eperpus.*
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.model.adapter.BukuAdapter
import com.example.eperpus.model.data_class.Buku
import com.example.eperpus.ui.kelolaAkun.EditProfilActivity
import com.example.eperpus.ui.menu.panduanActivity
import com.example.eperpus.ui.pemijaman.DetailBuku
import com.example.eperpus.ui.menu.historyActivity
import kotlinx.android.synthetic.main.fragment_home.*

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment() {

    private lateinit var swipeRefresh : SwipeRefreshLayout
    private lateinit var bukuArrayList : ArrayList<Buku>
    lateinit var btn_layMenu1: Button
    lateinit var btn_layMenu2: Button
    lateinit var btn_layMenu3: Button


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view: View = inflater.inflate(R.layout.fragment_home, container, false)
        val tvNama : TextView = view.findViewById(R.id.txtH_username)
        val args = this.arguments
        val namaDsbd = args?.get("nama")
        tvNama.text = namaDsbd.toString()

        //Menu 1
        btn_layMenu1 = view.findViewById(R.id.menu1)
        btn_layMenu1.setOnClickListener(){
            val intent = Intent(activity, panduanActivity::class.java)
            startActivity(intent)
        }

        //Menu2
        btn_layMenu2 = view.findViewById(R.id.menu2)
        btn_layMenu2.setOnClickListener(){
            val intent = Intent(activity, historyActivity::class.java)
            startActivity(intent)
        }

        //Menu3
        btn_layMenu3 = view.findViewById(R.id.menu3)
        btn_layMenu3.setOnClickListener(){
            val intent = Intent(activity, EditProfilActivity::class.java)
            startActivity(intent)
        }

        //kontrol refresh -> refresh akan bekerja jika hanya layout berada di list 1
        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnChildScrollUpCallback(object : SwipeRefreshLayout.OnChildScrollUpCallback {
            override fun canChildScrollUp(parent: SwipeRefreshLayout, child: View?): Boolean {
                if (listView != null) {
                    return listView.canScrollVertically(-1)
                }
                return false
            }
        })


        val api = RetrofitClient().getInstances()
        api.viewBuku().enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        bukuArrayList.add(bk)
                    }
                    listView.adapter = BukuAdapter(requireActivity(),bukuArrayList)
                    listView.setOnItemClickListener { parent, view, position, id ->
//                        SharedPrefManager.getInstance(requireActivity()).saveBuku(response.body()!![position]!!.id_buku)
                        val id_buku = response.body()!![position]!!.id_buku
                        val stok = response.body()!![position]!!.stok
                        val i = Intent(activity, DetailBuku::class.java)
                        i.putExtra("id_buku",id_buku)
                        i.putExtra("stok",stok)
                        startActivity(i)
                    }
                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(requireActivity().applicationContext,t.message,Toast.LENGTH_LONG).show()
            }
        })



        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnRefreshListener{

            Toast.makeText(requireActivity().applicationContext,"Memperbarui Data", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                swipeRefresh.isRefreshing = false
                //Api Untuk menampilkan data buku
                val api = RetrofitClient().getInstances()
                api.viewBuku().enqueue(object  : Callback<List<Buku>> {
                    override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                        if (response.body() != null && response.isSuccessful()){
                            bukuArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val bk = Buku(
                                    response.body()!![i]!!.id_buku,
                                    response.body()!![i]!!.kd_buku,
                                    response.body()!![i]!!.judul,
                                    response.body()!![i]!!.no_buku,
                                    response.body()!![i]!!.pengarang,
                                    response.body()!![i]!!.penerbit,
                                    response.body()!![i]!!.thn_terbit,
                                    response.body()!![i]!!.stok,
                                    response.body()!![i]!!.sampul,
                                    response.body()!![i]!!.keterangan_buku,
                                    response.body()!![i]!!.id_ktg,
                                    response.body()!![i]!!.nama_ktg
                                )
                                bukuArrayList.add(bk)
                            }
                            listView.adapter = BukuAdapter(requireActivity(),bukuArrayList)
                            listView.setOnItemClickListener { parent, view, position, id ->
                                val id_buku = response.body()!![position]!!.id_buku
                                val stok = response.body()!![position]!!.stok
                                val i = Intent(activity, DetailBuku::class.java)
                                i.putExtra("id_buku",id_buku)
                                i.putExtra("stok",stok)
                                startActivity(i)
                            }
                        }
                    }

                    override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                        Toast.makeText(requireActivity().applicationContext,t.message,Toast.LENGTH_LONG).show()
                    }
                })
                Toast.makeText(requireActivity().applicationContext,"Memperbarui Data Selesai", Toast.LENGTH_LONG).show()
            }, 3000L)
        }


        return view
    }


}