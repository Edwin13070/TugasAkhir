package com.example.eperpus.ui.kelolaAkun

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.eperpus.LoginActivity
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.model.data_class.LupaPassword
import kotlinx.android.synthetic.main.activity_register.*
import kotlinx.android.synthetic.main.activity_register.loading
import kotlinx.android.synthetic.main.activity_reset_password.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class ResetPassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reset_password)


        val tv_ResetPassword = findViewById<EditText>(R.id.txt_ResetPassword)
        val tv_KonfirmasiPassword = findViewById<EditText>(R.id.txt_KonfirmasiPassword)
        val btnReset = findViewById<Button>(R.id.btn_resetpswd)

        //hasil parsing data dari activity lupaPassword
        val email = intent.getStringExtra("email")


        btnReset.setOnClickListener{
            val isi_ResetPassword = tv_ResetPassword.text.toString().trim()
            val isi_KonfirmasiPassword = tv_KonfirmasiPassword.text.toString().trim()
            val isi_mail = email.toString().trim()

            if(isi_ResetPassword.isEmpty()) {
                tv_ResetPassword.error = "Password tidak boleh kosong!"
                tv_ResetPassword.requestFocus()
                return@setOnClickListener
            }
            else if(isi_KonfirmasiPassword.isEmpty()) {
                tv_KonfirmasiPassword.error = "Konfirmasi Password tidak boleh kosong!"
                tv_KonfirmasiPassword.requestFocus()
                return@setOnClickListener
            }
            else if (isi_KonfirmasiPassword != isi_ResetPassword ){
                tv_KonfirmasiPassword.error = "Konfirmasi password tidak sesuai"
                tv_KonfirmasiPassword.requestFocus()
                return@setOnClickListener
            }
            else{
                loadingFG.visibility = View.VISIBLE
                val api = RetrofitClient().getInstances()
                api.resetPassword(isi_mail,isi_ResetPassword)
                    .enqueue(object  : Callback<LupaPassword> {
                        override fun onResponse(call: Call<LupaPassword>, response: Response<LupaPassword>) {
                            if (response.isSuccessful()) {
                                if (response.body() != null && response.body()?.result_code == true) {
                                    Toast.makeText(
                                        applicationContext,
                                        response.body()?.message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                    val i = Intent(this@ResetPassword, LoginActivity::class.java)
                                    startActivity(i)
                                } else {
                                    loadingFG.visibility = View.GONE
                                    Toast.makeText(
                                        applicationContext,
                                        response.body()?.message,
                                        Toast.LENGTH_LONG
                                    ).show()
                                }

                            }else{
                                loadingFG.visibility = View.GONE
                                Toast.makeText(
                                    applicationContext,
                                    "Proses gagal, Terjadi Kesalahan",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }

                        override fun onFailure(call: Call<LupaPassword>, t: Throwable) {
                            Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
                        }

                    })
            }

        }
    }

    fun btn_backListener(v: View){
        finish()
    }
}