package com.example.eperpus.ui.fragment

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.eperpus.*
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.api.repo
import com.example.eperpus.model.adapter.BukuAdapter
import com.example.eperpus.model.adapter.BukuAdapter2
import com.example.eperpus.model.data_class.Buku
import com.example.eperpus.model.storage.SharedPrefManager
import com.example.eperpus.ui.menu.historyActivity
import com.example.eperpus.ui.pemijaman.DetailBuku
import com.example.eperpus.ui.pemijaman.FilterKategori
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_buku.*
import kotlinx.android.synthetic.main.fragment_home.*


import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class BukuFragment : Fragment() {

    private lateinit var swipeRefresh : SwipeRefreshLayout
    private lateinit var bukuArrayList : ArrayList<Buku>
    private lateinit var cari : TextView
    lateinit var btnKat: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view: View = inflater.inflate(R.layout.fragment_buku, container, false)

        //kontrol refresh -> refresh akan bekerja jika hanya layout berada di list 1
        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnChildScrollUpCallback(object : SwipeRefreshLayout.OnChildScrollUpCallback {
            override fun canChildScrollUp(parent: SwipeRefreshLayout, child: View?): Boolean {
                if (gridView != null) {
                    return gridView.canScrollVertically(-1)
                }
                return false
            }
        })

        btnKat = view.findViewById(R.id.btn_filter)
        btnKat.setOnClickListener(){
            val i = Intent(activity, FilterKategori::class.java)
            startActivity(i)
        }

        val api = RetrofitClient().getInstances()
        api.viewBuku().enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        bukuArrayList.add(bk)
                    }
                    gridView.adapter = BukuAdapter2(requireActivity(),bukuArrayList)
                    gridView.setOnItemClickListener { parent, view, position, id ->
                        val id_buku = response.body()!![position]!!.id_buku
                        val stok = response.body()!![position]!!.stok

                        val i = Intent(requireContext(), DetailBuku::class.java)
                        i.putExtra("id_buku",id_buku)
                        i.putExtra("stok",stok)
                        startActivity(i)
                    }
                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(requireContext(),t.message,Toast.LENGTH_LONG).show()
            }
        })



        //Function untuk pencarian
        cari = view.findViewById(R.id.txt_Cari)
        cari.setOnKeyListener(View.OnKeyListener{v, keyCode, event ->

            if( keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP){
                val kata_cari = cari.text.toString().trim()
                val api = RetrofitClient().getInstances()
                api.cariBuku(kata_cari).enqueue(object  : Callback<List<Buku>> {
                    override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                        if (response.body() != null && response.isSuccessful()){
                            bukuArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val bk = Buku(
                                    response.body()!![i]!!.id_buku,
                                    response.body()!![i]!!.kd_buku,
                                    response.body()!![i]!!.judul,
                                    response.body()!![i]!!.no_buku,
                                    response.body()!![i]!!.pengarang,
                                    response.body()!![i]!!.penerbit,
                                    response.body()!![i]!!.thn_terbit,
                                    response.body()!![i]!!.stok,
                                    response.body()!![i]!!.sampul,
                                    response.body()!![i]!!.keterangan_buku,
                                    response.body()!![i]!!.id_ktg,
                                    response.body()!![i]!!.nama_ktg
                                )
                                bukuArrayList.add(bk)
                            }
                            gridView.adapter = BukuAdapter2(requireActivity(),bukuArrayList)
                            gridView.setOnItemClickListener { parent, view, position, id ->
                                val id_buku = response.body()!![position]!!.id_buku
                                val stok = response.body()!![position]!!.stok

                                val i = Intent(requireContext(), DetailBuku::class.java)
                                i.putExtra("id_buku",id_buku)
                                i.putExtra("stok",stok)
                                startActivity(i)
                            }
                        }
                    }

                    override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                        Toast.makeText(requireContext(),t.message,Toast.LENGTH_LONG).show()
                    }
                })

                return@OnKeyListener true

            }
            false

        })


        //Fungsi refresh
        swipeRefresh = view.findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnRefreshListener{

            Toast.makeText(requireActivity().applicationContext,"Memperbarui Data", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                swipeRefresh.isRefreshing = false
                //Api Untuk menampilkan data buku
                val api = RetrofitClient().getInstances()
                api.viewBuku().enqueue(object  : Callback<List<Buku>> {
                    override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                        if (response.body() != null && response.isSuccessful()){
                            bukuArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val bk = Buku(
                                    response.body()!![i]!!.id_buku,
                                    response.body()!![i]!!.kd_buku,
                                    response.body()!![i]!!.judul,
                                    response.body()!![i]!!.no_buku,
                                    response.body()!![i]!!.pengarang,
                                    response.body()!![i]!!.penerbit,
                                    response.body()!![i]!!.thn_terbit,
                                    response.body()!![i]!!.stok,
                                    response.body()!![i]!!.sampul,
                                    response.body()!![i]!!.keterangan_buku,
                                    response.body()!![i]!!.id_ktg,
                                    response.body()!![i]!!.nama_ktg
                                )
                                bukuArrayList.add(bk)
                            }
                            gridView.adapter = BukuAdapter2(requireActivity(),bukuArrayList)
                            gridView.setOnItemClickListener { parent, view, position, id ->
                                val id_buku = response.body()!![position]!!.id_buku
                                val stok = response.body()!![position]!!.stok

                                val i = Intent(requireContext(), DetailBuku::class.java)
                                i.putExtra("id_buku",id_buku)
                                i.putExtra("stok",stok)
                                startActivity(i)
                            }
                        }
                    }

                    override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                        Toast.makeText(requireContext(),t.message,Toast.LENGTH_LONG).show()
                    }
                })
                Toast.makeText(requireActivity().applicationContext,"Memperbarui Data Selesai", Toast.LENGTH_LONG).show()
            }, 3000L)
        }


        return  view
    }


}