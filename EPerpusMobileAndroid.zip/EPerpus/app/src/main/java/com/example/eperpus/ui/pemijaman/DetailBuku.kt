package com.example.eperpus.ui.pemijaman

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.api.repo
import com.example.eperpus.model.adapter.BukuAdapter
import com.example.eperpus.model.adapter.BukuAdapter2
import com.example.eperpus.model.data_class.Buku
import com.example.eperpus.model.storage.SharedPrefManager
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_buku.*
import kotlinx.android.synthetic.main.activity_detail_buku.gridView
import kotlinx.android.synthetic.main.fragment_home.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailBuku : AppCompatActivity() {

    private lateinit var bukuArrayList : ArrayList<Buku>
    lateinit var btnSimpan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_buku)
        tampilData()
        listBukuLain()

        btnSimpan = findViewById(R.id.btn_ProfPnj)
        btnSimpan.setOnClickListener(){
            val stok =intent.getStringExtra("stok").toString()
            if(stok == "0"){
                val msg= "Maaf stok buku tidak tersedia, silahkan pilih buku lain"
                showCustomDialogBox(msg)
            }else{
                val id_buku =intent.getStringExtra("id_buku")
                val i = Intent(this, TambahPeminjaman::class.java)
                i.putExtra("id_buku",id_buku)
                startActivity(i)
            }
        }

    }
    private fun showCustomDialogBox(msg: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.layout_alert2)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog.findViewById(R.id.btnYes)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            dialog.dismiss()
        }
        dialog.show()
    }

    fun tampilData(){
        loadingSrv.visibility = View.VISIBLE
        val id_buku = intent.getStringExtra("id_buku").toString()
        val api = RetrofitClient().getInstances()
        api.getBukuById(id_buku).enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        //panggil Id element xml
                        val namaBk = findViewById<TextView>(R.id.namaBk)
                        val kdBuku = findViewById<TextView>(R.id.txt_kdBuku)
                        val NoBuku = findViewById<TextView>(R.id.txt_NoBuku)
                        val kategori = findViewById<TextView>(R.id.txt_kategori)
                        val prg = findViewById<TextView>(R.id.txt_pengarang)
                        val prb = findViewById<TextView>(R.id.txt_penerbit)
                        val thnTerbit = findViewById<TextView>(R.id.txt_thnTerbit)
                        val stok_bk = findViewById<TextView>(R.id.txt_stok)
                        val keterangan = findViewById<TextView>(R.id.txt_keterangan)
                        val foto = findViewById<ImageView>(R.id.iv_buku)

                        //hasil query retrofit
                        val judul = response.body()!![i].judul
                        val kd_buku = response.body()!![i].kd_buku
                        val no_buku = response.body()!![i].no_buku
                        val nama_ktg = response.body()!![i].nama_ktg
                        val pengarang = response.body()!![i].pengarang
                        val penerbit = response.body()!![i].penerbit
                        val thn_terbit = response.body()!![i].thn_terbit
                        val stok = response.body()!![i].stok
                        val kerangan_buku = response.body()!![i].keterangan_buku
                        val foto_buku = response.body()!![i].sampul
                        val urlFoto = repo.base_url +"/$foto_buku"

                        namaBk.text = judul
                        kdBuku.text = kd_buku
                        NoBuku.text = no_buku
                        kategori.text = nama_ktg
                        prg.text = pengarang
                        prb.text = penerbit
                        thnTerbit.text = thn_terbit
                        stok_bk.text = stok
                        keterangan.text = kerangan_buku
                        Picasso.get().load(urlFoto).into(foto)
                    }
                    loadingSrv.visibility = View.GONE

                }else {
                    Toast.makeText(applicationContext,"Tidak Ada Data Buku!",
                        Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message, Toast.LENGTH_LONG).show()
            }
        })

    }

    fun listBukuLain(){
        val id_buku = intent.getStringExtra("id_buku").toString()
        val api = RetrofitClient().getInstances()
        api.getBukuById2(id_buku).enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        bukuArrayList.add(bk)
                    }
                    gridView.adapter = BukuAdapter2(this@DetailBuku,bukuArrayList)
                    gridView.setOnItemClickListener { parent, view, position, id ->
                        //SharedPrefManager.getInstance(applicationContext).saveBuku(response.body()!![position]!!.id_buku)
                        val id_buku = response.body()!![position]!!.id_buku
                        val stok = response.body()!![position]!!.stok
                        val i = Intent(this@DetailBuku, DetailBuku::class.java)
                        i.putExtra("id_buku",id_buku)
                        i.putExtra("stok",stok)
                        startActivity(i)

                    }
                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message,Toast.LENGTH_LONG).show()
            }
        })
    }

    fun btn_backListener(v: View){
        finish()
    }

}