package com.example.eperpus.model.data_class

class DurasiInput  (
    val max_hari : String?
)