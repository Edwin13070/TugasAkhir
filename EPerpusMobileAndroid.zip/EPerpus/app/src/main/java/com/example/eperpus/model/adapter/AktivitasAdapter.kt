package com.example.eperpus.model.adapter

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.eperpus.R
import com.example.eperpus.model.data_class.AktivitasUser
import com.example.eperpus.ui.pemijaman.EditPinjam

class AktivitasAdapter(private val mContext : Activity, private val arrayList:ArrayList<AktivitasUser>): ArrayAdapter<AktivitasUser>(mContext, R.layout.list_aktivitas, arrayList)  {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater : LayoutInflater = LayoutInflater.from(mContext)
        val view : View = inflater.inflate(R.layout.list_aktivitas,null)

        val namaBk : TextView = view.findViewById(R.id.tv_kdPinjam)
        val pnbt : TextView = view.findViewById(R.id.tv_tglPinjam)
        val kdBk : TextView = view.findViewById(R.id.tv_durasi)
        val stk : TextView = view.findViewById(R.id.tv_status)
        val editSr : TextView = view.findViewById(R.id.tv_edit)






        if(arrayList[position].kd_pinjam!!.isEmpty() && arrayList[position].status_pinjam=="1" ){
            namaBk.text = "Pending" //ubah tulisan ini menjadi merah
            namaBk.setTextColor(Color.parseColor("#ce181e"))
            stk.text = "Menunggu Konfirmasi"
            editSr.visibility = View.VISIBLE
            pnbt.text = arrayList[position].tanggal_pinjam
            kdBk.text = arrayList[position].durasi
            //button edit
            editSr.setOnClickListener(){

                val s = Intent(context, EditPinjam  ::class.java)
                s.putExtra("id_pinjam",arrayList[position].id_pinjam )
                ContextCompat.startActivity(context, s, null)
            }
        }else if( arrayList[position].kd_pinjam!!.isEmpty() && arrayList[position].status_pinjam=="4"){
            namaBk.text = "-" //ubah tulisan ini menjadi merah
            pnbt.text = "-"
            stk.text = "Dibatalkan"
            editSr.visibility = View.GONE
            stk.setTextColor(Color.parseColor("#ce181e"))
            kdBk.text = "-"
        }else if(arrayList[position].status_pinjam=="6"){
            namaBk.text = "-" //ubah tulisan ini menjadi merah
            pnbt.text = "-"
            stk.text = "Dibatalkan sistem"
            editSr.visibility = View.GONE
            stk.setTextColor(Color.parseColor("#ce181e"))
            kdBk.text = "-"
        }else{
            namaBk.text = arrayList[position].kd_pinjam
            stk.text = "Terkonfirmasi"
            editSr.visibility = View.GONE
            pnbt.text = arrayList[position].tanggal_pinjam
            kdBk.text = arrayList[position].durasi
        }


        return view
    }
}