package com.example.eperpus.model.data_class

data class LupaPassword (
    val status : String,
    val message: String,
    val result_code : Boolean

)