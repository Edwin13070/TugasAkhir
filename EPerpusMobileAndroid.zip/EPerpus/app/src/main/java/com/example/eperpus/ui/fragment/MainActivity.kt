package com.example.eperpus.ui.fragment

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import com.example.eperpus.R
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import com.example.eperpus.LoginActivity
import com.example.eperpus.databinding.ActivityMainBinding
import com.example.eperpus.model.storage.SharedPrefManager
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {


    val fragmentHome : Fragment = HomeFragment()
    val fragmenBuku : Fragment =BukuFragment();
    val fragmentAktivitas : Fragment = AktivitasFragment()
    val fragmentProfil : Fragment = ProfileFragment()
    val fm: FragmentManager = supportFragmentManager
    var active : Fragment = fragmentHome

    private lateinit var binding : ActivityMainBinding
    private lateinit var menu : Menu
    private lateinit var menuItem: MenuItem
    private lateinit var bottomNavigationView: BottomNavigationView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setUpBottomNav()
    }

    private fun setUpBottomNav() {
        val data = SharedPrefManager.getInstance(this).user
        val bundle = Bundle()
        bundle.putString("id", data.id.toString())
        bundle.putString("nis", data.nis.toString())
        bundle.putString("nama", data.nama.toString())
        bundle.putString("jenkel", data.jenkel.toString())
        bundle.putString("tempat_lahir", data.tempat_lahir.toString())
        bundle.putString("tgl_lahir", data.tgl_lahir.toString())
        bundle.putString("alamat", data.alamat.toString())
        bundle.putString("no_telp", data.no_telp.toString())
        bundle.putString("username", data.username.toString())
        bundle.putString("password", data.password.toString())
        bundle.putString("email", data.email.toString())
        bundle.putString("hak_akses", data.hak_akses.toString())
        bundle.putString("foto", data.foto.toString())
        fragmentHome.arguments = bundle
        fragmenBuku.arguments = bundle
        fragmentAktivitas.arguments = bundle
        fragmentProfil.arguments = bundle

        fm.beginTransaction().add(R.id.navi_content, fragmentHome).show(fragmentHome).commit()
        fm.beginTransaction().add(R.id.navi_content, fragmenBuku).hide(fragmenBuku).commit()
        fm.beginTransaction().add(R.id.navi_content, fragmentAktivitas).hide(fragmentAktivitas).commit()
        fm.beginTransaction().add(R.id.navi_content, fragmentProfil).hide(fragmentProfil).commit()

        bottomNavigationView = findViewById(R.id.btn_navi_view)
        menu = bottomNavigationView.menu
        menuItem = menu.getItem(0)
        menuItem.isChecked = true

        bottomNavigationView.setOnItemSelectedListener { item ->
            when(item.itemId){
                R.id.navi_home -> {
                    callFragment(0, fragmentHome)
                }
                R.id.navi_buku -> {
                    callFragment(1, fragmenBuku)
                }
                R.id.navi_aktivitas -> {
                    callFragment(2, fragmentAktivitas)
                }
                R.id.navi_profile -> {
                    callFragment(3, fragmentProfil)
                }
            }
            false
        }
    }

    fun callFragment(int: Int , fragment: Fragment){

        menuItem = menu.getItem(int)
        menuItem.isChecked = true
        fm.beginTransaction().hide(active).show(fragment).commit()
        active = fragment
    }

    override fun onStart() {
        super.onStart()
        if(!SharedPrefManager.getInstance(this).isLoggedIn){
            val intent = Intent(this@MainActivity, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

    }
}