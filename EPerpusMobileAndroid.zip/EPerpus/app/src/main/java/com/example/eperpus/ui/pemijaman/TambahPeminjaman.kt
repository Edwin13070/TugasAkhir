package com.example.eperpus.ui.pemijaman

import android.app.DatePickerDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.api.repo
import com.example.eperpus.model.adapter.BukuAdapter
import com.example.eperpus.model.adapter.DetailBukuAdapter
import com.example.eperpus.model.data_class.Buku
import com.example.eperpus.model.data_class.DurasiInput
import com.example.eperpus.model.data_class.Peminjaman
import com.example.eperpus.model.login.DataLogin
import com.example.eperpus.model.storage.SharedPrefManager
import com.example.eperpus.ui.fragment.MainActivity
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_detail_buku.*
import kotlinx.android.synthetic.main.activity_tambah_peminjaman.*
import kotlinx.android.synthetic.main.fragment_home.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class TambahPeminjaman : AppCompatActivity() {

    private lateinit var bukuArrayList : ArrayList<Buku>
    private lateinit var profilCusArrayList : ArrayList<DataLogin>
    private lateinit var durasiArrayList : ArrayList<DurasiInput>
    private lateinit var tvDate : TextView
    private  lateinit var datePickerButton : Button
    lateinit var btnSimpan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_peminjaman)
        tampilBuku()
        tampil_Profil()
        tampil_Durasi()


        //FUNCTION TAMPIL TANGGAL
        tvDate = findViewById(R.id.et_tanggalPinjam)
        datePickerButton = findViewById(R.id.datePickerButton2)

        val myCalendar = Calendar.getInstance()

        val datePicker = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            myCalendar.set(Calendar.YEAR, year)
            myCalendar.set(Calendar.MONTH, month)
            myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)
            updateAble(myCalendar)
        }

        datePickerButton.setOnClickListener{
            DatePickerDialog(this, datePicker, myCalendar.get(Calendar.YEAR), myCalendar.get(
                Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)).show()
        }


        //Proses simpan data ke variabel
        val txt_tanggal_pinjam = findViewById<TextView>(R.id.et_tanggalPinjam)
        val txt_durasi = findViewById<TextView>(R.id.et_durasi)

        btnSimpan = findViewById(R.id.btn_simpanPnj)
        btnSimpan.setOnClickListener() {
            val tanggal_pinjam = txt_tanggal_pinjam.text.toString().trim()
            val durasi = "0"
            val id_buku = intent.getStringExtra("id_buku").toString()
            val id_anggota = SharedPrefManager.getInstance(this).user.id.toString()

            if (tanggal_pinjam.isEmpty()){
                txt_tanggal_pinjam.error="Tanggal pinjam tidak boleh kosong!"
                txt_tanggal_pinjam.requestFocus()
                return@setOnClickListener
            }
            else if (durasi.isEmpty()){
                txt_durasi.error="Durasi tidak boleh kosong!"
                txt_durasi.requestFocus()
                return@setOnClickListener
            }
            else{
                loading.visibility = View.VISIBLE
                val api = RetrofitClient().getInstances()
                api.inputPnj(tanggal_pinjam, durasi, id_buku, id_anggota)
                    .enqueue(object :retrofit2.Callback<Peminjaman>{
                    override fun onResponse(call: Call<Peminjaman>, response: Response<Peminjaman>) {
                        if (response.isSuccessful()) {
                            if (response.body() != null && response.body()?.result_code == true) {
                                val msg : String? =response.body()?.message
                                showCustomDialogBox(msg)
                            } else {
                                Toast.makeText(
                                    this@TambahPeminjaman,
                                    response.body()?.message,
                                    Toast.LENGTH_LONG
                                ).show()
                                loading.visibility = View.GONE
                            }
                        }else{
                            Toast.makeText(
                                this@TambahPeminjaman,
                                "Terjadi Kesalahan",
                                Toast.LENGTH_LONG
                            ).show()
                            loading.visibility = View.GONE
                        }
                    }

                    override fun onFailure(call: Call<Peminjaman>, t: Throwable) {
                        Log.e("pesan error","${t.message}")
                        loading.visibility = View.GONE
                    }


                })

            }

        }


    }


    fun tampilBuku(){
        val id_buku = intent.getStringExtra("id_buku").toString()
        val api = RetrofitClient().getInstances()
        api.getBukuById(id_buku).enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        bukuArrayList.add(bk)
                    }
                    listDetail.adapter = DetailBukuAdapter(this@TambahPeminjaman,bukuArrayList)

                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message,Toast.LENGTH_LONG).show()
            }
        })


    }

    fun tampil_Profil(){
        val id_userLogIn = SharedPrefManager.getInstance(this).user.id.toString()
        val hak_aksesUser = SharedPrefManager.getInstance(this).user.hak_akses.toString()

        val api = RetrofitClient().getInstances()
        api.getIdUser(id_userLogIn,hak_aksesUser).enqueue(object  : Callback<List<DataLogin>> {
            override fun onResponse(call: Call<List<DataLogin>>, response: Response<List<DataLogin>>) {
                if (response.body() != null && response.isSuccessful()){
                    profilCusArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val prl = DataLogin(
                            response.body()!![i]!!.id,
                            response.body()!![i]!!.nis,
                            response.body()!![i]!!.nama,
                            response.body()!![i]!!.jenkel,
                            response.body()!![i]!!.tempat_lahir,
                            response.body()!![i]!!.tgl_lahir,
                            response.body()!![i]!!.alamat,
                            response.body()!![i]!!.no_telp,
                            response.body()!![i]!!.username,
                            response.body()!![i]!!.password,
                            response.body()!![i]!!.email,
                            response.body()!![i]!!.hak_akses,
                            response.body()!![i]!!.foto

                        )


                        val tvNama : TextView = findViewById(R.id.txt_nama)
                        val tvNis : TextView = findViewById(R.id.txt_nis)
                        val tvTelp : TextView = findViewById(R.id.txt_notelp)
                        val tvMail : TextView = findViewById(R.id.txt_email)

                        val nama_Prof = response.body()!![i].nama
                        val nis = response.body()!![i].nis
                        val no_telp = response.body()!![i].no_telp
                        val email_usr = response.body()!![i].email

//                        tvIdUser.text = id_user
                        tvNama.text = nama_Prof
                        tvNis.text = nis
                        tvTelp.text = no_telp
                        tvMail.text = email_usr

                    }

                }else {
                    Toast.makeText(applicationContext,"Tidak Ada Data profil!",
                        Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<List<DataLogin>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message, Toast.LENGTH_LONG).show()
            }
        })
    }

    fun tampil_Durasi(){
        val api = RetrofitClient().getInstances()
        api.getDurasi().enqueue(object  : Callback<List<DurasiInput>> {
            override fun onResponse(call: Call<List<DurasiInput>>, response: Response<List<DurasiInput>>) {
                if (response.body() != null && response.isSuccessful()){
                    durasiArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val prl = DurasiInput(
                            response.body()!![i]!!.max_hari
                        )


                        val tvDrsInput : TextView = findViewById(R.id.durasi)
                        val isi_durasiInput = response.body()!![i].max_hari

                        tvDrsInput.text = isi_durasiInput

                    }

                }else {
                    Toast.makeText(applicationContext,"Tidak Ada Data profil!",
                        Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<List<DurasiInput>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message, Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun updateAble(myCalendar: Calendar) {
        val myFormat = "yyyy-MM-dd"
        val sdf = SimpleDateFormat(myFormat, Locale.UK)
        tvDate.setText(sdf.format(myCalendar.time))

    }

    private fun showCustomDialogBox(msg: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.layout_alert2)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog.findViewById(R.id.btnYes)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            dialog.dismiss()
        }
        dialog.show()
    }

    fun btn_backListener(v: View){
        finish()
    }
}