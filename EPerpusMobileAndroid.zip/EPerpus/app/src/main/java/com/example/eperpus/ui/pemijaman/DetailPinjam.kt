package com.example.eperpus.ui.pemijaman

import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.Window
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.eperpus.LoginActivity
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.model.adapter.DetailBukuAdapter
import com.example.eperpus.model.data_class.AktivitasUser
import com.example.eperpus.model.data_class.Buku
import com.example.eperpus.model.data_class.DetailPnj
import com.example.eperpus.model.data_class.Peminjaman
import com.example.eperpus.model.storage.SharedPrefManager
import kotlinx.android.synthetic.main.activity_detail_pinjam.*
import kotlinx.android.synthetic.main.activity_edit_pinjam.*
import kotlinx.android.synthetic.main.fragment_aktivitas.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.text.SimpleDateFormat
import java.util.*

class DetailPinjam : AppCompatActivity() {

    private lateinit var dataPinjamArrayList: ArrayList<DetailPnj>
    private lateinit var swipeRefresh : SwipeRefreshLayout
    private lateinit var bukuArrayList : ArrayList<Buku>
    lateinit var btn_cancelPnj: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_pinjam)
        tampilDetail()
        tampilBuku()

        btn_cancelPnj = findViewById(R.id.btn_cancelPnj)
        btn_cancelPnj.setOnClickListener(){
            val msg : String? ="Anda yakin akan membatalkan pengajuan peminjaman?"
            showCustomDialogBox(msg)
        }

    }


    fun tampilDetail(){
        loadingSrv.visibility = View.VISIBLE
        val id_pinjam = intent.getStringExtra("id_pinjam").toString()
        val api = RetrofitClient().getInstances()
        api.getDetail(id_pinjam).enqueue(object  : Callback<List<DetailPnj>> {
            override fun onResponse(call: Call<List<DetailPnj>>, response: Response<List<DetailPnj>>) {
                if (response.body() != null && response.isSuccessful()){
                    dataPinjamArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val Cstmr = DetailPnj(
                            response.body()!![i]!!.id_pinjam,
                            response.body()!![i]!!.kd_pinjam,
                            response.body()!![i]!!.tanggal_pinjam,
                            response.body()!![i]!!.durasi,
                            response.body()!![i]!!.deadline_kembali,
                            response.body()!![i]!!.telat,
                            response.body()!![i]!!.status_pinjam,
                            response.body()!![i]!!.id_admin,
                            response.body()!![i]!!.id_anggota,
                            response.body()!![i]!!.nama_anggota,
                            response.body()!![i]!!.no_anggota,
                            response.body()!![i]!!.email_user,
                            response.body()!![i]!!.nama_admin,
                            response.body()!![i]!!.tgl_pengembalian,
                            response.body()!![i]!!.id_denda,
                            response.body()!![i]!!.total_denda,
                            response.body()!![i]!!.id_pengembalian,
                            response.body()!![i]!!.status_telat,
                        )
                        loadingSrv.visibility = View.GONE
                        val Ket = findViewById<TextView>(R.id.txt_ketStatus)
                        val detail = findViewById<TextView>(R.id.txt_ketDtl)
                        val keterangan = response.body()!![i].status_pinjam

                        val nama = findViewById<TextView>(R.id.txt_nama)
                        val nis = findViewById<TextView>(R.id.txt_nis)
                        val email = findViewById<TextView>(R.id.txt_email)
                        val kd_pinjam = findViewById<TextView>(R.id.txt_kdPnj)
                        val tanggal = findViewById<TextView>(R.id.txt_tglPinjam)
                        val tanggal2 = findViewById<TextView>(R.id.txt_tgl)
                        val tanggal3 = findViewById<TextView>(R.id.txt_tgl2)
                        val durasi = findViewById<TextView>(R.id.txt_durasi)
                        val deadline = findViewById<TextView>(R.id.txt_deadline)
                        val status_pnj = findViewById<TextView>(R.id.txt_status)
                        val kembali = findViewById<TextView>(R.id.txt_kembali)
                        val petugas = findViewById<TextView>(R.id.txt_petugas)
                        val telat = findViewById<TextView>(R.id.txt_telat)
                        val Kettelat1 = findViewById<TextView>(R.id.ketTl1)
                        val Kettelat2 = findViewById<TextView>(R.id.ketTl2)
                        val layout_kembali = findViewById<LinearLayout>(R.id.layout_kembali)
                        val layout_petugas = findViewById<LinearLayout>(R.id.layout_petugas)
                        val asd2 = findViewById<LinearLayout>(R.id.asd)
                        val ketDnd = findViewById<LinearLayout>(R.id.dendaPnjm)
                        val statusPmb1 = findViewById<TextView>(R.id.txt_statusPmb1)
                        val statusPmb2 = findViewById<TextView>(R.id.txt_statusPmb2)
                        val statusPmb3 = findViewById<TextView>(R.id.txt_statusPmb3)
                        val statusPmb4 = findViewById<TextView>(R.id.txt_statusPmb4)
                        val denda = findViewById<TextView>(R.id.txt_denda)
                        val denda2 = findViewById<TextView>(R.id.txt_denda2)


                        val isi_nama = response.body()!![i].nama_anggota
                        val isi_nis = response.body()!![i].no_anggota
                        val isi_email = response.body()!![i].email_user
                        val isi_kd = response.body()!![i].kd_pinjam
                        val isi_tanggal = response.body()!![i].tanggal_pinjam
                        val isi_telat = response.body()!![i].telat
                        val isi_deadline = response.body()!![i].deadline_kembali
                        val isi_durasi = response.body()!![i].durasi
                        val isi_petugas = response.body()!![i].nama_admin
                        val isi_kembali = response.body()!![i].tgl_pengembalian
                        val isi_denda = response.body()!![i].total_denda
                        val isi_statusTelat = response.body()!![i].status_telat

                        if(keterangan == "1"){
                            status_1.visibility = View.VISIBLE
                            detail.visibility = View.VISIBLE
                            btn_cancelPnj.visibility = View.VISIBLE
                            Ket.text = "Belum Terkonfirmasi"
                            kd_pinjam.text = "-"
                            status_pnj.text = "Pending"
                            detail.text = "Menunggu konfirmasi admin"
                            layout_kembali.visibility = View.GONE
                            layout_petugas.visibility = View.GONE
                        }
                        else if(keterangan == "2"){
                            status_1.visibility = View.GONE
                            status_2.visibility = View.VISIBLE
                            asd2.visibility = View.VISIBLE
                            tanggal3.text =isi_tanggal
                            detail.visibility = View.VISIBLE
                            Ket.text = "Terkonfirmasi"
                            status_pnj.text = "Belum Dikembalikan"
                            kd_pinjam.text =isi_kd
                            detail.text="Proses peminjaman disetujui"
                            layout_kembali.visibility = View.GONE
                            petugas.text =isi_petugas

                            if(isi_telat !="0"){
                                telat.text =isi_telat
                                denda2.text =isi_denda
                                telat.setTextColor(Color.parseColor("#ce181e"))
                                Kettelat1.setTextColor(Color.parseColor("#ce181e"))
                                bagtelat.visibility = View.VISIBLE
                                Kettelat1.visibility = View.VISIBLE
                                ketDnd.visibility = View.VISIBLE
                                Kettelat2.setTextColor(Color.parseColor("#ce181e"))
                            }
                        }
                        else if(keterangan == "3") {
                            status_1.visibility = View.GONE
                            status_3.visibility = View.VISIBLE
                            detail.visibility = View.VISIBLE
                            detailPengembalian.visibility = View.VISIBLE
                            kd_pinjam.text =isi_kd
                            denda.text =isi_denda
                            asd2.visibility = View.VISIBLE
                            tanggal3.text =isi_tanggal
                            Ket.text = "Terkonfirmasi"
                            status_pnj.text = "Sudah Dikembalikan"
                            detail.text="Buku telah dikembalikan"
                            kembali.text =isi_kembali
                            petugas.text =isi_petugas
                            if (isi_statusTelat == "terlambat") {
                                statusPmb1.visibility = View.GONE
                                statusPmb2.visibility = View.VISIBLE
                                statusPmb2.setTextColor(Color.parseColor("#ce181e"))
                            }
                            else{
                                statusPmb1.visibility = View.VISIBLE
                                statusPmb2.visibility = View.GONE
                            }

                        }
                        else if (keterangan == "4"){
                            status_1.visibility = View.GONE
                            status_3.visibility = View.GONE
                            detail.visibility = View.VISIBLE
                            bag_tengah.visibility = View.GONE
                            bag_Texttengah2.visibility = View.VISIBLE
                            Ket.text = "Pengajuan dibatalkan"
                            detail.text="Pembatalan pengajuan berhasil dilakukan"
                        }
                        else if (keterangan == "6"){
                            status_1.visibility = View.GONE
                            status_3.visibility = View.GONE
                            detail.visibility = View.VISIBLE
                            bag_tengah.visibility = View.GONE
                            bag_Texttengah2.visibility = View.VISIBLE
                            Ket.text = "Pengajuan dibatalkan"
                            detail.text="Dibatalkan otomatis oleh sistem"
                        }
                        else if (keterangan == "5"){
                            status_1.visibility = View.GONE
                            status_2.visibility = View.VISIBLE
                            detail.visibility = View.VISIBLE
                            Ket.text = "Terkonfirmasi"
                            status_pnj.text = "Belum Dikembalikan"
                            kd_pinjam.text =isi_kd
                            detail.text="Menunggu Konfirmasi Anda"
                            layout_kembali.visibility = View.GONE
                            petugas.text =isi_petugas

                            val dialog = Dialog(this@DetailPinjam)
                            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
                            dialog.setCancelable(false)
                            dialog.setContentView(R.layout.layout_alert)
                            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

                            val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
                            val btnYes : Button = dialog.findViewById(R.id.btnYes)
                            val btnNo : Button = dialog.findViewById(R.id.btnNo)

                            val msg : String? ="Konfirmasi data peminjaman anda"
                            tv_msgAlert.text = msg

                            btnYes.setOnClickListener{
                                dialog.dismiss()
                                loadingSrv.visibility = View.VISIBLE
                                val id_pinjam = intent.getStringExtra("id_pinjam").toString()
                                val api = RetrofitClient().getInstances()
                                api.ApprovePnj(id_pinjam).enqueue(object :retrofit2.Callback<Peminjaman>{

                                    override fun onResponse(call: Call<Peminjaman>, response: Response<Peminjaman>) {
                                        if (response.isSuccessful()) {
                                            if (response.body() != null && response.body()?.result_code == true) {
                                                val msg : String? =response.body()?.message
                                                cancelBox(msg)
                                            } else {
                                                Toast.makeText(
                                                    this@DetailPinjam,
                                                    response.body()?.message,
                                                    Toast.LENGTH_LONG
                                                ).show()
                                                loadingSrv.visibility = View.GONE
                                            }
                                        }else{
                                            Toast.makeText(
                                                this@DetailPinjam,
                                                "Terjadi Kesalahan",
                                                Toast.LENGTH_LONG
                                            ).show()
                                            loadingSrv.visibility = View.GONE
                                        }
                                    }

                                    override fun onFailure(call: Call<Peminjaman>, t: Throwable) {
                                        Log.e("pesan error","${t.message}")
                                        loadingSrv.visibility = View.GONE
                                    }


                                })

                            }
                            btnNo.setOnClickListener{
                                dialog.dismiss()
                                loadingSrv.visibility = View.VISIBLE
                                val id_pinjam = intent.getStringExtra("id_pinjam").toString()
                                val api = RetrofitClient().getInstances()
                                api.UnApprovePnj(id_pinjam).enqueue(object :retrofit2.Callback<Peminjaman>{

                                    override fun onResponse(call: Call<Peminjaman>, response: Response<Peminjaman>) {
                                        if (response.isSuccessful()) {
                                            if (response.body() != null && response.body()?.result_code == true) {
                                                val msg : String? =response.body()?.message
                                                cancelBox(msg)
                                            } else {
                                                Toast.makeText(
                                                    this@DetailPinjam,
                                                    response.body()?.message,
                                                    Toast.LENGTH_LONG
                                                ).show()
                                                loadingSrv.visibility = View.GONE
                                            }
                                        }else{
                                            Toast.makeText(
                                                this@DetailPinjam,
                                                "Terjadi Kesalahan",
                                                Toast.LENGTH_LONG
                                            ).show()
                                            loadingSrv.visibility = View.GONE
                                        }
                                    }

                                    override fun onFailure(call: Call<Peminjaman>, t: Throwable) {
                                        Log.e("pesan error","${t.message}")
                                        loadingSrv.visibility = View.GONE
                                    }


                                })
                            }
                            dialog.show()
                        }



                        nama.text =isi_nama
                        nis.text =isi_nis
                        email.text =isi_email
                        tanggal.text =isi_tanggal
                        tanggal2.text =isi_tanggal
                        durasi.text =isi_durasi
                        deadline.text =isi_deadline
                    }

                }
                if (response.body()!!.isEmpty()) {
                    text_blank.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<List<DetailPnj>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message, Toast.LENGTH_LONG).show()
            }
        })

    }
    fun tampilBuku(){
        val id_pinjam = intent.getStringExtra("id_pinjam").toString()
        val api = RetrofitClient().getInstances()
        api.getBukuByIdPinjam(id_pinjam).enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        bukuArrayList.add(bk)
                    }
                    listDetail3.adapter = DetailBukuAdapter(this@DetailPinjam,bukuArrayList)

                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message,Toast.LENGTH_LONG).show()
            }
        })


    }

    private fun showCustomDialogBox(msg: String?) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)
        dialog.setContentView(R.layout.layout_alert)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog.findViewById(R.id.btnYes)
        val btnNo : Button = dialog.findViewById(R.id.btnNo)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            dialog.dismiss()
            loadingSrv.visibility = View.VISIBLE
            val id_pinjam = intent.getStringExtra("id_pinjam").toString()
            val api = RetrofitClient().getInstances()
            api.cancelPnj(id_pinjam).enqueue(object :retrofit2.Callback<Peminjaman>{

                override fun onResponse(call: Call<Peminjaman>, response: Response<Peminjaman>) {
                    if (response.isSuccessful()) {
                        if (response.body() != null && response.body()?.result_code == true) {
                            val msg : String? =response.body()?.message
                            cancelBox(msg)
                        } else {
                            Toast.makeText(
                                this@DetailPinjam,
                                response.body()?.message,
                                Toast.LENGTH_LONG
                            ).show()
                            loadingSrv.visibility = View.GONE
                        }
                    }else{
                        Toast.makeText(
                            this@DetailPinjam,
                            "Terjadi Kesalahan",
                            Toast.LENGTH_LONG
                        ).show()
                        loadingSrv.visibility = View.GONE
                    }
                }

                override fun onFailure(call: Call<Peminjaman>, t: Throwable) {
                    Log.e("pesan error","${t.message}")
                    loadingSrv.visibility = View.GONE
                }


            })

        }
        btnNo.setOnClickListener{
            dialog.dismiss()
        }
        dialog.show()
    }
    private fun cancelBox(msg: String?) {


        val dialog2 = Dialog(this)
        dialog2.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog2.setCancelable(false)
        dialog2.setContentView(R.layout.layout_alert2)
        dialog2.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val tv_msgAlert : TextView = dialog2.findViewById(R.id.msgAlert)
        val btnYes : Button = dialog2.findViewById(R.id.btnYes)

        tv_msgAlert.text = msg

        btnYes.setOnClickListener{
            dialog2.dismiss()
            finish()
        }
        dialog2.show()
    }
}