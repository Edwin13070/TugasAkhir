package com.example.eperpus.model.data_class

class History(
    val id_pinjam : String?,
    val kd_pinjam : String?,
    val tanggal_pinjam : String?,
    val status_pinjam : String?,
    val judul : String?,
    val id_anggota : String?
)