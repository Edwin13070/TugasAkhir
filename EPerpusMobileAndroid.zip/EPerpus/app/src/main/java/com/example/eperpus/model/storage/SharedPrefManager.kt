package com.example.eperpus.model.storage

import android.content.Context
import com.example.eperpus.model.login.DataLogin

class SharedPrefManager private constructor(private val mCtx: Context) {

    val isLoggedIn: Boolean
        get() {
            val sharedPreferences =
                mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
            return sharedPreferences.getString("username", null) != null
        }

    val user: DataLogin
        get() {
            val sharedPreferences =
                mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
            return DataLogin(
                sharedPreferences.getString("id", null),
                sharedPreferences.getString("nis", null),
                sharedPreferences.getString("nama", null),
                sharedPreferences.getString("jenkel", null),
                sharedPreferences.getString("tempat_lahir", null),
                sharedPreferences.getString("tgl_lahir", null),
                sharedPreferences.getString("alamat", null),
                sharedPreferences.getString("no_telp", null),
                sharedPreferences.getString("username", null),
                sharedPreferences.getString("password", null),
                sharedPreferences.getString("email", null),
                sharedPreferences.getString("hak_akses", null),
                sharedPreferences.getString("foto", null)
            )

        }

    fun saveUser(user: DataLogin) {
        val sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()

        editor.putString("id", user.id)
        editor.putString("nis", user.nis)
        editor.putString("nama", user.nama)
        editor.putString("jenkel", user.jenkel)
        editor.putString("tempat_lahir", user.tempat_lahir)
        editor.putString("tgl_lahir", user.tgl_lahir)
        editor.putString("alamat", user.alamat)
        editor.putString("no_telp", user.no_telp)
        editor.putString("username", user.username)
        editor.putString("password", user.password)
        editor.putString("email", user.email)
        editor.putString("hak_akses", user.hak_akses)
        editor.putString("foto", user.foto)
        editor.apply()
    }

    val cekLog: Boolean
        get() {
            val sharedPreferences =
                mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
            return sharedPreferences.getString("hak_akses", null) != null
        }

    val hakAkses: String?
        get() {
            val sharedPreferences =
                mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
            return sharedPreferences.getString("hak_akses", null)
        }


    val buku: String?
        get() {
            val sharedPreferences =
                mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
            return sharedPreferences.getString("id_buku", null)
        }

    fun saveBuku(bengkel: String?) {
        val sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("id_buku", bengkel)
        editor.apply()
    }


    fun clear() {
        val sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.clear()
        editor.apply()
    }

    companion object {
        private val SHARED_PREF_NAME = "my_shared_preff"
        private var mInstance: SharedPrefManager? = null

        @Synchronized
        fun getInstance(mCtx: Context): SharedPrefManager {
            if (mInstance == null) {
                mInstance = SharedPrefManager(mCtx)
            }
            return mInstance as SharedPrefManager
        }
    }


}