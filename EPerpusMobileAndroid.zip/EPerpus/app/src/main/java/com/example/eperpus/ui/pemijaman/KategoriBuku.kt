package com.example.eperpus.ui.pemijaman

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.model.adapter.BukuAdapter2
import com.example.eperpus.model.data_class.Buku
import kotlinx.android.synthetic.main.activity_detail_buku.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class KategoriBuku : AppCompatActivity() {

    private lateinit var swipeRefresh : SwipeRefreshLayout
    private lateinit var bukuArrayList : ArrayList<Buku>
    private lateinit var cari : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kategori_buku)

        val nama_ktg = intent.getStringExtra("nama_ktg").toString()
        val tvktg : TextView =findViewById(R.id.nm_ktg)
        tvktg.text = nama_ktg


        //menampilkan data buku
        val id_ktg = intent.getStringExtra("id_ktg").toString()
        val api = RetrofitClient().getInstances()
        api.viewBukuById(id_ktg).enqueue(object  : Callback<List<Buku>> {
            override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                if (response.body() != null && response.isSuccessful()){
                    bukuArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val bk = Buku(
                            response.body()!![i]!!.id_buku,
                            response.body()!![i]!!.kd_buku,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.no_buku,
                            response.body()!![i]!!.pengarang,
                            response.body()!![i]!!.penerbit,
                            response.body()!![i]!!.thn_terbit,
                            response.body()!![i]!!.stok,
                            response.body()!![i]!!.sampul,
                            response.body()!![i]!!.keterangan_buku,
                            response.body()!![i]!!.id_ktg,
                            response.body()!![i]!!.nama_ktg
                        )
                        bukuArrayList.add(bk)
                    }
                    gridView.adapter = BukuAdapter2(this@KategoriBuku,bukuArrayList)
                    gridView.setOnItemClickListener { parent, view, position, id ->
                        val id_buku = response.body()!![position]!!.id_buku
                        val stok = response.body()!![position]!!.stok
                        val id_ktg = response.body()!![position]!!.id_ktg

                        val i = Intent(this@KategoriBuku, DetailBuku::class.java)
                        i.putExtra("id_buku",id_buku)
                        i.putExtra("stok",stok)
                        i.putExtra("id_ktg",id_ktg)
                        startActivity(i)
                    }
                }
            }

            override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                Toast.makeText(this@KategoriBuku,t.message, Toast.LENGTH_LONG).show()
            }
        })


        //Function untuk pencarian
        cari = findViewById(R.id.txt_Cari)
        cari.setOnKeyListener(View.OnKeyListener{ v, keyCode, event ->

            if( keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_UP){
                val kata_cari = cari.text.toString().trim()
                val id_ktg = intent.getStringExtra("id_ktg").toString()
                val api = RetrofitClient().getInstances()
                api.cariBukuById(kata_cari,id_ktg).enqueue(object  : Callback<List<Buku>> {
                    override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                        if (response.body() != null && response.isSuccessful()){
                            bukuArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val bk = Buku(
                                    response.body()!![i]!!.id_buku,
                                    response.body()!![i]!!.kd_buku,
                                    response.body()!![i]!!.judul,
                                    response.body()!![i]!!.no_buku,
                                    response.body()!![i]!!.pengarang,
                                    response.body()!![i]!!.penerbit,
                                    response.body()!![i]!!.thn_terbit,
                                    response.body()!![i]!!.stok,
                                    response.body()!![i]!!.sampul,
                                    response.body()!![i]!!.keterangan_buku,
                                    response.body()!![i]!!.id_ktg,
                                    response.body()!![i]!!.nama_ktg
                                )
                                bukuArrayList.add(bk)
                            }
                            gridView.adapter = BukuAdapter2(this@KategoriBuku,bukuArrayList)
                            gridView.setOnItemClickListener { parent, view, position, id ->
                                val id_buku = response.body()!![position]!!.id_buku
                                val stok = response.body()!![position]!!.stok

                                val i = Intent(this@KategoriBuku, DetailBuku::class.java)
                                i.putExtra("id_buku",id_buku)
                                i.putExtra("stok",stok)
                                startActivity(i)
                            }
                        }
                    }

                    override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                        Toast.makeText(this@KategoriBuku,t.message,Toast.LENGTH_LONG).show()
                    }
                })

                return@OnKeyListener true

            }
            false

        })


        //Fungsi refresh
        swipeRefresh = findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnRefreshListener{

            Toast.makeText(applicationContext,"Memperbarui Data", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                swipeRefresh.isRefreshing = false
                //menampilkan data buku
                val id_ktg = intent.getStringExtra("id_ktg").toString()
                val api = RetrofitClient().getInstances()
                api.viewBukuById(id_ktg).enqueue(object  : Callback<List<Buku>> {
                    override fun onResponse(call: Call<List<Buku>>, response: Response<List<Buku>>) {
                        if (response.body() != null && response.isSuccessful()){
                            bukuArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val bk = Buku(
                                    response.body()!![i]!!.id_buku,
                                    response.body()!![i]!!.kd_buku,
                                    response.body()!![i]!!.judul,
                                    response.body()!![i]!!.no_buku,
                                    response.body()!![i]!!.pengarang,
                                    response.body()!![i]!!.penerbit,
                                    response.body()!![i]!!.thn_terbit,
                                    response.body()!![i]!!.stok,
                                    response.body()!![i]!!.sampul,
                                    response.body()!![i]!!.keterangan_buku,
                                    response.body()!![i]!!.id_ktg,
                                    response.body()!![i]!!.nama_ktg
                                )
                                bukuArrayList.add(bk)
                            }
                            gridView.adapter = BukuAdapter2(this@KategoriBuku,bukuArrayList)
                            gridView.setOnItemClickListener { parent, view, position, id ->
                                val id_buku = response.body()!![position]!!.id_buku
                                val stok = response.body()!![position]!!.stok
                                val id_ktg = response.body()!![position]!!.id_ktg

                                val i = Intent(this@KategoriBuku, DetailBuku::class.java)
                                i.putExtra("id_buku",id_buku)
                                i.putExtra("stok",stok)
                                i.putExtra("id_ktg",id_ktg)
                                startActivity(i)
                            }
                        }
                    }

                    override fun onFailure(call: Call<List<Buku>>, t: Throwable) {
                        Toast.makeText(this@KategoriBuku,t.message, Toast.LENGTH_LONG).show()
                    }
                })
                Toast.makeText(applicationContext,"Memperbarui Data Selesai", Toast.LENGTH_LONG).show()
            }, 3000L)
        }
    }

}