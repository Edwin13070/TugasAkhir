package com.example.eperpus.model.adapter

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.eperpus.R
import com.example.eperpus.model.data_class.AktivitasUser
import com.example.eperpus.model.data_class.Kategori
import com.example.eperpus.ui.pemijaman.EditPinjam

class KategoriAdapter(private val mContext : Activity, private val arrayList:ArrayList<Kategori>): ArrayAdapter<Kategori>(mContext, R.layout.list_kategori, arrayList)  {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val inflater : LayoutInflater = LayoutInflater.from(mContext)
        val view : View = inflater.inflate(R.layout.list_kategori,null)

        val namaBk : TextView = view.findViewById(R.id.txt_kat)
        namaBk.text = arrayList[position].nama_ktg

        return view
    }
}