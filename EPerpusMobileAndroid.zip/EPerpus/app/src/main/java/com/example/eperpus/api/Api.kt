package com.example.eperpus.api

import com.example.eperpus.model.data_class.*
import com.example.eperpus.model.login.DataLogin
import com.example.eperpus.model.login.Login
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface Api {
    // LOGIN REGISTER AREA//

    //API Proses Login
    @FormUrlEncoded
    @POST("login/loginUser.php")
    fun userLogin(
        @Field("username") username:String,
        @Field("password") password:String
    ): Call<Login>

    //API Proses Register
    @Multipart
    @POST("login/registerUser.php")
    fun userRegister(
        @Part("no_user") no_user: RequestBody,
        @Part("nama_user") nama_user: RequestBody,
        @Part("jenkel") jenkel: RequestBody,
        @Part("tempat_lahir") tempat_lahir: RequestBody,
        @Part("tgl_lahir") tgl_lahir: RequestBody,
        @Part("alamat") alamat: RequestBody,
        @Part("no_telp") no_telp: RequestBody,
        @Part("email") email: RequestBody,
        @Part("username") username: RequestBody,
        @Part("password") password: RequestBody,
        @Part foto : MultipartBody.Part //untuk upload foto
    ): Call<Register>

    //API Proses Lupa password, tahap cek email
    @FormUrlEncoded
    @POST("login/lupaPassword.php")
    fun cekEmailCus(
        @Field("email") email:String
    ): Call<LupaPassword>

    //API Proses Lupa password, tahap reset password baru
    @FormUrlEncoded
    @POST("login/resetPassword.php")
    fun resetPassword(
        @Field("email") email:String,
        @Field("password") password:String
    ): Call<LupaPassword>

    // TUTUP LOGIN REGISTER AREA//

    //Profil
    @FormUrlEncoded
    @POST("user/getIdUser.php")
    fun getIdUser(
        @Field("id_user") id_user : String,
        @Field("hak_akses") hak_akses : String
    ): Call<List<DataLogin>>

    @Multipart
    @POST("user/EditUser.php")
    fun editUser(
        @Part("id_user") id_user: RequestBody,
        @Part("nama_user") nama_user: RequestBody,
        @Part("jenkel") jenkel: RequestBody,
        @Part("tempat_lahir") tempat_lahir: RequestBody,
        @Part("tgl_lahir") tgl_lahir: RequestBody,
        @Part("alamat") alamat: RequestBody,
        @Part("no_telp") no_telp: RequestBody,
        @Part("email") email: RequestBody,
        @Part("username") username: RequestBody,
        @Part("password") password: RequestBody,
        @Part foto : MultipartBody.Part //untuk upload foto
    ): Call<Register>

    //API TAMPIL BUKU
    @GET("buku/dataBuku.php")
    fun viewBuku() :Call<List<Buku>>

    @FormUrlEncoded
    @POST("buku/getBukuByid.php")
    fun getBukuById(
        @Field("id_buku") id_buku : String
    ): Call<List<Buku>>

    @FormUrlEncoded
    @POST("buku/getBukuByid2.php")
    fun getBukuById2(
        @Field("id_buku") id_buku : String
    ): Call<List<Buku>>

    @FormUrlEncoded
    @POST("buku/cariBuku.php")
    fun cariBuku(
        @Field("kata_cari") kata_cari : String
    ): Call<List<Buku>>

    @FormUrlEncoded
    @POST("buku/cariBukuById.php")
    fun cariBukuById(
        @Field("kata_cari") kata_cari : String,
        @Field("id_ktg") id_ktg : String
    ): Call<List<Buku>>

    //API Peminjaman
    //1. Proses peminjaman
    @FormUrlEncoded
    @POST("peminjaman/inputPinjam.php")
    fun inputPnj(
        @Field("tanggal_pinjam") tanggal_pinjam:String,
        @Field("durasi") durasi:String,
        @Field("id_buku") id_buku:String,
        @Field("id_anggota") id_anggota:String
    ): Call<Peminjaman>

    //API untuk menampilkan aktivitas customer
    @FormUrlEncoded
    @POST("peminjaman/getPinjamById.php")
    fun getAktivitasById(
        @Field("id_anggota") id_anggota : String
    ): Call<List<AktivitasUser>>

    @FormUrlEncoded
    @POST("peminjaman/cariPinjam.php")
    fun cariPinjam(
        @Field("id_anggota") id_anggota : String,
        @Field("kata_cari") kata_cari : String
    ): Call<List<AktivitasUser>>

    @FormUrlEncoded
    @POST("peminjaman/getIdPinjam.php")
    fun getIdPinjam(
        @Field("id_pinjam") id_pinjam : String,
    ): Call<List<AktivitasUser>>

    @FormUrlEncoded
    @POST("peminjaman/detailPeminjaman.php")
    fun getDetail(
        @Field("id_pinjam") id_pinjam : String,
    ): Call<List<DetailPnj>>


    @FormUrlEncoded
    @POST("buku/getBukuByidPinjam.php")
    fun getBukuByIdPinjam(
        @Field("id_pinjam") id_pinjam : String
    ): Call<List<Buku>>

    @FormUrlEncoded
    @POST("peminjaman/editPinjam.php")
    fun editPnj(
        @Field("id_pinjam") id_pinjam:String,
        @Field("tanggal_pinjam") tanggal_pinjam:String,
        @Field("durasi") durasi:String
    ): Call<Peminjaman>

    @FormUrlEncoded
    @POST("peminjaman/cancelPnj.php")
    fun cancelPnj(
        @Field("id_pinjam") id_pinjam : String
    ): Call<Peminjaman>

    @FormUrlEncoded
    @POST("peminjaman/ApprovePnj.php")
    fun ApprovePnj(
        @Field("id_pinjam") id_pinjam : String
    ): Call<Peminjaman>

    @FormUrlEncoded
    @POST("peminjaman/UnapprovedPnj.php")
    fun UnApprovePnj(
        @Field("id_pinjam") id_pinjam : String
    ): Call<Peminjaman>

    //API untuk menampilkan history customer
    @FormUrlEncoded
    @POST("peminjaman/getHistoryById.php")
    fun getHistoryById(
        @Field("id_anggota") id_anggota : String
    ): Call<List<History>>

    //ambil setttingan durasi input dari admin
    @GET("peminjaman/settingDurasi.php")
    fun getDurasi() :Call<List<DurasiInput>>

    //ambil setttingan durasi input dari admin
    @GET("buku/dataKategori.php")
    fun viewKategori() :Call<List<Kategori>>

    //tampil buku berdasarkan kategori
    @FormUrlEncoded
    @POST("buku/filterBuku.php")
    fun viewBukuById(
        @Field("id_ktg") id_ktg : String
    ) :Call<List<Buku>>
}