package com.example.eperpus.ui.menu

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.eperpus.R
import com.example.eperpus.api.RetrofitClient
import com.example.eperpus.model.adapter.HistoryAdapter
import com.example.eperpus.model.data_class.History
import com.example.eperpus.model.storage.SharedPrefManager
import com.example.eperpus.ui.pemijaman.DetailPinjam
import kotlinx.android.synthetic.main.activity_history.*
import kotlinx.android.synthetic.main.fragment_aktivitas.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class historyActivity : AppCompatActivity() {

    private lateinit var swipeRefresh : SwipeRefreshLayout
    private lateinit var historyMnArrayList : ArrayList<History>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        //kontrol refresh -> refresh akan bekerja jika hanya layout berada di list 1
        swipeRefresh = findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnChildScrollUpCallback(object : SwipeRefreshLayout.OnChildScrollUpCallback {
            override fun canChildScrollUp(parent: SwipeRefreshLayout, child: View?): Boolean {
                if (listView5 != null) {
                    return listView5.canScrollVertically(-1)
                }
                return false
            }
        })

        refresh()

        val api = RetrofitClient().getInstances()
        val id_anggota = SharedPrefManager.getInstance(this).user.id.toString()
        api.getHistoryById(id_anggota).enqueue(object  : Callback<List<History>> {
            override fun onResponse(call: Call<List<History>>, response: Response<List<History>>) {
                if (response.body() != null && response.isSuccessful()){
                    historyMnArrayList = ArrayList()
                    for (i in response.body()!!.indices){
                        val his = History(
                            response.body()!![i]!!.id_pinjam,
                            response.body()!![i]!!.kd_pinjam,
                            response.body()!![i]!!.tanggal_pinjam,
                            response.body()!![i]!!.status_pinjam,
                            response.body()!![i]!!.judul,
                            response.body()!![i]!!.id_anggota
                        )
                        historyMnArrayList.add(his)

                    }
                    listView5.adapter = HistoryAdapter(this@historyActivity,historyMnArrayList)
                    listView5.setOnItemClickListener { parent, view, position, id ->
                        val id_pinjam = response.body()!![position]!!.id_pinjam
                        val i = Intent(this@historyActivity, DetailPinjam::class.java)
                        i.putExtra("id_pinjam",id_pinjam)
                        startActivity(i)
                    }
                }
                if (response.body()!!.isEmpty()) {
                    listView5.visibility = View.GONE
                    text_blank3.visibility = View.VISIBLE
                }
            }

            override fun onFailure(call: Call<List<History>>, t: Throwable) {
                Toast.makeText(applicationContext,t.message, Toast.LENGTH_LONG).show()
            }
        })
    }


    fun refresh(){
        swipeRefresh = findViewById(R.id.swipeRefresh)
        swipeRefresh.setOnRefreshListener{

            Toast.makeText(applicationContext,"Memperbarui Data", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({
                swipeRefresh.isRefreshing = false
                val api = RetrofitClient().getInstances()
                val id_anggota = SharedPrefManager.getInstance(this).user.id.toString()
                api.getHistoryById(id_anggota).enqueue(object  : Callback<List<History>> {
                    override fun onResponse(call: Call<List<History>>, response: Response<List<History>>) {
                        if (response.body() != null && response.isSuccessful()){
                            historyMnArrayList = ArrayList()
                            for (i in response.body()!!.indices){
                                val his = History(
                                    response.body()!![i]!!.id_pinjam,
                                    response.body()!![i]!!.kd_pinjam,
                                    response.body()!![i]!!.tanggal_pinjam,
                                    response.body()!![i]!!.status_pinjam,
                                    response.body()!![i]!!.judul,
                                    response.body()!![i]!!.id_anggota
                                )
                                historyMnArrayList.add(his)

                            }
                            listView5.adapter = HistoryAdapter(this@historyActivity,historyMnArrayList)
                            listView5.setOnItemClickListener { parent, view, position, id ->
                                val id_pinjam = response.body()!![position]!!.id_pinjam
                                val i = Intent(this@historyActivity, DetailPinjam::class.java)
                                i.putExtra("id_pinjam",id_pinjam)
                                startActivity(i)
                            }
                        }
                        if (response.body()!!.isEmpty()) {
                            listView5.visibility = View.GONE
                            text_blank3.visibility = View.VISIBLE
                        }
                    }

                    override fun onFailure(call: Call<List<History>>, t: Throwable) {
                        Toast.makeText(applicationContext,t.message, Toast.LENGTH_LONG).show()
                    }
                })
                Toast.makeText(applicationContext,"Memperbarui Data Selesai", Toast.LENGTH_LONG).show()
            }, 3000L)
        }
    }

    fun btn_backListener(v: View){
        finish()
    }
}