package com.example.eperpus.error

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.example.eperpus.R
import com.example.eperpus.support.Utilitas


class ErrorForResultActivity : AppCompatActivity() {
    private lateinit var className : String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_error_for_result)

//        className = Utilitas().getExtraString(savedInstanceState, "className", intent)!!
        findViewById<TextView>(R.id.lblMSG).setText(Utilitas().getExtraString(savedInstanceState, "msg", intent)!!)
    }

    override fun onBackPressed() {
        back()
    }

    fun reload(v : View){
        setResult(RESULT_OK)
        finish()
    }

    private fun back(){
        setResult(RESULT_CANCELED)
        finish()
    }

}