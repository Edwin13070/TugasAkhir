-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 25 Des 2023 pada 03.12
-- Versi server: 10.4.17-MariaDB
-- Versi PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `role_user`
--

CREATE TABLE `role_user` (
  `id_role` int(11) NOT NULL,
  `hak_akses` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `role_user`
--

INSERT INTO `role_user` (`id_role`, `hak_akses`) VALUES
(1, 'admin'),
(2, 'anggota');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_buku`
--

CREATE TABLE `tbl_buku` (
  `id_buku` int(11) NOT NULL,
  `kd_buku` varchar(20) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `no_buku` char(30) NOT NULL,
  `pengarang` varchar(50) NOT NULL,
  `penerbit` varchar(40) NOT NULL,
  `thn_terbit` varchar(20) NOT NULL,
  `stok` int(11) NOT NULL,
  `keterangan_buku` text NOT NULL,
  `sampul` varchar(100) NOT NULL,
  `id_ktg` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_buku`
--

INSERT INTO `tbl_buku` (`id_buku`, `kd_buku`, `judul`, `no_buku`, `pengarang`, `penerbit`, `thn_terbit`, `stok`, `keterangan_buku`, `sampul`, `id_ktg`) VALUES
(1, 'BK001', 'Perahu Kertas', '1210-1232', 'Endang Sujarwo', 'Matahari', '2018', 0, 'Buku cerita karya Raditya Dika', 'perahu.jpg', 2),
(3, 'BK002', 'KKN', '223313', 'Andri Suherman', 'Andi Jaya', '2019', 0, 'tes tes', 'IMG-20220517-WA0022.jpg', 3),
(4, 'BK003', 'Cek Toko Sebelah', '12322112', 'Indro Warkop', 'CV. Aditama', '2022', 18, 'tes aja', 'index61.jpg', 2),
(5, 'BK004', 'Abatasa', '765223', 'Muhammad Ali', 'CV. Andi ', '2023', 5, 'Buku cerita anak muda', 'poster-film-indo-3d350.jpg', 4),
(6, 'BK005', 'Kartini', '86521', 'Andri Suherman', 'CV. Aditama', '2023', 0, 'Buku biografi yang menceritakan Kartini sebagai salah satu pahlawan wanita Indoneisa', '692037-poster-palsu.jpg', 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_denda`
--

CREATE TABLE `tbl_denda` (
  `id_denda` int(11) NOT NULL,
  `kd_denda` varchar(20) NOT NULL,
  `nominal` int(11) NOT NULL,
  `keterangan` text NOT NULL,
  `jns_denda` enum('Utama','Tambahan') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_denda`
--

INSERT INTO `tbl_denda` (`id_denda`, `kd_denda`, `nominal`, `keterangan`, `jns_denda`) VALUES
(1, 'DN001', 500, 'Denda telat (per hari)', 'Utama'),
(4, 'DN002', 60000, 'Buku Hilang/Rusak', 'Tambahan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail`
--

CREATE TABLE `tbl_detail` (
  `id_detail` int(11) NOT NULL,
  `id_pinjam` int(11) NOT NULL,
  `id_buku` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_detail`
--

INSERT INTO `tbl_detail` (`id_detail`, `id_pinjam`, `id_buku`) VALUES
(38, 55, 4),
(39, 56, 4),
(56, 82, 6),
(57, 83, 6),
(58, 84, 6),
(60, 86, 6),
(61, 87, 6),
(62, 88, 6),
(63, 89, 6),
(64, 90, 4),
(65, 90, 4),
(66, 90, 4),
(68, 94, 6),
(69, 96, 5),
(70, 98, 6),
(71, 97, 6),
(72, 100, 1),
(73, 101, 1),
(74, 102, 1),
(75, 103, 5),
(76, 104, 5),
(77, 105, 4),
(78, 106, 4),
(79, 107, 4),
(80, 108, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kategori`
--

CREATE TABLE `tbl_kategori` (
  `id_ktg` int(11) NOT NULL,
  `nama_ktg` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_kategori`
--

INSERT INTO `tbl_kategori` (`id_ktg`, `nama_ktg`) VALUES
(1, 'Sosiologi & Sains'),
(2, 'Ensiklopedia'),
(3, 'Biografi'),
(4, 'Kamus');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kembali`
--

CREATE TABLE `tbl_kembali` (
  `id_pengembalian` int(11) NOT NULL,
  `tanggal_kembali` date NOT NULL,
  `total_denda` int(11) NOT NULL,
  `id_pinjam` int(11) NOT NULL,
  `id_denda` int(11) NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_maxpinjam`
--

CREATE TABLE `tbl_maxpinjam` (
  `id_max` int(11) NOT NULL,
  `max_hari` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_maxpinjam`
--

INSERT INTO `tbl_maxpinjam` (`id_max`, `max_hari`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pinjam`
--

CREATE TABLE `tbl_pinjam` (
  `id_pinjam` int(11) NOT NULL,
  `kd_pinjam` varchar(20) NOT NULL,
  `tanggal_booking` date NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `durasi` int(11) NOT NULL,
  `deadline_kembali` date NOT NULL,
  `tokenInp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status_pinjam` int(11) NOT NULL,
  `notifikasi_email` enum('0','1') NOT NULL,
  `id_admin` int(11) NOT NULL,
  `id_anggota` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` int(11) NOT NULL,
  `no_user` varchar(20) NOT NULL,
  `nama_user` varchar(50) NOT NULL,
  `jenkel` enum('Laki-laki','Perempuan') NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat` text NOT NULL,
  `no_telp` char(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tgl_dibuat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status_akun` varchar(30) NOT NULL,
  `token_akun` varchar(100) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `id_role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `no_user`, `nama_user`, `jenkel`, `tempat_lahir`, `tgl_lahir`, `alamat`, `no_telp`, `email`, `tgl_dibuat`, `username`, `password`, `status_akun`, `token_akun`, `foto`, `id_role`) VALUES
(1, '7642', 'Edwin Setiawan', 'Laki-laki', 'Semarangs', '2003-07-24', 'Jalan Sriwedari No.12 Semarang Barat', '086232312442', 'alfin@gmail.com', '2023-10-14 05:51:47', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', 'admin@gmail.com', 'avatar-03.jpg', 1),
(5, '7831', 'Emmy Search', 'Laki-laki', 'Jakarta', '2001-02-01', 'Jalan Surabaya No.12', '086542632232', 'emmy@gmai.com', '2023-10-29 13:32:54', 'emmy', '8a74cdd9f34548a005a6952504f991ad', '1', '', 'avatar-041.jpg', 2),
(7, '9723', 'Isabella', 'Perempuan', 'Kelantan', '2023-09-12', 'Malaysia', '08975423212', 'hoodiejogjka@gmail.com', '2023-10-14 02:53:45', 'asdas', '827ccb0eea8a706c4c34a16891f84e7b', '1', '', 'avatar-big-01.jpg', 2),
(10, '8631', 'Sasha Kharisma', 'Perempuan', 'Sleman', '2008-10-24', 'Jalan Kebon Agung', '0865423234', 'tes@gmail.com', '2023-10-08 15:54:35', 'admin2', 'c84258e9c39059a89ab77d846ddab909', '1', '', 'avatar-021.jpg', 1),
(25, '5463', 'Alfin Faiz Aseggaf', 'Perempuan', 'Den Hag', '2023-10-14', 'Pekalongan', '08644645145', 'aseggaf27@gmail.com', '2023-10-29 13:29:42', 'alfin123', '21232f297a57a5a743894a0e4a801fc3', '1', 'aseggaf27@gmail.come3bcb8c92bbf7ccc5af52a53f806d66257a9c219e3f6b12b19ac706c46bb4c0e', 'cancelimage.png', 2);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id_role`);

--
-- Indeks untuk tabel `tbl_buku`
--
ALTER TABLE `tbl_buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD KEY `id_ktg` (`id_ktg`);

--
-- Indeks untuk tabel `tbl_denda`
--
ALTER TABLE `tbl_denda`
  ADD PRIMARY KEY (`id_denda`);

--
-- Indeks untuk tabel `tbl_detail`
--
ALTER TABLE `tbl_detail`
  ADD PRIMARY KEY (`id_detail`);

--
-- Indeks untuk tabel `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  ADD PRIMARY KEY (`id_ktg`);

--
-- Indeks untuk tabel `tbl_kembali`
--
ALTER TABLE `tbl_kembali`
  ADD PRIMARY KEY (`id_pengembalian`);

--
-- Indeks untuk tabel `tbl_maxpinjam`
--
ALTER TABLE `tbl_maxpinjam`
  ADD PRIMARY KEY (`id_max`);

--
-- Indeks untuk tabel `tbl_pinjam`
--
ALTER TABLE `tbl_pinjam`
  ADD PRIMARY KEY (`id_pinjam`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_role` (`id_role`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_buku`
--
ALTER TABLE `tbl_buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tbl_denda`
--
ALTER TABLE `tbl_denda`
  MODIFY `id_denda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tbl_detail`
--
ALTER TABLE `tbl_detail`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT untuk tabel `tbl_kategori`
--
ALTER TABLE `tbl_kategori`
  MODIFY `id_ktg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `tbl_kembali`
--
ALTER TABLE `tbl_kembali`
  MODIFY `id_pengembalian` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT untuk tabel `tbl_maxpinjam`
--
ALTER TABLE `tbl_maxpinjam`
  MODIFY `id_max` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tbl_pinjam`
--
ALTER TABLE `tbl_pinjam`
  MODIFY `id_pinjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
